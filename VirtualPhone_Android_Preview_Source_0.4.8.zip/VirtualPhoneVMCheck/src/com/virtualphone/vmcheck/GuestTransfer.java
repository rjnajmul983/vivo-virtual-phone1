package com.virtualphone.vmcheck;

import java.io.*;
import java.security.MessageDigest;
import java.util.*;

/** Selected-file transfer with per-chunk acknowledgements and guest-side SHA-256. */
final class GuestTransfer {
    interface Progress {void update(long bytes,long total);boolean cancelled();}
    static String safeName(String name){
        String n=(name==null?"file":name).replaceAll("[^A-Za-z0-9._-]","_");
        if(n.length()>100)n=n.substring(n.length()-100);
        if(n.isEmpty()||n.equals(".")||n.equals(".."))n="file";
        return n;
    }
    static String digest(File file)throws Exception {
        MessageDigest sha=MessageDigest.getInstance("SHA-256");byte[] b=new byte[65536];int n;
        try(InputStream in=new FileInputStream(file)){while((n=in.read(b))>=0)sha.update(b,0,n);}
        StringBuilder s=new StringBuilder();for(byte v:sha.digest())s.append(String.format(Locale.ROOT,"%02x",v&255));return s.toString();
    }
    static String send(GuestConsole console,File file,String name,boolean apk,Progress progress)throws Exception {
        String stage="/data/local/tmp/vp-"+UUID.randomUUID().toString().replace("-","")+".pending";
        String expected=digest(file),path=GuestConsole.quote(stage);long total=file.length(),sent=0;
        console.command("umask 077; : > "+path,false,10000).require();
        try {
            byte[] buffer=new byte[1024];int n;
            try(InputStream in=new FileInputStream(file)) {
                while((n=in.read(buffer))>=0){
                    if(progress.cancelled()||Thread.currentThread().isInterrupted())throw new IOException("Transfer cancelled");
                    String b64=Base64.getEncoder().encodeToString(Arrays.copyOf(buffer,n));
                    console.command("printf %s '"+b64+"' | base64 -d >> "+path,false,15000).require();
                    sent+=n;progress.update(sent,total);
                }
            }
            if(sent!=total)throw new IOException("Selected file changed during transfer");
            String actual=console.command("sha256sum "+path,false,15000).require().output;
            if(!actual.matches("(?s).*\\b"+expected+"\\s+.*"))throw new IOException("Guest SHA-256 mismatch; import rejected");
            if(apk){
                GuestConsole.Result result=console.command("cat "+path+" | pm install -r -S "+total,false,180000).require();
                if(!Arrays.asList(result.output.split("\\r?\\n")).contains("Success"))throw new IOException("Guest package installer did not confirm Success: "+result.output);
                return "APK installed in guest; SHA-256 "+expected;
            }
            String leaf=UUID.randomUUID().toString().substring(0,8)+"-"+safeName(name);
            String destination="/storage/emulated/0/Download/VirtualPhone/"+leaf;
            // The init console is in the global mount namespace; its /sdcard alias
            // has no per-app FUSE mount. Write the guest's backing media as root,
            // using media_rw ownership, without sharing a host directory.
            String backing="/data/media/0/Download/VirtualPhone/"+leaf;
            String dest=GuestConsole.quote(backing),tmp=GuestConsole.quote(backing+".pending");
            console.command("mkdir -p /data/media/0/Download/VirtualPhone && chown 1023:1023 /data/media/0/Download /data/media/0/Download/VirtualPhone && chmod 0775 /data/media/0/Download /data/media/0/Download/VirtualPhone && cp "+path+" "+tmp+" && chown 1023:1023 "+tmp+" && chmod 0664 "+tmp+" && mv "+tmp+" "+dest,true,60000).require();
            String committed=console.command("sha256sum "+dest,true,15000).require().output;
            if(!committed.matches("(?s).*\\b"+expected+"\\s+.*"))throw new IOException("Committed guest file checksum mismatch");
            return destination+"\nSHA-256 "+expected;
        } finally {try{console.command("rm -f "+path,false,5000);}catch(Exception ignored){}}
    }
}
