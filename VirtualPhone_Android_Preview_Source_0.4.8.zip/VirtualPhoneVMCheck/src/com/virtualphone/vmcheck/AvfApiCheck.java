package com.virtualphone.vmcheck;

import android.content.Context;
import android.os.Build;
import android.view.KeyEvent;
import android.view.MotionEvent;
import org.json.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.Executor;

/** Enumerates the complete custom-image surface BEFORE any image download. Read-only. */
final class AvfApiCheck {
    interface Step {void run()throws Exception;}
    private final JSONObject result=new JSONObject(),inventories=new JSONObject();
    private final JSONArray checks=new JSONArray(),failures=new JSONArray();
    private final Set<String> inspected=new HashSet<>();
    private void check(String name,Step step)throws Exception {
        JSONObject item=new JSONObject();item.put("member",name);
        try{step.run();item.put("accessible",true);}catch(Throwable e){item.put("accessible",false);item.put("error",DeviceProbe.describe(e));failures.put(name);}
        checks.put(item);
    }
    private Class<?> type(String name)throws Exception {
        Class<?> t=Class.forName(name);
        if(inspected.add(name))inventories.put(name,AvfReflection.inventory(t));
        return t;
    }
    private void builder(String name,Context c)throws Exception {check(name+" constructor",()->AvfReflection.builder(type(name),Context.class,c));}
    private void method(String owner,String name,Class<?>... params)throws Exception {check(owner+"."+name+Arrays.toString(params),()->AvfReflection.method(type(owner),name,params));}
    static JSONObject run(Context c)throws Exception {return new AvfApiCheck().probe(c);}
    private JSONObject probe(Context c)throws Exception {
        result.put("manufacturer",Build.MANUFACTURER);result.put("model",Build.MODEL);result.put("sdk",Build.VERSION.SDK_INT);result.put("android",Build.VERSION.RELEASE);
        result.put("hiddenApiPolicyChangedByApp",false);result.put("interpretation","A missing reflective member can mean Android non-SDK filtering or an OEM API difference; it does not establish lack of VM hardware.");
        result.put("instrumentationSessionActive",VmSessionInstrumentation.active());
        result.put("adbSetup",setupState(c));
        result.put("preflightScope","Required Java/native interface accessibility only. Idle Binder lookup is diagnostic and cannot prove guest boot, service permission or display rendering.");
        for(String p:new String[]{"android.permission.MANAGE_VIRTUAL_MACHINE","android.permission.USE_CUSTOM_VIRTUAL_MACHINE"})check(p,()->{if(c.checkSelfPermission(p)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new SecurityException("Permission not granted");});
        String base="android.system.virtualmachine.VirtualMachineCustomImageConfig",custom=base+"$Builder",display=base+"$DisplayConfig$Builder",gpu=base+"$GpuConfig$Builder";
        String config="android.system.virtualmachine.VirtualMachineConfig",host=config+"$Builder",vm="android.system.virtualmachine.VirtualMachine";
        builder(custom,c);builder(display,c);builder(gpu,c);builder(host,c);
        for(String name:new String[]{"setName","setKernelPath","setInitrdPath","addParam"})method(custom,name,String.class);
        for(String name:new String[]{"useTouch","useKeyboard","useNetwork"})method(custom,name,boolean.class);
        for(String name:new String[]{"setWidth","setHeight","setHorizontalDpi","setVerticalDpi","setRefreshRate"})method(display,name,int.class);
        method(gpu,"setBackend",String.class);
        for(String name:new String[]{custom,display,gpu,host})method(name,"build");
        check("custom image disk/partition/display/GPU/config types",()->{
            Class<?> disk=type(base+"$Disk"),partition=type(base+"$Partition");
            AvfReflection.method(disk,"RWDisk",String.class);AvfReflection.method(disk,"addPartition",partition);
            partition.getConstructor(String.class,String.class,boolean.class,String.class);
            AvfReflection.method(type(custom),"addDisk",disk);
            AvfReflection.method(type(custom),"setDisplayConfig",type(base+"$DisplayConfig"));
            AvfReflection.method(type(custom),"setGpuConfig",type(base+"$GpuConfig"));
            AvfReflection.method(type(host),"setCustomImageConfig",type(base));
        });
        for(String name:new String[]{"setProtectedVm","setVmOutputCaptured","setVmConsoleInputSupported"})method(host,name,boolean.class);
        for(String name:new String[]{"setDebugLevel","setCpuTopology"})method(host,name,int.class);
        method(host,"setMemoryBytes",long.class);method(host,"setConsoleInputDevice",String.class);
        check("VM config constants",()->{type(config).getField("DEBUG_LEVEL_FULL").getInt(null);type(config).getField("CPU_TOPOLOGY_MATCH_HOST").getInt(null);});
        for(String name:new String[]{"getConsoleInput","getConsoleOutput","getLogOutput","run","close"})method(vm,name);
        method(vm,"sendMultiTouchEvent",MotionEvent.class);
        check("VM keyboard input API (scan code or KeyEvent)",()->result.put("keyboardInputMethod",AvfReflection.keyboardMethod(type(vm),KeyEvent.class).toString()));
        check("VM callbacks and manager",()->{
            Class<?> callback=type("android.system.virtualmachine.VirtualMachineCallback");
            AvfReflection.method(type(vm),"setCallback",Executor.class,callback);
            AvfReflection.method(type(vm),"setConfig",type(config));
            Class<?> manager=type("android.system.virtualmachine.VirtualMachineManager");
            AvfReflection.method(manager,"get",String.class);AvfReflection.method(manager,"create",String.class,type(config));
        });
        final Boolean[] visible={null};
        check("native display bridge / interface symbols",()->visible[0]=AndroidDisplay.checkApi());
        JSONObject displayState=new JSONObject();displayState.put("systemBinderVisibleNow",visible[0]==null?JSONObject.NULL:visible[0]);
        displayState.put("runtimeGraphicsAccessVerified",false);
        displayState.put("interpretation","An idle checkService returning null is not a failed Java API check or proof of permission denial. Service and Surface access are checked again after VM.run().");
        result.put("displayServiceObservation",displayState);
        boolean readinessAttempted=failures.length()==0;
        if(readinessAttempted){
            JSONObject lookup=AndroidDisplay.observeService(true);
            displayState.put("lazyStartObservation",lookup);
            displayState.put("permissionDeniedConfirmed",lookup.optBoolean("permissionDeniedConfirmed"));
        } else displayState.put("permissionDeniedConfirmed",false);
        displayState.put("lazyStartReadinessCheckAttempted",readinessAttempted);
        displayState.put("lazyStartReadinessCheckPassed",readinessAttempted&&displayState.optJSONObject("lazyStartObservation").optBoolean("binderVisible"));
        displayState.put("requiredForJavaPreflight",false);
        result.put("passed",AvfPreflightPolicy.passed(failures.length()));
        result.put("guestBootAndDisplayVerified",false);
        result.put("checks",checks);result.put("failedMembers",failures);
        if(failures.length()!=0)result.put("visibleApiInventory",inventories);
        return result;
    }
    private JSONObject setupState(Context c)throws Exception {
        JSONObject state=new JSONObject();
        state.put("manualSetupExecutionProven",false);state.put("runningProcessApiAccessProvenBySettingAlone",false);
        try{
            String value=android.provider.Settings.Global.getString(c.getContentResolver(),"hidden_api_blacklist_exemptions");
            JSONArray coverage=new JSONArray();boolean all=true;
            for(String descriptor:new String[]{
                "Landroid/system/virtualmachine/VirtualMachineCustomImageConfig$Builder;",
                "Landroid/system/virtualmachine/VirtualMachineConfig$Builder;",
                "Landroid/system/virtualmachine/VirtualMachine;",
                "Landroid/system/virtualmachine/VirtualMachineManager;",
                "Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal;",
                "Landroid/crosvm/ICrosvmAndroidDisplayService;"}){
                boolean present=AvfSetupState.covered(value,descriptor);all&=present;
                coverage.put(new JSONObject().put("descriptor",descriptor).put("coveredByCurrentSetting",present));
            }
            state.put("settingRead","ok");state.put("allRequiredDescriptorsCovered",all);state.put("coverage",coverage);
        }catch(Throwable e){state.put("settingRead","unavailable");state.put("readError",DeviceProbe.describe(e));}
        state.put("interpretation","Setting coverage is read-only evidence. The separate constructor/method checks determine actual access; false hiddenApiPolicyChangedByApp does not mean the user never ran ADB setup.");
        return state;
    }
}
