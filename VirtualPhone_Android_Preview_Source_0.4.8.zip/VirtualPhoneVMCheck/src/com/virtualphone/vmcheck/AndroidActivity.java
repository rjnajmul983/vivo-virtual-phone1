package com.virtualphone.vmcheck;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.graphics.Color;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;

public final class AndroidActivity extends Activity implements AndroidVm.Listener {
    private TextView status,scope;private Button install,start,stop,ram;private SurfaceView surface;private ImageView snapshot;
    private final Handler timer=new Handler(Looper.getMainLooper());
    private final Runnable tick=new Runnable(){public void run(){refresh();timer.postDelayed(this,1000);}};
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private Button button(LinearLayout box,String text,Runnable action){Button b=new Button(this);b.setText(text);box.addView(b);b.setOnClickListener(v->action.run());return b;}
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);AndroidVm.initialize(this);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(8));box.setBackgroundColor(Color.rgb(10,20,38));
        box.setOnApplyWindowInsetsListener((v,insets)->{if(Build.VERSION.SDK_INT>=30){android.graphics.Insets i=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());v.setPadding(i.left+dp(12),i.top+dp(8),i.right+dp(12),i.bottom+dp(8));}return insets;});
        TextView title=new TextView(this);title.setText("VirtualPhone · Android preview 0.4.8");title.setTextColor(Color.rgb(124,231,202));title.setTextSize(19);box.addView(title);
        scope=new TextView(this);scope.setText((VmSessionInstrumentation.active()?"ADB পরীক্ষামূলক session চলছে। Termux-এর command চালু রাখুন। ":"")+"পূর্ণ Android image চালানোর পরীক্ষামূলক build। প্রথম setup: প্রায় ১.০৩ GB download ও অন্তত ১৪ GB খালি জায়গা। Root apps, Chrome ও গেম এখনও যাচাই হয়নি। অ্যাপটি খোলা রাখুন।");scope.setTextColor(Color.LTGRAY);scope.setTextSize(12);box.addView(scope);
        status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(14);box.addView(status);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);box.addView(controls);
        install=button(controls,"Android নামান",()->AndroidVm.install(this));start=button(controls,"Start",()->AndroidVm.start(this));stop=button(controls,"Stop",AndroidVm::stop);
        ram=button(controls,"RAM "+(AndroidVm.memoryMiB(this)/1024)+" GB",this::chooseRam);
        FrameLayout viewport=new FrameLayout(this);viewport.setBackgroundColor(Color.BLACK);box.addView(viewport,new LinearLayout.LayoutParams(-1,0,1));
        surface=new SurfaceView(this);viewport.addView(surface,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        snapshot=new ImageView(this);snapshot.setScaleType(ImageView.ScaleType.FIT_CENTER);
        snapshot.setBackgroundColor(Color.BLACK);snapshot.setVisibility(View.GONE);
        viewport.addView(snapshot,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
        snapshot.setOnTouchListener((v,e)->{AndroidVm.touch(e,v.getWidth(),v.getHeight());return true;});
        viewport.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{int w=r-l,h=b-t;if(w<=0||h<=0)return;int fitW=Math.min(w,h*720/1280),fitH=fitW*1280/720;FrameLayout.LayoutParams fit=(FrameLayout.LayoutParams)surface.getLayoutParams();if(fit.width!=fitW||fit.height!=fitH){fit.width=fitW;fit.height=fitH;surface.setLayoutParams(fit);}});
        surface.getHolder().addCallback(new SurfaceHolder.Callback(){public void surfaceCreated(SurfaceHolder h){AndroidDisplay.present(h.getSurface());}public void surfaceChanged(SurfaceHolder h,int f,int w,int height){AndroidDisplay.present(h.getSurface());}public void surfaceDestroyed(SurfaceHolder h){AndroidDisplay.remove();}});
        surface.setOnTouchListener((v,e)->{AndroidVm.touch(e,v.getWidth(),v.getHeight());return true;});
        LinearLayout capture=new LinearLayout(this);box.addView(capture);
        button(capture,"Screen snapshot",()->AndroidVm.captureScreen(this,(image,message)->runOnUiThread(()->{
            if(isFinishing()||isDestroyed())return;
            if(image!=null){snapshot.setImageBitmap(image);snapshot.setVisibility(View.VISIBLE);}
            show(message);
        })));
        button(capture,"Live view",()->{snapshot.setImageDrawable(null);snapshot.setVisibility(View.GONE);});
        button(capture,"Graphics test",()->AndroidVm.diagnoseGraphics(this,this::show));
        LinearLayout navigation=new LinearLayout(this);box.addView(navigation);button(navigation,"Back",()->AndroidVm.key(KeyEvent.KEYCODE_BACK));button(navigation,"Home",()->AndroidVm.key(KeyEvent.KEYCODE_HOME));button(navigation,"Recents",()->AndroidVm.key(KeyEvent.KEYCODE_APP_SWITCH));
        LinearLayout files=new LinearLayout(this);box.addView(files);button(files,"APK install",()->pick(true));button(files,"File import",()->pick(false));button(files,"VM tools",this::tools);
        LinearLayout report=new LinearLayout(this);box.addView(report);
        button(report,"Copy report",()->{String value=AndroidVm.report();try{value=new JSONObject(value).toString(2);}catch(Exception ignored){}((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Android VM report",value));Toast.makeText(this,"রিপোর্ট কপি হয়েছে",Toast.LENGTH_SHORT).show();});
        button(report,"আগের VM পরীক্ষা",()->{if(!AndroidVm.active()&&!AndroidVm.busy())startActivity(new Intent(this,MainActivity.class));});
        LinearLayout api=new LinearLayout(this);box.addView(api);
        button(api,"API check",()->AndroidVm.checkApi(this,this::show));button(api,"Display check",this::displayCheck);button(api,"Setup নির্দেশনা",this::setup);
        setContentView(box);AndroidVm.observe(this);refresh();
    }
    private void pick(boolean apk){
        if(!AndroidVm.active()||AndroidVm.transferring()){show("আগে VM চালু করুন এবং চলমান কাজ শেষ হতে দিন।");return;}
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.setType(apk?"application/vnd.android.package-archive":"*/*");pick.addCategory(Intent.CATEGORY_OPENABLE);pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(pick,apk?40:41);
    }
    private void chooseRam(){
        if(AndroidVm.active()||AndroidVm.busy()){show("RAM পরিবর্তনের আগে VM Stop করুন।");return;}
        String[] choices={"2 GB (আগের সেটিং)","3 GB (পরীক্ষার জন্য প্রস্তাবিত)","4 GB (বেশি host RAM দরকার)"};
        int selected=AndroidVm.memoryMiB(this)/1024-2;
        new AlertDialog.Builder(this).setTitle("Guest Android-এর RAM")
            .setSingleChoiceItems(choices,selected,(dialog,index)->{
                int value=(index+2)*1024;
                if(AndroidVm.setMemoryMiB(this,value))ram.setText("RAM "+(index+2)+" GB");
                dialog.dismiss();
            }).setNegativeButton("Cancel",null).show();
    }
    @Override protected void onActivityResult(int request,int code,Intent data){super.onActivityResult(request,code,data);if((request==40||request==41)&&code==RESULT_OK&&data!=null&&data.getData()!=null)AndroidVm.importFile(this,data.getData(),request==40,this::show);}
    private void tools(){
        new AlertDialog.Builder(this).setTitle("Guest VM tools").setItems(new String[]{"Home screen খুলুন","Settings","File manager","Guest root পরীক্ষা","Installed apps","Guest command"},(d,which)->{
            String command;boolean root=false;
            switch(which){
                case 0:command="settings put global device_provisioned 1; settings put secure user_setup_complete 1; input keyevent 82; am start -a android.intent.action.MAIN -c android.intent.category.HOME";root=true;break;
                case 1:command="am start -a android.settings.SETTINGS";break;
                case 2:command="am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n com.android.documentsui/.files.FilesActivity";break;
                case 3:command="id; getenforce; getprop sys.boot_completed";root=true;break;
                case 4:command="pm list packages -3";break;
                default:shell();return;
            }
            AndroidVm.command(this,command,root,this::show);
        }).setNegativeButton("Close",null).show();
    }
    private void shell(){
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(16),0,dp(16),0);box.setOrientation(LinearLayout.VERTICAL);
        EditText input=new EditText(this);input.setText("id");input.setSingleLine(false);box.addView(input);
        CheckBox root=new CheckBox(this);root.setText("Guest root (শুধু VM)");box.addView(root);
        new AlertDialog.Builder(this).setTitle("Guest command").setView(box).setPositiveButton("Run",(d,w)->AndroidVm.command(this,input.getText().toString(),root.isChecked(),this::show)).setNegativeButton("Cancel",null).show();
    }
    private void setup(){
        new AlertDialog.Builder(this).setTitle("App-only ADB session").setMessage("Global setting সংরক্ষিত না হলে Android-এর app-testing session ব্যবহার করুন। কপি করা command আগের Wireless ADB-connected Termux-এ চালান। শুধু VirtualPhone-এর পরীক্ষামূলক process-এ hidden API checks শিথিল হয়; global setting লেখা হয় না। প্রতিবার এই command দিয়ে খুলতে হবে। এটি VM boot/display সফল হওয়ার প্রমাণ নয়।")
            .setPositiveButton("Copy launch command",(d,w)->{String command="adb shell am instrument --no-hidden-api-checks -w com.virtualphone.vmcheck/.VmSessionInstrumentation";((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("VirtualPhone diagnostic launch",command));Toast.makeText(this,"Termux command কপি হয়েছে",Toast.LENGTH_LONG).show();}).setNeutralButton("End ADB session",(d,w)->{if(AndroidVm.active()||AndroidVm.busy())show("আগে VM Stop করুন।");else VmSessionInstrumentation.requestEnd();}).setNegativeButton("Close",null).show();
    }
    private void displayCheck(){
        new Thread(()->{
            JSONObject result=AndroidDisplay.observeService(true);
            AndroidVm.put("manualDisplayServiceCheck",result);
            show("Display Binder observation (not a graphics test):\n"+result.toString());
        },"vp-display-diagnostic").start();
    }
    private void show(String output){runOnUiThread(()->{if(isFinishing()||isDestroyed())return;TextView text=new TextView(this);text.setText(output);text.setTextIsSelectable(true);text.setPadding(dp(16),dp(12),dp(16),dp(12));ScrollView scroll=new ScrollView(this);scroll.addView(text);new AlertDialog.Builder(this).setTitle("VM result").setView(scroll).setPositiveButton("Close",null).show();});}
    private void refresh(){
        if(isFinishing()||isDestroyed())return;
        String value=AndroidVm.status();if(!AndroidVm.busy()&&!AndroidVm.active()&&AndroidImageStore.ready(this)&&value.equals("Android image প্রস্তুত করা বাকি।"))value="Android image প্রস্তুত। Start চাপুন।";
        status.setText(value);install.setEnabled(!AndroidVm.busy()&&!AndroidVm.active()&&!AndroidImageStore.ready(this));start.setEnabled(!AndroidVm.busy()&&!AndroidVm.active()&&AndroidImageStore.ready(this));stop.setEnabled(AndroidVm.busy()||AndroidVm.active());
        ram.setEnabled(!AndroidVm.busy()&&!AndroidVm.active());
        if(AndroidVm.active()&&surface.getHolder().getSurface().isValid())AndroidDisplay.present(surface.getHolder().getSurface());
    }
    @Override public void changed(){runOnUiThread(this::refresh);}
    @Override protected void onResume(){super.onResume();timer.post(tick);}
    @Override protected void onPause(){timer.removeCallbacks(tick);super.onPause();}
    @Override protected void onDestroy(){if(isFinishing()){AndroidDisplay.remove();AndroidVm.stop();VmSessionInstrumentation.requestEnd();}super.onDestroy();}
}
