package com.virtualphone.vmcheck;

/** A capability signal must never be presented as a successful guest boot. */
public final class ProbeStatus {
    private ProbeStatus() {}
    public static String code(boolean feature, boolean manage, boolean custom, boolean kvmOpened) {
        if (feature && manage && custom) return "AVF_ACCESS_SIGNALS_ONLY";
        if (feature) return "AVF_PRESENT_ACCESS_UNCONFIRMED";
        if (kvmOpened) return "KVM_OPEN_ONLY";
        return "NO_ACCELERATION_CONFIRMED";
    }
    public static String title(String code) {
        switch (code) {
            case "AVF_ACCESS_SIGNALS_ONLY": return "AVF ও অনুমতির সংকেত পাওয়া গেছে";
            case "AVF_PRESENT_ACCESS_UNCONFIRMED": return "AVF আছে; ব্যবহার করার অনুমতি যাচাই বাকি";
            case "KVM_OPEN_ONLY": return "KVM ডিভাইস খোলা গেছে; VM পরীক্ষা বাকি";
            default: return "Hardware VM চালানোর প্রমাণ এখনও মেলেনি";
        }
    }
    public static String explanation(String code) {
        switch (code) {
            case "AVF_ACCESS_SIGNALS_ONLY":
                return "এখনও পূর্ণ Android boot, custom kernel, graphics ও গেম পরীক্ষা হয়নি।";
            case "AVF_PRESENT_ACCESS_UNCONFIRMED":
                return "Firmware-এ AVF প্রকাশ করা আছে। সাধারণ অ্যাপ থেকে custom Android চালানো যাবে কি না, এই ফল একা তা প্রমাণ করে না।";
            case "KVM_OPEN_ONLY":
                return "শুধু device open সফল হয়েছে। KVM ioctl, VM তৈরি বা guest boot পরীক্ষা করা হয়নি।";
            default:
                return "এটি সফটওয়্যার emulation অসম্ভব বলে না। AVF broker-এর প্রবেশাধিকার ও graphics আলাদা পরীক্ষা দরকার।";
        }
    }
}
