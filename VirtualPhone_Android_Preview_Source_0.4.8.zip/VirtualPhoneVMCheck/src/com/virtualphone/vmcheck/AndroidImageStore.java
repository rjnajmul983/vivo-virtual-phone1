package com.virtualphone.vmcheck;

import android.content.Context;
import android.os.StatFs;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.CancellationException;
import java.util.regex.*;
import java.util.zip.*;

/** Installs only the pinned public AOSP guest, inside this app's private directory. */
final class AndroidImageStore {
    static final String ARCHIVE_SHA="a9314183f3cf4d15a0a2121a85f8300ca7990788c52474d322c6fe9320b40802";
    static final long ARCHIVE_BYTES=1101174958L, SUPER_BYTES=8589934592L;
    interface Status {void update(String value);boolean cancelled();}
    static File directory(Context c){return new File(c.getFilesDir(),"android-guest-v1");}
    static boolean ready(Context c){File d=directory(c);return new File(d,"image-ready-v1").isFile()&&new File(d,"super.raw").length()==SUPER_BYTES&&new File(d,"userdata.img").length()==4294967296L;}
    static void check(Status s)throws IOException {if(s.cancelled()||Thread.currentThread().isInterrupted())throw new IOException("Cancelled");}
    static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte v:b)s.append(String.format(java.util.Locale.ROOT,"%02x",v&255));return s.toString();}
    static HttpURLConnection connect(String url)throws Exception {
        URL u=new URL(url);if(!"https".equals(u.getProtocol()))throw new IOException("HTTPS required");
        HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent","VirtualPhone-Android-Preview/0.3");
        c.setInstanceFollowRedirects(false);
        for(int redirects=0;;redirects++) {
            int code=c.getResponseCode();if(code>=300&&code<400&&redirects<5){URL next=new URL(u,c.getHeaderField("Location"));c.disconnect();if(!next.getProtocol().equals("https"))throw new IOException("Insecure redirect rejected");u=next;c=(HttpURLConnection)u.openConnection();c.setConnectTimeout(25000);c.setReadTimeout(30000);c.setRequestProperty("User-Agent","VirtualPhone-Android-Preview/0.3");c.setInstanceFollowRedirects(false);continue;}
            if(code!=200){c.disconnect();throw new IOException("Image server returned HTTP "+code);}return c;
        }
    }
    private static String text(String url,int max)throws Exception {
        HttpURLConnection c=connect(url);try(InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()) {
            byte[] buffer=new byte[4096];int n;while((n=in.read(buffer))>=0){if(b.size()+n>max)throw new IOException("Metadata too large");b.write(buffer,0,n);}return new String(b.toByteArray(),StandardCharsets.UTF_8);
        }finally{c.disconnect();}
    }
    static void install(Context context,Status status)throws Exception {
        if(ready(context)){status.update("Android image প্রস্তুত আছে।");return;}
        File d=directory(context);if(!d.isDirectory()&&!d.mkdirs())throw new IOException("Cannot create private guest directory");
        if(new StatFs(d.getAbsolutePath()).getAvailableBytes()<14L*1024*1024*1024)throw new IOException("অন্তত ১৪ GB খালি storage প্রয়োজন।");
        File zip=new File(context.getCacheDir(),"aosp-16644040.zip");
        // No consumer key or signed download URL is saved in the app or logs.
        if(zip.length()!=ARCHIVE_BYTES||!hash(zip,status).equals(ARCHIVE_SHA)) {
            status.update("অফিশিয়াল Android image-এর download address নেওয়া হচ্ছে…");check(status);
            String source=text("https://raw.githubusercontent.com/google/android-cuttlefish/main/base/cvd/cuttlefish/host/libs/web/android_build_api_key.cc",65536);
            Matcher m=Pattern.compile("AIza[0-9A-Za-z_-]+").matcher(source);if(!m.find())throw new IOException("Official public image client metadata changed");
            String endpoint="https://androidbuild-pa.googleapis.com/v4/builds/16644040/aosp_cf_arm64_only_phone-userdebug/attempts/latest/artifacts/aosp_cf_arm64_only_phone-img-16644040.zip/url?key="+URLEncoder.encode(m.group(),"UTF-8");
            String address=new JSONObject(text(endpoint,65536)).getString("signedUrl");
            HttpURLConnection c=connect(address);File part=new File(context.getCacheDir(),"aosp-16644040.zip.part");
            MessageDigest hash=MessageDigest.getInstance("SHA-256");long bytes=0,last=0;
            try(InputStream in=c.getInputStream();FileOutputStream out=new FileOutputStream(part)) {
                byte[] buffer=new byte[1024*1024];int n;
                while((n=in.read(buffer))>=0){check(status);bytes+=n;if(bytes>ARCHIVE_BYTES)throw new IOException("Image exceeds pinned size");out.write(buffer,0,n);hash.update(buffer,0,n);long now=System.currentTimeMillis();if(now-last>750){status.update("Android নামছে: "+(bytes/(1024*1024))+" / 1050 MB");last=now;}}
                out.getFD().sync();
            } finally {c.disconnect();}
            if(bytes!=ARCHIVE_BYTES||!hex(hash.digest()).equals(ARCHIVE_SHA)){part.delete();throw new IOException("Android image SHA-256 mismatch");}
            if(zip.exists()&&!zip.delete())throw new IOException("Cannot replace cached image");
            if(!part.renameTo(zip))throw new IOException("Cannot commit downloaded image");
        }
        check(status);status.update("Checksum মিলেছে। Android disk প্রস্তুত হচ্ছে…");
        File pending=new File(d,"super.raw.pending");final long[] last={0};
        try(ZipFile z=new ZipFile(zip)) {
            ZipEntry entry=z.getEntry("super.img");if(entry==null||entry.getSize()!=1746554644L)throw new IOException("Unexpected super image");
            SparseImage.decode(z.getInputStream(entry),pending,SUPER_BYTES,bytes->{check(status);long now=System.currentTimeMillis();if(now-last[0]>750){status.update("Android disk তৈরি: "+(100*bytes/SUPER_BYTES)+"%");last[0]=now;}});
            check(status);status.update("Android kernel ও ramdisk প্রস্তুত হচ্ছে…");BootImages.prepare(z,d);
        }
        // The guest init trigger reports real sys.boot_completed for this run's nonce.
        JSONObject patches=new JSONObject(assetText(context,"android/patches.json"));
        try(RandomAccessFile raw=new RandomAccessFile(pending,"rw")) {
            JSONArray items=patches.getJSONArray("patches");
            for(int i=0;i<items.length();i++) {
                JSONObject item=items.getJSONObject(i);byte[] old=new byte[item.getInt("length")];raw.seek(item.getLong("offset"));raw.readFully(old);
                if(!hex(MessageDigest.getInstance("SHA-256").digest(old)).equals(item.getString("oldSha256")))throw new IOException("Guest patch precondition failed");
                byte[] replacement=android.util.Base64.decode(item.getString("replacementBase64"),android.util.Base64.DEFAULT);
                if(replacement.length!=old.length)throw new IOException("Guest patch length mismatch");raw.seek(item.getLong("offset"));raw.write(replacement);
            }raw.getFD().sync();
        }
        check(status);File committed=new File(d,"super.raw");if(committed.exists()&&!committed.delete())throw new IOException("Cannot replace incomplete guest image");
        if(!pending.renameTo(committed))throw new IOException("Cannot commit guest disk");
        for(String n:new String[]{"userdata.img","metadata.img","misc.img","frp.img"}) {
            // Existing guest data is never reset by image installation or app updates.
            File file=new File(d,n);if(!file.exists()){status.update("Guest-এর নিজস্ব "+n+" তৈরি হচ্ছে…");copyAsset(context,"android/"+n+".gz",file,true,status);}
        }
        try(FileOutputStream out=new FileOutputStream(new File(d,"image-ready-v1"))){out.write(ARCHIVE_SHA.getBytes(StandardCharsets.US_ASCII));out.getFD().sync();}
        zip.delete();status.update("Android image প্রস্তুত। এবার Start চাপুন।");
    }
    private static String hash(File file,Status s)throws Exception {
        if(!file.exists())return "";s.update("Android image checksum যাচাই হচ্ছে…");MessageDigest d=MessageDigest.getInstance("SHA-256");
        try(InputStream in=new FileInputStream(file)){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>=0){check(s);d.update(b,0,n);}}return hex(d.digest());
    }
    static String assetText(Context c,String n)throws Exception {try(InputStream in=c.getAssets().open(n);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int k;while((k=in.read(b))>=0)out.write(b,0,k);return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
    private static void copyAsset(Context c,String name,File target,boolean gzip,Status s)throws Exception {
        File pending=new File(target.getPath()+".pending");
        try(InputStream asset=c.getAssets().open(name);InputStream in=gzip?new GZIPInputStream(asset,1024*1024):asset;RandomAccessFile out=new RandomAccessFile(pending,"rw")) {
            out.setLength(0);byte[] b=new byte[1024*1024];long total=0;int n;
            while((n=in.read(b))>=0){check(s);boolean zero=true;for(int i=0;i<n;i++)if(b[i]!=0){zero=false;break;}if(zero)out.seek(total+n);else out.write(b,0,n);total+=n;}
            out.setLength(total);out.getFD().sync();
        }
        if(!pending.renameTo(target))throw new IOException("Cannot commit "+target.getName());
    }
}
