package com.virtualphone.vmcheck;

/** Required API accessibility is separate from lazy display service readiness. */
final class AvfPreflightPolicy {
    private AvfPreflightPolicy() {}
    static boolean passed(int requiredFailures) {return requiredFailures==0;}
}
