package com.virtualphone.vmcheck;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** Locally derives guest kernel/ramdisk from the user's SHA-256-verified Google ZIP.
 * No kernel or third-party driver binary is redistributed inside this APK.
 */
final class BootImages {
    private static long u32(byte[] b,int p)throws IOException {if(p<0||p+4>b.length)throw new EOFException();return (b[p]&255L)|((b[p+1]&255L)<<8)|((b[p+2]&255L)<<16)|((b[p+3]&255L)<<24);}
    private static byte[] read(InputStream in,int n)throws IOException {byte[] b=new byte[n];int p=0;while(p<n){int k=in.read(b,p,n-p);if(k<0)throw new EOFException();p+=k;}return b;}
    private static void skip(InputStream in,long n)throws IOException {while(n>0){long k=in.skip(n);if(k==0){if(in.read()<0)throw new EOFException();k=1;}n-=k;}}
    private static void magic(byte[] b,String expected)throws IOException {for(int i=0;i<expected.length();i++)if(b[i]!=(byte)expected.charAt(i))throw new IOException("Invalid Android boot image");}
    static void prepare(ZipFile zip,File directory)throws IOException {
        File image=new File(directory,"Image.pending");
        try(InputStream in=zip.getInputStream(required(zip,"boot.img"));FileOutputStream out=new FileOutputStream(image)) {
            byte[] h=read(in,4096);magic(h,"ANDROID!");long size=u32(h,8);if(u32(h,40)!=4||size!=42031616L)throw new IOException("Unexpected pinned boot kernel");
            byte[] b=new byte[1024*1024];long left=size;while(left>0){int n=in.read(b,0,(int)Math.min(left,b.length));if(n<0)throw new EOFException();out.write(b,0,n);left-=n;}out.getFD().sync();
        }
        byte[] vendor;
        try(InputStream in=zip.getInputStream(required(zip,"vendor_boot.img"))) {
            byte[] h=read(in,2128);magic(h,"VNDRBOOT");long page=u32(h,12),size=u32(h,24);
            if(u32(h,8)!=4||page!=2048||size!=18816074L)throw new IOException("Unexpected pinned vendor ramdisk");
            skip(in,4096-h.length);vendor=legacyLz4(read(in,(int)size));
        }
        Map<String,Entry> members=cpio(vendor);
        try(InputStream in=zip.getInputStream(required(zip,"init_boot.img"))) {
            byte[] h=read(in,4096);magic(h,"ANDROID!");long size=u32(h,12);
            if(u32(h,8)!=0||u32(h,40)!=4||size!=2992408L)throw new IOException("Unexpected pinned generic ramdisk");
            members.putAll(cpio(legacyLz4(read(in,(int)size))));
        }
        for(Map.Entry<String,Entry> item:members.entrySet())if(item.getKey().contains("/fstab.cf.")) {
            Entry e=item.getValue();e.bytes=patchFstab(new String(e.bytes,e.offset,e.length,StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8);e.offset=0;e.length=e.bytes.length;
        }
        File ramdisk=new File(directory,"initrd.img.pending");
        try(FileOutputStream file=new FileOutputStream(ramdisk);GZIPOutputStream gz=new GZIPOutputStream(file,1024*1024)) {writeCpio(members,gz);gz.finish();file.getFD().sync();}
        if(!image.renameTo(new File(directory,"Image"))||!ramdisk.renameTo(new File(directory,"initrd.img")))throw new IOException("Cannot commit guest boot files");
    }
    private static ZipEntry required(ZipFile z,String name)throws IOException {ZipEntry e=z.getEntry(name);if(e==null)throw new IOException("Missing guest image "+name);return e;}
    /** Linux bootconfig trailer, matching kernel tools/bootconfig/main.c.
     * Keeps the growing Android hardware profile out of ARM64's short cmdline.
     */
    static void bootconfig(File source,File target,Map<String,String> params)throws IOException {
        StringBuilder text=new StringBuilder();
        for(Map.Entry<String,String> e:params.entrySet()) {
            if(!e.getKey().matches("[A-Za-z0-9_.-]+")||!e.getValue().matches("[A-Za-z0-9_.,:/=-]+"))throw new IOException("Invalid bootconfig field");
            String key=e.getKey().startsWith("androidboot.")?e.getKey():"kernel."+e.getKey();
            text.append(key).append(" = \"").append(e.getValue()).append("\"\n");
        }
        byte[] data=(text.toString()+"\0").getBytes(StandardCharsets.UTF_8);if(data.length>32764)throw new IOException("Bootconfig too large");
        int padding=(int)(-(source.length()+data.length+20)&3);long sum=0;for(byte v:data)sum+=v&255;
        File pending=new File(target.getPath()+".pending");
        try(InputStream in=new FileInputStream(source);FileOutputStream out=new FileOutputStream(pending)) {
            byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>=0)out.write(b,0,n);
            out.write(data);for(int i=0;i<padding;i++)out.write(0);
            for(long value:new long[]{data.length+padding,sum&0xffffffffL})for(int i=0;i<4;i++)out.write((int)(value>>>(8*i)));
            out.write("#BOOTCONFIG\n".getBytes(StandardCharsets.US_ASCII));out.getFD().sync();
        }
        if(!pending.renameTo(target))throw new IOException("Cannot commit launch ramdisk");
    }
    /** LZ4 legacy blocks used by this pinned Android build; each block is independent. */
    static byte[] legacyLz4(byte[] input)throws IOException {
        if(u32(input,0)!=0x184c2102L)throw new IOException("Unsupported ramdisk compression");
        ByteArrayOutputStream out=new ByteArrayOutputStream(48*1024*1024);byte[] block=new byte[8*1024*1024];int p=4;
        while(p<input.length) {
            long amount=u32(input,p);p+=4;if(amount<=0||amount>input.length-p)throw new IOException("Invalid legacy LZ4 block");
            int end=p+(int)amount,used=0;
            while(p<end) {
                int token=input[p++]&255,literal=token>>>4;
                if(literal==15){int n;do{if(p>=end)throw new EOFException();n=input[p++]&255;literal+=n;}while(n==255);}
                if(literal>end-p||literal>block.length-used)throw new IOException("LZ4 literal exceeds bounds");
                System.arraycopy(input,p,block,used,literal);p+=literal;used+=literal;if(p==end)break;
                if(p+2>end)throw new EOFException();int distance=(input[p]&255)|((input[p+1]&255)<<8);p+=2;
                int match=(token&15)+4;if((token&15)==15){int n;do{if(p>=end)throw new EOFException();n=input[p++]&255;match+=n;}while(n==255);}
                if(distance<=0||distance>used||match>block.length-used)throw new IOException("Invalid LZ4 match");
                for(int i=0;i<match;i++)block[used+i]=block[used+i-distance];used+=match;
            }
            if(out.size()+used>64*1024*1024)throw new IOException("Ramdisk exceeds supported size");out.write(block,0,used);
        }
        return out.toByteArray();
    }
    private static final class Entry {long[] fields;byte[] bytes;int offset,length;Entry(long[] f,byte[] b,int o,int n){fields=f;bytes=b;offset=o;length=n;}}
    private static Map<String,Entry> cpio(byte[] bytes)throws IOException {
        Map<String,Entry> entries=new LinkedHashMap<>();int p=0;
        while(p+110<=bytes.length) {
            String magic=new String(bytes,p,6,StandardCharsets.US_ASCII);if(!magic.equals("070701"))throw new IOException("Unsupported newc archive");
            long[] fields=new long[13];try{for(int i=0;i<13;i++)fields[i]=Long.parseLong(new String(bytes,p+6+8*i,8,StandardCharsets.US_ASCII),16);}catch(NumberFormatException e){throw new IOException("Invalid newc field",e);}
            long names=fields[11],size=fields[6];if(names<1||names>4096||size>64*1024*1024L||p+110+names>bytes.length)throw new IOException("Invalid newc dimensions");
            String name=new String(bytes,p+110,(int)names-1,StandardCharsets.UTF_8);p=(p+110+(int)names+3)&~3;
            if(size>bytes.length-p)throw new EOFException();if(name.equals("TRAILER!!!"))return entries;
            if((fields[1]&0170000)==0100000&&fields[4]>1)throw new IOException("This port requires non-hardlinked ramdisk regular files");
            entries.put(name,new Entry(fields,bytes,p,(int)size));p=(p+(int)size+3)&~3;
        }
        throw new IOException("Missing newc trailer");
    }
    static String patchFstab(String input)throws IOException {
        StringBuilder out=new StringBuilder();
        for(String line:input.split("\n")) {
            if(line.trim().isEmpty()||line.trim().startsWith("#")){out.append(line).append('\n');continue;}
            String[] words=line.trim().split("\\s+");if(words.length!=5)throw new IOException("Unexpected guest fstab");
            List<String> flags=new ArrayList<>(Arrays.asList(words[4].split(",")));if(flags.contains("recoveryonly"))continue;
            Iterator<String> it=flags.iterator();while(it.hasNext()){String f=it.next();if(f.equals("avb")||f.startsWith("avb=")||f.startsWith("avb_keys=")||(words[1].equals("/data")&&(f.startsWith("fileencryption=")||f.startsWith("keydirectory=")||f.startsWith("metadata_encryption=")||f.startsWith("checkpoint="))))it.remove();}
            words[4]=String.join(",",flags);out.append(String.join(" ",words)).append('\n');
        }return out.toString();
    }
    private static long writeMember(OutputStream out,String name,Entry e,int index,long total)throws IOException {
        long[] f=e.fields.clone();f[0]=index;f[6]=e.length;f[11]=name.getBytes(StandardCharsets.UTF_8).length+1;f[12]=0;
        StringBuilder h=new StringBuilder("070701");for(long value:f)h.append(String.format(java.util.Locale.ROOT,"%08x",value));
        byte[] header=h.toString().getBytes(StandardCharsets.US_ASCII),n=name.getBytes(StandardCharsets.UTF_8);out.write(header);out.write(n);out.write(0);total+=header.length+n.length+1;
        while(total%4!=0){out.write(0);total++;}out.write(e.bytes,e.offset,e.length);total+=e.length;while(total%4!=0){out.write(0);total++;}return total;
    }
    private static void writeCpio(Map<String,Entry> members,OutputStream out)throws IOException {
        int index=0;long size=0;for(Map.Entry<String,Entry> e:members.entrySet())size=writeMember(out,e.getKey(),e.getValue(),++index,size);
        size=writeMember(out,"TRAILER!!!",new Entry(new long[13],new byte[0],0,0),++index,size);while(size%512!=0){out.write(0);size++;}
    }
}
