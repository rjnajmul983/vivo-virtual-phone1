package com.virtualphone.vmcheck;

import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity implements GuestBootTest.Listener {
    private static final int SAVE=17;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextView status,detail,reportView,bootStatus;
    private Button scan,copy,save,boot;
    private String report;
    private int dp(int value){return Math.round(value*getResources().getDisplayMetrics().density);}
    private TextView text(String value,int size,int color){
        TextView view=new TextView(this);view.setText(value);view.setTextSize(size);view.setTextColor(color);
        view.setPadding(0,dp(8),0,dp(8));return view;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(10,20,38));getWindow().setNavigationBarColor(Color.rgb(10,20,38));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(10,20,38));
        scroll.setOnApplyWindowInsetsListener((view,insets)->{
            if(android.os.Build.VERSION.SDK_INT>=30) {
                android.graphics.Insets bars=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
                view.setPadding(bars.left,bars.top,bars.right,bars.bottom);
            } else view.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout column=new LinearLayout(this);column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(22),dp(18),dp(22),dp(28));scroll.addView(column);
        TextView title=text("VirtualPhone VM Check",25,Color.rgb(124,231,202));
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);column.addView(title);
        column.addView(text("AVF guest boot পরীক্ষা · 0.2",20,Color.WHITE));
        column.addView(text("আপনার দেওয়া AVF অনুমতি দিয়ে একটি ছোট guest তৈরি করে পরীক্ষা শেষে মুছে দেয়। এটি পূর্ণ Android UI নয়; ফোন root করে না বা ইন্টারনেটে রিপোর্ট পাঠায় না।",14,Color.rgb(176,191,213)));
        status=text("পরীক্ষা চলছে…",19,Color.WHITE);column.addView(status);
        detail=text("",14,Color.rgb(176,191,213));column.addView(detail);
        scan=new Button(this);scan.setText("আবার পরীক্ষা করুন");column.addView(scan);
        bootStatus=text("",15,Color.rgb(124,231,202));column.addView(bootStatus);
        boot=new Button(this);boot.setText("Guest boot পরীক্ষা করুন");column.addView(boot);
        column.addView(text("Microdroid guest · ২৫৬ MB · প্রায় ২ মিনিট। পরীক্ষা চলার সময় অ্যাপটি খোলা রাখুন।",13,Color.rgb(176,191,213)));
        copy=new Button(this);copy.setText("রিপোর্ট কপি করুন / Copy report");column.addView(copy);
        save=new Button(this);save.setText("JSON রিপোর্ট সেভ করুন");column.addView(save);
        column.addView(text("পরীক্ষা শেষ হলে Copy report চাপুন এবং এই কথোপকথনে পেস্ট করুন।",14,Color.rgb(124,231,202)));
        reportView=text("",12,Color.rgb(205,220,240));reportView.setTypeface(Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);column.addView(reportView);
        setContentView(scroll);
        scan.setOnClickListener(v->scan());
        boot.setOnClickListener(v->{if(GuestBootTest.running())GuestBootTest.cancel();else GuestBootTest.start(this);});
        copy.setOnClickListener(v->{
            if(report!=null) {
                ((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("VM capability report",report));
                Toast.makeText(this,"রিপোর্ট কপি হয়েছে",Toast.LENGTH_SHORT).show();
            }
        });
        save.setOnClickListener(v->{
            if(report!=null) startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT)
                .addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                .putExtra(Intent.EXTRA_TITLE,"VirtualPhone_VM_Report.json"),SAVE);
        });
        GuestBootTest.observe(this);
        String saved=state==null?null:state.getString("report");
        if(saved!=null && saved.contains("VirtualPhone VM Check 0.2.0"))display(saved);else scan();
    }
    private void scan() {
        scan.setEnabled(false);copy.setEnabled(false);save.setEnabled(false);boot.setEnabled(false);
        status.setText("পরীক্ষা চলছে…");detail.setText("AVF, অনুমতি, KVM access এবং host graphics পড়া হচ্ছে।");
        worker.execute(()->{
            String result;
            try {result=DeviceProbe.run(getApplicationContext()).toString(2);}
            catch(Throwable error) {
                JSONObject failed=new JSONObject();
                try{failed.put("probeError",DeviceProbe.describe(error));failed.put("guestBootTested",false);}catch(Exception ignored){}
                result=failed.toString();
            }
            final String value=result;
            runOnUiThread(()->{if(!isFinishing()&&!isDestroyed())display(value);});
        });
    }
    private void display(String value) {
        scan.setEnabled(!GuestBootTest.running());copy.setEnabled(true);save.setEnabled(true);
        try {
            JSONObject parsed=new JSONObject(value);
            JSONObject bootResult=GuestBootTest.latest(this);
            if(bootResult!=null) {
                parsed.put("bootTest",bootResult);
                parsed.put("guestBootTested",bootResult.optBoolean("runRequested"));
                parsed.put("guestBootVerified",bootResult.optBoolean("payloadExecutionVerified"));
            }
            report=parsed.toString(2);reportView.setText(report);
            if(parsed.has("probeError")) {
                status.setText("পরীক্ষা সম্পূর্ণ হয়নি");detail.setText(parsed.optString("probeError"));
            } else {
                String code=parsed.getString("status");status.setText(ProbeStatus.title(code));detail.setText(ProbeStatus.explanation(code));
            }
            boolean granted=checkSelfPermission("android.permission.MANAGE_VIRTUAL_MACHINE")==android.content.pm.PackageManager.PERMISSION_GRANTED;
            boot.setEnabled(GuestBootTest.running() || (android.os.Build.VERSION.SDK_INT>=34 && granted));
            boot.setText(GuestBootTest.running()?"পরীক্ষা বন্ধ করুন":"Guest boot পরীক্ষা করুন");
            if(GuestBootTest.running())bootStatus.setText("Guest পরীক্ষা চলছে… "+(bootResult==null?"প্রস্তুতি":bootResult.optString("phase")));
            else if(bootResult==null)bootStatus.setText(granted?"AVF অনুমতি পাওয়া গেছে। এখন guest চালিয়ে পরীক্ষা করা যাবে।":"Guest চালাতে MANAGE_VIRTUAL_MACHINE অনুমতি লাগবে।");
            else if(bootResult.optBoolean("payloadExecutionVerified"))bootStatus.setText("Guest payload সত্যিই চলেছে এবং 42 exit code ফেরত দিয়েছে। পূর্ণ Android UI ও গেম এখনও পরীক্ষা হয়নি।");
            else bootStatus.setText("Guest ফল: "+bootResult.optString("state")+" · "+bootResult.optString("failure",bootResult.optString("phase")));
        } catch(Exception e) {status.setText("রিপোর্ট পড়া যায়নি");detail.setText(DeviceProbe.describe(e));}
    }
    @Override public void changed(){runOnUiThread(()->{if(!isFinishing()&&!isDestroyed()&&report!=null)display(report);});}
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);if(report!=null)state.putString("report",report);}
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==SAVE&&result==RESULT_OK&&data!=null&&data.getData()!=null&&report!=null) {
            try(OutputStream output=getContentResolver().openOutputStream(data.getData(),"wt")) {
                if(output==null)throw new IllegalStateException("Cannot open destination");
                output.write(report.getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"রিপোর্ট সেভ হয়েছে",Toast.LENGTH_SHORT).show();
            } catch(Exception e) {Toast.makeText(this,DeviceProbe.describe(e),Toast.LENGTH_LONG).show();}
        }
    }
    @Override protected void onDestroy(){if(isFinishing())GuestBootTest.cancel();worker.shutdownNow();super.onDestroy();}
}
