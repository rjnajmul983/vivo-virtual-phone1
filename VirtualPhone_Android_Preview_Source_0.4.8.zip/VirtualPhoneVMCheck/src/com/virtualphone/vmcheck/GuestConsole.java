package com.virtualphone.vmcheck;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;
import java.util.concurrent.*;

/** Framed commands on this app-owned guest's serial console. Never executes on the host. */
final class GuestConsole implements Closeable {
    static final class Result {
        final int code; final String output;
        Result(int code,String output){this.code=code;this.output=output;}
        Result require()throws IOException {if(code!=0)throw new IOException("Guest exit "+code+": "+output);return this;}
    }
    private static final class Pending {
        final String marker;final CountDownLatch done=new CountDownLatch(1);
        final StringBuilder output=new StringBuilder();boolean begun;int code=-1;IOException failure;
        Pending(String marker){this.marker=marker;}
    }
    private final OutputStream out;
    private final Object lock=new Object();
    private Pending pending;
    private volatile boolean closed;
    GuestConsole(OutputStream out){this.out=out;}
    static boolean bootMarker(String line,String nonce){return line.replace("\r","").matches("(?:\\[[^\\]\\r\\n]{1,40}\\]){0,3}\\s*"+java.util.regex.Pattern.quote("VP_ANDROID_BOOT_COMPLETE "+nonce));}
    static String quote(String value){return "'"+value.replace("'","'\\''")+"'";}
    synchronized Result command(String command,boolean root,long timeoutMs)throws Exception {
        if(closed)throw new IOException("Guest console disconnected");
        if(command.getBytes(StandardCharsets.UTF_8).length>1800)throw new IOException("Guest command too long");
        Pending p=new Pending("VP_CMD_"+UUID.randomUUID().toString().replace("-",""));
        synchronized(lock){pending=p;}
        String encoded=Base64.getEncoder().encodeToString(command.getBytes(StandardCharsets.UTF_8));
        String invoke=(root?"su 0 ":"")+"/system/bin/sh -c \"$(printf %s '"+encoded+"' | base64 -d)\"";
        // The terminal's 4096-byte canonical line limit also bounds transfer chunks.
        String line="\nstty -echo; printf '\\n"+p.marker+"_BEGIN\\n'; timeout "+Math.max(1,(timeoutMs+999)/1000)+" "+invoke+"; vp_rc=$?; printf '\\n"+p.marker+"_END %s\\n' \"$vp_rc\"\n";
        if(line.length()>3900)throw new IOException("Guest console frame too long");
        try {
            out.write(line.getBytes(StandardCharsets.US_ASCII));out.flush();
            if(!p.done.await(timeoutMs+3000,TimeUnit.MILLISECONDS)) {
                // A timed out shell could still consume later input. Require a VM restart.
                close();throw new IOException("Guest command timed out; Stop/Start the VM before retrying");
            }
            if(p.failure!=null)throw p.failure;
            return new Result(p.code,p.output.toString().trim());
        } finally {synchronized(lock){if(pending==p)pending=null;}}
    }
    void line(String raw) {
        String value=raw.replace("\r","");
        synchronized(lock){Pending p=pending;if(p==null)return;
            if(value.equals(p.marker+"_BEGIN")){p.begun=true;return;}
            if(!p.begun)return;
            if(value.startsWith(p.marker+"_END ")){
                try{p.code=Integer.parseInt(value.substring((p.marker+"_END ").length()));p.done.countDown();}catch(NumberFormatException ignored){}
                return;
            }
            if(p.output.length()<65536)p.output.append(value,0,Math.min(value.length(),65536-p.output.length())).append('\n');
        }
    }
    public void close(){closed=true;synchronized(lock){if(pending!=null){pending.failure=new IOException("Guest console disconnected");pending.done.countDown();}}try{out.close();}catch(IOException ignored){}}
}
