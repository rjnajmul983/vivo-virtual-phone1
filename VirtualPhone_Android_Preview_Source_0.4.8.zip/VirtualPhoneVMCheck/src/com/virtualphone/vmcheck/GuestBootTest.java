package com.virtualphone.vmcheck;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Boots an ephemeral Microdroid guest through the real system AVF API. */
final class GuestBootTest {
    interface Listener {void changed();}
    private static final String NAME="vp_boot_probe_v2";
    private static final String PREFS="vm-boot-test";
    private static final long BUDGET_MS=120_000;
    private static final ExecutorService RUNNER=Executors.newSingleThreadExecutor();
    private static WeakReference<Listener> listener=new WeakReference<>(null);
    private static volatile boolean running;
    private static final AtomicBoolean cancel=new AtomicBoolean();
    private static volatile JSONObject last;
    private static volatile CountDownLatch completion;
    private GuestBootTest() {}

    static synchronized void observe(Listener value){listener=new WeakReference<>(value);}
    static boolean running(){return running;}
    static synchronized JSONObject latest(Context context) {
        if(last==null) {
            String saved=context.getSharedPreferences(PREFS,0).getString("last",null);
            if(saved!=null)try {
                last=new JSONObject(saved);
                if("running".equals(last.optString("state"))) {
                    last.put("state","interrupted");last.put("payloadExecutionVerified",false);
                    last.put("detail","The application process ended before the test completed.");
                }
            } catch(Exception ignored){}
        }
        try{return last==null?null:new JSONObject(last.toString());}
        catch(Exception ignored){return null;}
    }
    private static synchronized void publish(Context context,JSONObject value) {
        last=value;
        context.getSharedPreferences(PREFS,0).edit().putString("last",value.toString()).apply();
        Listener target=listener.get();if(target!=null)target.changed();
    }
    static synchronized void start(Context context) {
        if(running)return;
        running=true;cancel.set(false);
        Context app=context.getApplicationContext();
        RUNNER.execute(()->execute(app));
        Listener target=listener.get();if(target!=null)target.changed();
    }
    static void cancel() {
        cancel.set(true);CountDownLatch latch=completion;if(latch!=null)latch.countDown();
        // The owner thread performs close/delete in finally. Never close on UI.
    }
    private static void invoke(Object object,String method,Class<?>[] types,Object... args)throws Exception {
        object.getClass().getMethod(method,types).invoke(object,args);
    }
    private static String describe(Throwable error) {
        while(error instanceof InvocationTargetException && ((InvocationTargetException)error).getTargetException()!=null)
            error=((InvocationTargetException)error).getTargetException();
        return DeviceProbe.describe(error);
    }
    private static void execute(Context context) {
        final long started=System.nanoTime();
        final CountDownLatch done=new CountDownLatch(1),stopped=new CountDownLatch(1);
        completion=done;
        final JSONObject result=new JSONObject();final Object lock=new Object();
        final JSONArray events=new JSONArray();
        final AtomicBoolean payloadStarted=new AtomicBoolean(),ready=new AtomicBoolean(),finished=new AtomicBoolean(),error=new AtomicBoolean();
        final int[] exit={-1};
        Object manager=null,vm=null;LogDrain console=null,logs=null;
        ExecutorService callbacks=Executors.newSingleThreadExecutor();
        String stage="preflight";boolean runRequested=false,timedOut=false,cleanupSucceeded=false;
        try {
            result.put("state","running");result.put("guest","Microdroid");
            result.put("protectedVm",false);result.put("memoryBytes",268435456);
            result.put("payload","libvp_guest_probe.so");result.put("expectedExitCode",42);
            result.put("payloadExecutionVerified",false);result.put("events",events);
            result.put("fullAndroidUiTested",false);result.put("rootAppsTested",false);result.put("guestGpuTested",false);
            result.put("phase",stage);publish(context,new JSONObject(result.toString()));
            if(Build.VERSION.SDK_INT<34)throw new IllegalStateException("AVF API 34 or newer is required");
            if(context.checkSelfPermission("android.permission.MANAGE_VIRTUAL_MACHINE")!=PackageManager.PERMISSION_GRANTED)
                throw new SecurityException("MANAGE_VIRTUAL_MACHINE permission is not granted");
            Class<?> managerClass=Class.forName("android.system.virtualmachine.VirtualMachineManager");
            @SuppressWarnings({"unchecked","rawtypes"}) Object obtained=context.getSystemService((Class)managerClass);
            manager=obtained;if(manager==null)throw new IllegalStateException("AVF manager unavailable");
            // Only remove this test's own exact-name disposable instance.
            Object old=managerClass.getMethod("get",String.class).invoke(manager,NAME);
            if(old!=null){old.getClass().getMethod("close").invoke(old);managerClass.getMethod("delete",String.class).invoke(manager,NAME);}
            if(cancel.get())throw new CancellationException("Cancelled before VM creation");
            stage="configure";
            Class<?> configClass=Class.forName("android.system.virtualmachine.VirtualMachineConfig");
            Class<?> builderClass=Class.forName("android.system.virtualmachine.VirtualMachineConfig$Builder");
            Object builder=builderClass.getConstructor(Context.class).newInstance(context);
            invoke(builder,"setProtectedVm",new Class<?>[]{boolean.class},false);
            invoke(builder,"setPayloadBinaryName",new Class<?>[]{String.class},"libvp_guest_probe.so");
            invoke(builder,"setMemoryBytes",new Class<?>[]{long.class},268435456L);
            invoke(builder,"setDebugLevel",new Class<?>[]{int.class},configClass.getField("DEBUG_LEVEL_FULL").getInt(null));
            invoke(builder,"setVmOutputCaptured",new Class<?>[]{boolean.class},true);
            Object config=builderClass.getMethod("build").invoke(builder);
            stage="create";vm=managerClass.getMethod("create",String.class,configClass).invoke(manager,NAME,config);
            Class<?> callbackClass=Class.forName("android.system.virtualmachine.VirtualMachineCallback");
            Object callback=Proxy.newProxyInstance(callbackClass.getClassLoader(),new Class<?>[]{callbackClass},(proxy,method,args)->{
                if(method.getDeclaringClass()==Object.class) {
                    if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);
                    if(method.getName().equals("equals"))return proxy==args[0];
                    return "VirtualPhone guest boot callback";
                }
                synchronized(lock) {
                    JSONObject event=new JSONObject();event.put("event",method.getName());
                    event.put("elapsedMs",(System.nanoTime()-started)/1_000_000);
                    switch(method.getName()) {
                        case "onPayloadStarted":payloadStarted.set(true);break;
                        case "onPayloadReady":ready.set(true);break;
                        case "onPayloadFinished":
                            exit[0]=((Number)args[1]).intValue();finished.set(true);event.put("exitCode",exit[0]);done.countDown();break;
                        case "onError":
                            error.set(true);event.put("errorCode",args[1]);event.put("message",String.valueOf(args[2]));done.countDown();break;
                        case "onStopped":event.put("reason",args[1]);stopped.countDown();done.countDown();break;
                    }
                    events.put(event);result.put("phase",method.getName());
                    result.put("payloadStarted",payloadStarted.get());result.put("payloadReady",ready.get());
                    publish(context,new JSONObject(result.toString()));
                }
                return null;
            });
            vm.getClass().getMethod("setCallback",Executor.class,callbackClass).invoke(vm,callbacks,callback);
            // Drain BOTH pipes before run, as required by AVF to avoid blocking
            // the guest on a full captured-output pipe.
            console=new LogDrain((InputStream)vm.getClass().getMethod("getConsoleOutput").invoke(vm),"vp-console");
            logs=new LogDrain((InputStream)vm.getClass().getMethod("getLogOutput").invoke(vm),"vp-log");
            console.start();logs.start();
            if(cancel.get())throw new CancellationException("Cancelled before VM run");
            stage="run";runRequested=true;
            synchronized(lock){result.put("runRequested",true);result.put("phase",stage);publish(context,new JSONObject(result.toString()));}
            vm.getClass().getMethod("run").invoke(vm);
            long remaining=BUDGET_MS-(System.nanoTime()-started)/1_000_000;
            timedOut=remaining<=0 || !done.await(Math.max(1,remaining),TimeUnit.MILLISECONDS);
            if(!timedOut && !cancel.get())stopped.await(5,TimeUnit.SECONDS);
        } catch(Throwable failure) {
            synchronized(lock){try{result.put("failurePhase",stage);result.put("failure",describe(failure));}catch(Exception ignored){}}
            error.set(true);
        } finally {
            // close() stops only this disposable VM. It never changes host root,
            // permissions, other VMs, imported apps or user-selected files.
            if(vm!=null)try{vm.getClass().getMethod("close").invoke(vm);}catch(Throwable failure){
                synchronized(lock){try{result.put("closeError",describe(failure));}catch(Exception ignored){}}
            }
            // Stop accepting new Binder callbacks before shutting down their
            // executor, so a late onStopped cannot hit a rejected executor.
            if(vm!=null)try{vm.getClass().getMethod("clearCallback").invoke(vm);}catch(Throwable ignored){}
            if(console!=null)console.finish();if(logs!=null)logs.finish();
            if(manager!=null && vm!=null)try{manager.getClass().getMethod("delete",String.class).invoke(manager,NAME);cleanupSucceeded=true;}
            catch(Throwable failure){synchronized(lock){try{result.put("cleanupError",describe(failure));}catch(Exception ignored){}}}
            // Flush earlier queued callbacks before taking the final snapshot.
            callbacks.shutdown();try{callbacks.awaitTermination(2,TimeUnit.SECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
            synchronized(lock) {
                try {
                    boolean verified=payloadStarted.get()&&ready.get()&&finished.get()&&exit[0]==42&&!error.get()&&!cancel.get()&&!timedOut;
                    result.put("state",cancel.get()?"cancelled":timedOut?"timeout":verified?"completed":"failed");
                    result.put("runRequested",runRequested);result.put("timedOut",timedOut);
                    result.put("cleanupSucceeded",cleanupSucceeded);
                    result.put("payloadStarted",payloadStarted.get());result.put("payloadReady",ready.get());
                    result.put("payloadFinished",finished.get());result.put("exitCode",exit[0]);
                    result.put("payloadExecutionVerified",verified);
                    result.put("elapsedMs",(System.nanoTime()-started)/1_000_000);
                    if(console!=null)result.put("consoleTail",console.tail());
                    if(logs!=null)result.put("logTail",logs.tail());
                    JSONObject guest=console==null?null:console.guest();
                    if(guest==null && logs!=null)guest=logs.guest();
                    if(guest!=null)result.put("guestReport",guest);
                    result.put("guestReportCaptured",guest!=null);
                    result.put("scope","A native Microdroid boot/exit test only. No full Android UI, app root manager, GPU passthrough, game/browser compatibility or production isolation certification.");
                } catch(Exception ignored){}
                running=false;completion=null;
                publish(context,result);
            }
        }
    }
    private static final class LogDrain {
        private final InputStream stream;private final StringBuilder buffer=new StringBuilder();
        private final AtomicBoolean stop=new AtomicBoolean();private final Thread thread;
        private JSONObject marker;
        LogDrain(InputStream input,String name){stream=input;thread=new Thread(this::read,name);thread.setDaemon(true);}
        void start(){thread.start();}
        private void read() {
            byte[] bytes=new byte[2048];long stopAt=Long.MAX_VALUE;
            try {
                while(true) {
                    if(stop.get() && stopAt==Long.MAX_VALUE)stopAt=System.nanoTime()+300_000_000L;
                    int available=stream.available();
                    if(available>0) {
                        int n=stream.read(bytes,0,Math.min(available,bytes.length));if(n<0)break;
                        synchronized(this) {
                            buffer.append(new String(bytes,0,n,StandardCharsets.UTF_8));
                            int from=0;
                            while(true) {
                                int start=buffer.indexOf("VP_GUEST_PROBE ",from);if(start<0)break;
                                int end=buffer.indexOf("\n",start);if(end<0)break;
                                try {
                                    JSONObject value=new JSONObject(buffer.substring(start+15,end).trim());
                                    if("vp_guest_v2".equals(value.optString("marker")) && value.optInt("expectedExitCode")==42)marker=value;
                                } catch(Exception ignored){}
                                from=end+1;
                            }
                            if(buffer.length()>16_384)buffer.delete(0,buffer.length()-16_384);
                        }
                    } else {if(System.nanoTime()>=stopAt)break;Thread.sleep(20);}
                }
            } catch(Throwable ignored) {} finally {try{stream.close();}catch(Exception ignored){}}
        }
        void finish(){stop.set(true);try{thread.join(1500);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
        synchronized String tail(){return buffer.toString();}
        synchronized JSONObject guest(){return marker;}
    }
}
