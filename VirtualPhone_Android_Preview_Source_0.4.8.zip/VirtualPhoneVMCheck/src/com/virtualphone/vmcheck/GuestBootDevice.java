package com.virtualphone.vmcheck;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Selects a guest PCI boot-device path from evidence, not from the host's physical storage. */
final class GuestBootDevice {
    private static final Pattern PLATFORM_PCI=Pattern.compile(
            "/devices/platform/([0-9a-fA-F]{4,16}\\.pci)/pci[0-9a-fA-F]{4}:[0-9a-fA-F]{2}/");
    static final class Choice {
        final String path,source;
        Choice(String path,String source){this.path=path;this.source=source;}
    }
    private GuestBootDevice(){}
    static Choice choose(String priorGuestConsole,String manufacturer,String model) {
        Matcher found=PLATFORM_PCI.matcher(priorGuestConsole==null?"":priorGuestConsole);
        if(found.find())return new Choice(found.group(1),"previous_guest_kernel_pci_path");
        // Specific physical-user result, not a guessed generic OEM hardware profile.
        if("vivo".equalsIgnoreCase(manufacturer)&&"V2507A".equalsIgnoreCase(model))
            return new Choice("2e000000.pci","observed_vivo_V2507A_guest_pci_path");
        return new Choice("10000.pci","original_cuttlefish_qemu_default");
    }
}
