package com.virtualphone.vmcheck;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Locale;
import java.util.UUID;

/** Guest-only screenshot transfer across the existing framed serial console. */
final class GuestScreenCapture {
    private static final int CHUNK=32768,MAX_BYTES=6*1024*1024;
    interface Progress {void update(int received,int total);}
    private GuestScreenCapture(){}
    static byte[] decodeLines(String output,int expected)throws IOException {
        StringBuilder base64=new StringBuilder();
        for(String line:output.split("\\r?\\n")){
            String value=line.trim();
            if(value.matches("[A-Za-z0-9+/]{2,76}={0,2}")&&value.length()%4==0)
                base64.append(value);
        }
        try{
            byte[] bytes=Base64.getDecoder().decode(base64.toString());
            if(bytes.length!=expected)throw new IOException("Guest base64 chunk length mismatch: "+bytes.length+" != "+expected);
            return bytes;
        }catch(IllegalArgumentException error){throw new IOException("Invalid screenshot transfer encoding",error);}
    }
    private static int size(String output)throws IOException {
        for(String line:output.split("\\r?\\n")){
            String value=line.trim();
            if(value.matches("[0-9]{1,8}")){
                try{
                    int n=Integer.parseInt(value);
                    if(n>=8&&n<=MAX_BYTES)return n;
                }catch(NumberFormatException ignored){}
            }
        }
        throw new IOException("Guest screenshot has no valid size (limit 6 MiB): "+output);
    }
    private static String sha256(byte[] data)throws Exception {
        StringBuilder hex=new StringBuilder();
        for(byte b:MessageDigest.getInstance("SHA-256").digest(data))hex.append(String.format(Locale.ROOT,"%02x",b&255));
        return hex.toString();
    }
    static byte[] read(GuestConsole console,Progress progress)throws Exception {
        String path="/data/local/tmp/vp-screen-"+UUID.randomUUID().toString().replace("-","")+".png";
        String quoted=GuestConsole.quote(path);
        try {
            GuestConsole.Result shot=console.command("screencap -p "+quoted+" && wc -c < "+quoted,false,30000);
            if(shot.code==124)throw new IOException("Guest screencap timed out after 30 seconds: possible graphics/display stall; run Graphics test");
            int length=size(shot.require().output);
            ByteArrayOutputStream collected=new ByteArrayOutputStream(length);
            for(int offset=0,index=0;offset<length;offset+=CHUNK,index++){
                int expected=Math.min(CHUNK,length-offset);byte[] bytes=null;IOException last=null;
                for(int retry=0;retry<2&&bytes==null;retry++){
                    String out=console.command("dd if="+quoted+" bs="+CHUNK+" skip="+index+" count=1 2>/dev/null | base64",false,15000).require().output;
                    try{bytes=decodeLines(out,expected);}catch(IOException e){last=e;}
                }
                if(bytes==null)throw last;
                collected.write(bytes);progress.update(collected.size(),length);
            }
            byte[] image=collected.toByteArray();
            String expectedHash=sha256(image);
            String actual=console.command("sha256sum "+quoted,false,15000).require().output;
            if(!actual.contains(expectedHash))throw new IOException("Guest screenshot checksum mismatch");
            if(image.length<8||image[0]!=(byte)137||image[1]!=80||image[2]!=78||image[3]!=71)
                throw new IOException("Guest screenshot is not PNG");
            return image;
        }finally{try{console.command("rm -f "+quoted,false,5000);}catch(Exception ignored){}}
    }
}
