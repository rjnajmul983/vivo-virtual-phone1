package com.virtualphone.vmcheck;

/** Mirrors ART descriptor-prefix coverage; does not claim a running process applied it. */
final class AvfSetupState {
    static boolean covered(String setting,String descriptor){
        if(setting==null)return false;
        if(setting.equals("*"))return true;
        for(String prefix:setting.split(",",-1))if(!prefix.isEmpty()&&descriptor.startsWith(prefix))return true;
        return false;
    }
}
