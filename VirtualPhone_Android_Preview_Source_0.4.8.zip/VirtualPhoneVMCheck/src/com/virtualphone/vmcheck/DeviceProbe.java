package com.virtualphone.vmcheck;

import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.opengl.*;
import android.os.Build;
import android.os.StatFs;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import org.json.JSONObject;
import java.io.File;
import java.io.FileDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Read-only observations. No su, pm grant, VM creation, shell or network calls. */
final class DeviceProbe {
    private static final String MANAGE = "android.permission.MANAGE_VIRTUAL_MACHINE";
    private static final String CUSTOM = "android.permission.USE_CUSTOM_VIRTUAL_MACHINE";
    private DeviceProbe() {}

    static JSONObject run(Context context) throws Exception {
        JSONObject report = new JSONObject();
        report.put("schema",1); report.put("app","VirtualPhone Android Preview 0.4.8 / capability view");
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.ROOT);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        report.put("timeUtc",format.format(new Date()));
        JSONObject device=new JSONObject();
        device.put("manufacturer",Build.MANUFACTURER);device.put("brand",Build.BRAND);
        device.put("model",Build.MODEL);device.put("android",Build.VERSION.RELEASE);
        device.put("sdk",Build.VERSION.SDK_INT);device.put("securityPatch",Build.VERSION.SECURITY_PATCH);
        device.put("abis",android.text.TextUtils.join(", ",Build.SUPPORTED_ABIS));
        device.put("kernel",System.getProperty("os.version","unknown"));
        device.put("rootTest","not attempted; no root or elevation requested");
        try {device.put("pageSizeBytes",Os.sysconf(OsConstants._SC_PAGESIZE));}
        catch(Exception e){device.put("pageSizeError",describe(e));}
        ActivityManager.MemoryInfo memory=new ActivityManager.MemoryInfo();
        ((ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(memory);
        device.put("totalRamBytes",memory.totalMem);device.put("availableRamBytes",memory.availMem);
        StatFs fs=new StatFs(context.getFilesDir().getAbsolutePath());
        device.put("dataVolumeBytes",fs.getTotalBytes());device.put("availableStorageBytes",fs.getAvailableBytes());
        report.put("device",device);

        PackageManager pm=context.getPackageManager();
        boolean feature=pm.hasSystemFeature("android.software.virtualization_framework");
        boolean manage=context.checkSelfPermission(MANAGE)==PackageManager.PERMISSION_GRANTED;
        boolean custom=context.checkSelfPermission(CUSTOM)==PackageManager.PERMISSION_GRANTED;
        JSONObject avf=new JSONObject();
        avf.put("advertisedFeature",feature);
        avf.put("managePermission",permission(context,MANAGE));
        avf.put("customVmPermission",permission(context,CUSTOM));
        avf.put("vmToolVisible",new File("/apex/com.android.virt/bin/vm").exists());
        avf.put("crosvmVisible",new File("/apex/com.android.virt/bin/crosvm").exists());
        avf.put("managerProbe",manager(context));
        report.put("avf",avf);

        JSONObject kvm=new JSONObject();
        boolean opened=false;FileDescriptor fd=null;
        try {
            fd=Os.open("/dev/kvm",OsConstants.O_RDWR|OsConstants.O_CLOEXEC|OsConstants.O_NONBLOCK,0);
            opened=true;kvm.put("openReadWrite","opened");
        } catch(ErrnoException e) {
            kvm.put("openReadWrite","denied or unavailable");kvm.put("errno",e.errno);
            kvm.put("detail",describe(e));
        } catch(Exception e) { kvm.put("openReadWrite","not confirmed");kvm.put("detail",describe(e)); }
        finally { if(fd!=null)try{Os.close(fd);}catch(ErrnoException ignored){} }
        kvm.put("vmCreationAttempted",false);
        kvm.put("note","Raw KVM access and AVF-broker access are different. This open check cannot prove or disprove full VM support.");
        report.put("kvm",kvm);
        report.put("hostGraphics",graphics());
        String status=ProbeStatus.code(feature,manage,custom,opened);
        report.put("status",status);
        report.put("guestBootTested",false);report.put("guestRootTested",false);
        report.put("guestGpuTested",false);report.put("freeFireTested",false);
        report.put("chromeTested",false);
        report.put("scope","Capability observations plus an optional native Microdroid boot test. No full Android GUI image, game, root-app or host-identity-hiding compatibility is certified.");
        report.put("privacy","No Android ID, IMEI, serial, MAC, contacts, accounts, app list or host user file contents collected. INTERNET is used by the Android image installer for public metadata/archive downloads; reports are not uploaded.");
        return report;
    }

    private static JSONObject permission(Context context,String name) throws Exception {
        JSONObject value=new JSONObject();
        try {
            android.content.pm.PermissionInfo p=context.getPackageManager().getPermissionInfo(name,0);
            value.put("defined",true);value.put("protectionLevel",p.protectionLevel);
        } catch(PackageManager.NameNotFoundException e) {value.put("defined",false);}
        value.put("granted",context.checkSelfPermission(name)==PackageManager.PERMISSION_GRANTED);
        return value;
    }

    @SuppressWarnings({"unchecked","rawtypes"})
    private static JSONObject manager(Context context) throws Exception {
        JSONObject value=new JSONObject();
        try {
            Class<?> clazz=Class.forName("android.system.virtualmachine.VirtualMachineManager");
            value.put("classVisible",true);
            Object manager=context.getSystemService((Class)clazz);
            value.put("instanceAvailable",manager!=null);
            if(manager!=null) {
                Method method=clazz.getMethod("getCapabilities");
                value.put("capabilities",((Number)method.invoke(manager)).intValue());
            }
        } catch(Throwable e) {
            value.put("probeError",describe(e));
            value.put("interpretation","A missing or restricted System API does not by itself establish hardware support or lack of support.");
        }
        return value;
    }

    private static JSONObject graphics() throws Exception {
        JSONObject value=new JSONObject();
        EGLDisplay display=EGL14.EGL_NO_DISPLAY; EGLContext context=EGL14.EGL_NO_CONTEXT;
        EGLSurface surface=EGL14.EGL_NO_SURFACE;boolean initialized=false;
        try {
            display=EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] version=new int[2];
            if(display==EGL14.EGL_NO_DISPLAY || !EGL14.eglInitialize(display,version,0,version,1))
                throw new IllegalStateException("EGL initialization unavailable");
            initialized=true;
            EGLConfig[] config=new EGLConfig[1];int[] count=new int[1];
            int[] attributes={EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE,EGL14.EGL_PBUFFER_BIT,EGL14.EGL_NONE};
            if(!EGL14.eglChooseConfig(display,attributes,0,config,0,1,count,0)||count[0]<1)
                throw new IllegalStateException("No EGL pbuffer config");
            context=EGL14.eglCreateContext(display,config[0],EGL14.EGL_NO_CONTEXT,
                new int[]{EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE},0);
            surface=EGL14.eglCreatePbufferSurface(display,config[0],
                new int[]{EGL14.EGL_WIDTH,1,EGL14.EGL_HEIGHT,1,EGL14.EGL_NONE},0);
            if(context==EGL14.EGL_NO_CONTEXT||surface==EGL14.EGL_NO_SURFACE||
                !EGL14.eglMakeCurrent(display,surface,surface,context))
                throw new IllegalStateException("EGL context unavailable");
            value.put("vendor",GLES20.glGetString(GLES20.GL_VENDOR));
            value.put("renderer",GLES20.glGetString(GLES20.GL_RENDERER));
            value.put("version",GLES20.glGetString(GLES20.GL_VERSION));
        } catch(Throwable e) {value.put("probeError",describe(e));}
        finally {
            if(initialized) {
                EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT);
                if(surface!=EGL14.EGL_NO_SURFACE)EGL14.eglDestroySurface(display,surface);
                if(context!=EGL14.EGL_NO_CONTEXT)EGL14.eglDestroyContext(display,context);
                EGL14.eglTerminate(display);EGL14.eglReleaseThread();
            }
        }
        value.put("scope","Host renderer only; VM graphics acceleration is not tested.");
        return value;
    }

    static String describe(Throwable error) {
        if(error instanceof InvocationTargetException && ((InvocationTargetException)error).getTargetException()!=null)
            error=((InvocationTargetException)error).getTargetException();
        String value=error.getClass().getSimpleName()+": "+String.valueOf(error.getMessage());
        return value.length()>400?value.substring(0,400):value;
    }
}
