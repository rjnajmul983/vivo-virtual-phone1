package com.virtualphone.vmcheck;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MotionEvent;
import org.json.*;
import java.io.*;
import java.lang.ref.WeakReference;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** A real custom-image AVF guest. Custom Android VMs do not use Microdroid callbacks. */
final class AndroidVm {
    interface Listener {void changed();}
    private static WeakReference<Listener> listener=new WeakReference<>(null);
    private static final ExecutorService worker=Executors.newSingleThreadExecutor();
    private static final ExecutorService commands=Executors.newSingleThreadExecutor();
    private static volatile GuestConsole console;
    private static volatile boolean transferring;
    private static volatile Object vm;
    private static volatile boolean busy,installing,active;
    private static volatile String status="Android image প্রস্তুত করা বাকি।";
    private static final AtomicBoolean cancel=new AtomicBoolean();
    // Console input changes AVF config compatibility. Keep existing guest disk paths.
    private static final String NAME="vp_android_console_v2";
    private static final long MIB=1024L*1024L;
    static int memoryMiB(Context c){
        int mb=c.getSharedPreferences("android-vm-profile",0).getInt("memoryMiB",2048);
        return mb==3072||mb==4096?mb:2048;
    }
    static synchronized boolean setMemoryMiB(Context c,int mb){
        if(busy||active||(mb!=2048&&mb!=3072&&mb!=4096))return false;
        c.getSharedPreferences("android-vm-profile",0).edit().putInt("memoryMiB",mb).apply();
        note("VM-এর পরবর্তী Start-এ "+(mb/1024)+" GB RAM ব্যবহার হবে। Guest disk/data অপরিবর্তিত।");
        return true;
    }
    private static String profileName(int memoryMiB){
        return memoryMiB==2048?NAME:NAME+"_ram"+memoryMiB;
    }
    private static JSONObject report=new JSONObject();
    private static boolean initialized;
    static synchronized void initialize(Context c) {
        if(initialized)return;initialized=true;
        String saved=c.getSharedPreferences("android-vm-report",0).getString("last",null);
        if(saved!=null)try{report=new JSONObject(saved);if(report.has("installerError"))status="আগের setup ব্যর্থ হয়েছিল। API check চাপুন বা রিপোর্ট দেখুন।";}catch(JSONException ignored){}
    }
    static synchronized void observe(Listener l){listener=new WeakReference<>(l);}
    static boolean busy(){return busy;}
    static boolean active(){return active;}
    static boolean transferring(){return transferring;}
    static String status(){return status;}
    static synchronized String report(){return report.toString();}
    static synchronized void put(String key,Object value){try{report.put(key,value);}catch(JSONException ignored){}}
    static synchronized void recordSessionCheck(Context c,JSONObject api){
        report=new JSONObject();put("app","VirtualPhone Android Preview 0.4.8");put("apiCheck",api);put("instrumentationSessionActive",VmSessionInstrumentation.active());
        c.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();
        note(api.optBoolean("passed")?"প্রয়োজনীয় API পাওয়া যাচ্ছে। Display-এর পরীক্ষা VM start-এর পরে হবে।":"ADB session-এর API report প্রস্তুত। Copy report দিন।");
    }
    static void note(String text){status=text;Listener l=listener.get();if(l!=null)l.changed();}
    static Object call(Object o,String method,Class<?>[] types,Object... args)throws Exception {return AvfReflection.invoke(o,method,types,args);}
    static String error(Throwable e){while(e instanceof InvocationTargetException&&((InvocationTargetException)e).getTargetException()!=null)e=((InvocationTargetException)e).getTargetException();return DeviceProbe.describe(e);}
    static synchronized void install(Context c) {
        if(busy||active)return;busy=true;installing=true;cancel.set(false);Context app=c.getApplicationContext();
        worker.execute(()->{try{synchronized(AndroidVm.class){report=new JSONObject();}put("app","VirtualPhone Android Preview 0.4.8");preflight(app);AndroidImageStore.install(app,new AndroidImageStore.Status(){public void update(String s){note(s);}public boolean cancelled(){return cancel.get();}});}catch(Throwable e){put("installerError",error(e));app.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();note("Image প্রস্তুত হয়নি: "+error(e));}finally{busy=false;installing=false;note(status);}});
    }
    private static void preflight(Context c)throws Exception {
        JSONObject api=AvfApiCheck.run(c);put("apiCheck",api);put("customApiPreflightPassed",api.getBoolean("passed"));
        if(!api.getBoolean("passed"))throw new IllegalStateException("ফোনের VM API-এর কিছু অংশ অ্যাপ থেকে পাওয়া যাচ্ছে না। API check-এর রিপোর্ট দেখুন।");
    }
    static synchronized void checkApi(Context c,CommandResult result){
        if(busy||active)return;busy=true;Context app=c.getApplicationContext();
        worker.execute(()->{String output;try{
            synchronized(AndroidVm.class){report=new JSONObject();}
            put("app","VirtualPhone Android Preview 0.4.8");preflight(app);output="প্রয়োজনীয় VM API পাওয়া যাচ্ছে। Display access VM চালুর পরে পরীক্ষা হবে। Android image প্রস্তুত করুন।";note(output);
        }catch(Throwable e){put("installerError",error(e));output="API check ব্যর্থ। Copy report দিন।\n"+error(e);note(output);}
        finally{busy=false;app.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();}
        result.complete(output);note(status);});
    }
    static synchronized void start(Context c) {
        if(busy||active)return;
        if(!AndroidImageStore.ready(c)){note("আগে Android image প্রস্তুত করুন।");return;}
        initialize(c);busy=true;cancel.set(false);Context app=c.getApplicationContext();
        worker.execute(()->run(app));
    }
    static void stop(){cancel.set(true);note(installing?"Download বন্ধ হচ্ছে…":"Android বন্ধ হচ্ছে…");}
    private static void run(Context context) {
        Object owned=null;ExecutorService callbacks=Executors.newSingleThreadExecutor();
        CountDownLatch stopped=new CountDownLatch(1);List<Drain> drains=new ArrayList<>();
        String nonce=UUID.randomUUID().toString().replace("-","");long started=SystemClock.elapsedRealtime();
        try {
            synchronized(AndroidVm.class){report=new JSONObject();}
            int memoryMiB=memoryMiB(context);long memoryBytes=memoryMiB*MIB;String vmName=profileName(memoryMiB);
            put("app","VirtualPhone Android Preview 0.4.8");put("guest","AOSP Cuttlefish ARM64 Android 17");put("imageBuild","16644040");
            put("protectedVm",false);put("memoryBytes",memoryBytes);put("virtualMachineProfile",vmName);put("androidBootCompleted",false);
            put("vmRunReturned",false);put("displaySurfaceConnected",false);
            JSONObject host=new JSONObject();host.put("manufacturer",android.os.Build.MANUFACTURER);host.put("model",android.os.Build.MODEL);host.put("android",android.os.Build.VERSION.RELEASE);host.put("sdk",android.os.Build.VERSION.SDK_INT);put("host",host);
            android.app.ActivityManager activity=(android.app.ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);
            if(activity!=null){android.app.ActivityManager.MemoryInfo memory=new android.app.ActivityManager.MemoryInfo();activity.getMemoryInfo(memory);
                JSONObject capacity=new JSONObject();capacity.put("availableBytes",memory.availMem);capacity.put("totalBytes",memory.totalMem);
                capacity.put("lowMemory",memory.lowMemory);capacity.put("lowMemoryThresholdBytes",memory.threshold);put("hostMemoryAtStart",capacity);
                if(memory.lowMemory||memory.availMem<memoryBytes+768*MIB)
                    throw new IllegalStateException("VM-এর জন্য পর্যাপ্ত host RAM নেই। RAM কমিয়ে আবার Start করুন (free host memory="+(memory.availMem/MIB)+" MiB, selected="+memoryMiB+" MiB)।");}
            put("guestCommandImplemented",true);put("selectedApkFileImportImplemented",true);put("perAppRootManagerImplemented",false);
            put("guestUiFrameVerified",false);put("rootAppsTested",false);put("chromeTested",false);put("freeFireTested",false);
            put("guestSelinux","permissive development image");put("sharedHostDirectories",new JSONArray());
            for(String p:new String[]{"android.permission.MANAGE_VIRTUAL_MACHINE","android.permission.USE_CUSTOM_VIRTUAL_MACHINE"})
                if(context.checkSelfPermission(p)!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new SecurityException(p+" is not granted");
            preflight(context);
            if(GuestBootTest.running())throw new IllegalStateException("Microdroid পরীক্ষা শেষ করে আবার Start করুন।");
            put("displayServiceBeforeVmRun",AndroidDisplay.observeService(false));
            note("পূর্ণ Android VM তৈরি হচ্ছে…");
            Class<?> managerClass=Class.forName("android.system.virtualmachine.VirtualMachineManager");
            @SuppressWarnings({"unchecked","rawtypes"}) Object manager=context.getSystemService((Class)managerClass);
            if(manager==null)throw new IllegalStateException("AVF manager unavailable");
            Object config=config(context,nonce,vmName,memoryBytes);
            Class<?> configClass=Class.forName("android.system.virtualmachine.VirtualMachineConfig");
            owned=managerClass.getMethod("get",String.class).invoke(manager,vmName);
            if(owned==null)owned=managerClass.getMethod("create",String.class,configClass).invoke(manager,vmName,config);
            else call(owned,"setConfig",new Class<?>[]{configClass},config);
            vm=owned;
            console=new GuestConsole((OutputStream)call(owned,"getConsoleInput",new Class<?>[]{}));
            Class<?> callbackClass=Class.forName("android.system.virtualmachine.VirtualMachineCallback");
            Object callback=Proxy.newProxyInstance(callbackClass.getClassLoader(),new Class<?>[]{callbackClass},(proxy,method,args)->{
                if(method.getDeclaringClass()==Object.class){if(method.getName().equals("hashCode"))return System.identityHashCode(proxy);if(method.getName().equals("equals"))return proxy==args[0];return "VirtualPhone Android callback";}
                if(method.getName().equals("onStopped")){put("stopReason",args[1]);stopped.countDown();}
                if(method.getName().equals("onError")){put("errorCode",args[1]);put("error",String.valueOf(args[2]));stopped.countDown();}
                return null;
            });
            call(owned,"setCallback",new Class<?>[]{Executor.class,callbackClass},callbacks,callback);
            for(String pipe:new String[]{"getConsoleOutput","getLogOutput"}) {
                Drain drain=new Drain((InputStream)call(owned,pipe,new Class<?>[]{}),pipe,nonce);drains.add(drain);drain.start();
            }
            if(cancel.get())return;
            call(owned,"run",new Class<?>[]{});active=true;busy=false;put("runRequested",true);put("vmRunReturned",true);
            put("displayServiceAfterVmRun",AndroidDisplay.observeService(false));
            note("Android boot হচ্ছে… প্রথমবার কিছু সময় লাগতে পারে।");
            long savedAt=0;
            while(!cancel.get()&&!stopped.await(300,TimeUnit.MILLISECONDS)) {
                put("elapsedMs",SystemClock.elapsedRealtime()-started);
                if(SystemClock.elapsedRealtime()-savedAt>3000) {
                    for(Drain d:drains)put(d.name+"Tail",d.tail());
                    context.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();savedAt=SystemClock.elapsedRealtime();
                }
                if(SystemClock.elapsedRealtime()-started>240000&&!bootComplete()&&!transferring){put("bootBudgetExceeded",true);note("৪ মিনিটে Android boot সম্পূর্ণ হয়নি। রিপোর্ট সংরক্ষণ করে VM বন্ধ করুন।");}
            }
        } catch(Throwable e){put("error",error(e));note("Android চালু হয়নি: "+error(e));}
        finally {
            active=false;
            GuestConsole old=console;console=null;if(old!=null)old.close();
            AndroidDisplay.remove();
            // Closing this app-owned VM stops it. Persistent guest volumes are retained.
            if(owned!=null){try{call(owned,"close",new Class<?>[]{});}catch(Throwable e){put("closeError",error(e));}}
            vm=null;
            for(Drain d:drains){
                d.finish();String tail=d.tail();put(d.name+"Tail",tail);
                if(d.name.equals("getConsoleOutput")){
                    put("guestKernelPanicDetected",tail.contains("Kernel panic - not syncing"));
                    put("guestSuperByNameMissing",tail.contains("realpath failed: /dev/block/by-name/super"));
                }
            }
            callbacks.shutdownNow();busy=false;put("elapsedMs",SystemClock.elapsedRealtime()-started);
            try{context.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();}catch(Throwable ignored){}
            String failure; synchronized(AndroidVm.class){failure=report.optString("error","");}
            if(!failure.isEmpty())note("Android চালু হয়নি: "+failure);else note("Android বন্ধ। Guest-এর ডাটা রাখা হয়েছে।");
        }
    }
    private static synchronized boolean bootComplete(){return report.optBoolean("androidBootCompleted");}
    private static Object config(Context c,String nonce,String vmName,long memoryBytes)throws Exception {
        File dir=AndroidImageStore.directory(c);
        String base="android.system.virtualmachine.VirtualMachineCustomImageConfig";
        Class<?> customClass=Class.forName(base),builderClass=Class.forName(base+"$Builder"),diskClass=Class.forName(base+"$Disk"),partitionClass=Class.forName(base+"$Partition");
        Object custom=AvfReflection.builder(builderClass,Context.class,c);
        call(custom,"setName",new Class<?>[]{String.class},vmName);
        call(custom,"setKernelPath",new Class<?>[]{String.class},new File(dir,"Image").getPath());
        call(custom,"setInitrdPath",new Class<?>[]{String.class},new File(dir,"launch-initrd.img").getPath());
        Object disk=diskClass.getMethod("RWDisk",String.class).invoke(null,new Object[]{null});
        for(String name:new String[]{"super","metadata","userdata","misc","frp"}) {
            File image=new File(dir,name.equals("super")?"super.raw":name+".img");
            Object part=partitionClass.getConstructor(String.class,String.class,boolean.class,String.class).newInstance(name,image.getPath(),!name.equals("super"),null);
            call(disk,"addPartition",new Class<?>[]{partitionClass},part);
        }
        call(custom,"addDisk",new Class<?>[]{diskClass},disk);
        // No host folder, camera, microphone, SIM, or physical device is shared.
        call(custom,"useTouch",new Class<?>[]{boolean.class},true);call(custom,"useKeyboard",new Class<?>[]{boolean.class},true);
        call(custom,"useNetwork",new Class<?>[]{boolean.class},true);
        Class<?> displayClass=Class.forName(base+"$DisplayConfig"),displayBuilder=Class.forName(base+"$DisplayConfig$Builder");
        Object display=AvfReflection.builder(displayBuilder,Context.class,c);
        for(String method:new String[]{"setWidth","setHeight","setHorizontalDpi","setVerticalDpi","setRefreshRate"}) {
            int value=method.equals("setWidth")?720:method.equals("setHeight")?1280:method.equals("setRefreshRate")?60:280;
            call(display,method,new Class<?>[]{int.class},value);
        }
        call(custom,"setDisplayConfig",new Class<?>[]{displayClass},call(display,"build",new Class<?>[]{}));
        Class<?> gpuClass=Class.forName(base+"$GpuConfig"),gpuBuilder=Class.forName(base+"$GpuConfig$Builder");
        Object gpu=AvfReflection.builder(gpuBuilder,Context.class,c);call(gpu,"setBackend",new Class<?>[]{String.class},"2D");
        call(custom,"setGpuConfig",new Class<?>[]{gpuClass},call(gpu,"build",new Class<?>[]{}));
        JSONObject params=new JSONObject(AndroidImageStore.assetText(c,"android/boot-params.json"));Map<String,String> bootParams=new LinkedHashMap<>();
        Iterator<String> keys=params.keys();while(keys.hasNext()){String key=keys.next();bootParams.put(key,params.getString(key));}
        String prior=c.getSharedPreferences("android-vm-report",0).getString("last",null),consoleTail="";
        if(prior!=null)try{consoleTail=new JSONObject(prior).optString("getConsoleOutputTail","");}catch(JSONException ignored){}
        GuestBootDevice.Choice guestPci=GuestBootDevice.choose(consoleTail,android.os.Build.MANUFACTURER,android.os.Build.MODEL);
        bootParams.put("androidboot.boot_devices",guestPci.path);
        put("guestBootDevice",guestPci.path);
        put("guestBootDeviceSource",guestPci.source);
        bootParams.put("androidboot.vp_nonce",nonce);
        bootParams.put("androidboot.console","hvc0");bootParams.put("androidboot.serialconsole","1");
        String serial=c.getSharedPreferences("android-vm-identity",0).getString("serial",null);
        if(serial==null){serial="VP"+UUID.randomUUID().toString().replace("-","").substring(0,14);c.getSharedPreferences("android-vm-identity",0).edit().putString("serial",serial).commit();}
        bootParams.put("androidboot.serialno",serial);put("guestSerial",serial);
        BootImages.bootconfig(new File(dir,"initrd.img"),new File(dir,"launch-initrd.img"),bootParams);
        call(custom,"addParam",new Class<?>[]{String.class},"bootconfig");
        Class<?> configClass=Class.forName("android.system.virtualmachine.VirtualMachineConfig"),bClass=Class.forName(configClass.getName()+"$Builder");
        Object b=AvfReflection.builder(bClass,Context.class,c);call(b,"setProtectedVm",new Class<?>[]{boolean.class},false);
        call(b,"setCustomImageConfig",new Class<?>[]{customClass},call(custom,"build",new Class<?>[]{}));
        call(b,"setMemoryBytes",new Class<?>[]{long.class},memoryBytes);call(b,"setDebugLevel",new Class<?>[]{int.class},configClass.getField("DEBUG_LEVEL_FULL").getInt(null));
        call(b,"setCpuTopology",new Class<?>[]{int.class},configClass.getField("CPU_TOPOLOGY_MATCH_HOST").getInt(null));
        call(b,"setVmOutputCaptured",new Class<?>[]{boolean.class},true);
        call(b,"setVmConsoleInputSupported",new Class<?>[]{boolean.class},true);call(b,"setConsoleInputDevice",new Class<?>[]{String.class},"hvc0");return call(b,"build",new Class<?>[]{});
    }
    interface CommandResult {void complete(String output);}
    static void diagnoseGraphics(Context c,CommandResult result) {
        if(!active||console==null||transferring){result.complete("আগে VM চালু করুন এবং চলমান কাজ শেষ হতে দিন।");return;}
        if(!bootComplete()){result.complete("Android system boot সম্পূর্ণ হওয়ার পরে Graphics test চালান।");return;}
        GuestConsole session=console;transferring=true;Context app=c.getApplicationContext();
        note("Guest graphics diagnostic শুরু হয়েছে…");
        commands.execute(()->{
            String summary;
            try {
                JSONObject detail=GuestGraphicsDiagnostics.inspect(session,
                    title->note("Guest graphics পরীক্ষা: "+title));
                put("guestGraphicsDiagnostics",detail);
                put("guestGraphicsDiagnosticsCompleted",!detail.optBoolean("probeStoppedBecauseConsoleLost"));
                summary="Graphics diagnostic সম্পন্ন। Copy report পাঠান।\n\n"+detail.toString(2);
            }catch(Throwable error){
                summary="Graphics diagnostic ব্যর্থ: "+error(error);
                put("guestGraphicsDiagnosticsError",error(error));
            }finally{
                transferring=false;
                app.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();
            }
            note("Graphics diagnostic শেষ। Copy report পাঠান।");result.complete(summary);
        });
    }
    interface ScreenResult {void complete(Bitmap image,String message);}
    /** Diagnostic fallback: this is one verified guest PNG, not a live display. */
    static void captureScreen(Context c,ScreenResult result) {
        if(!active||console==null||transferring){result.complete(null,"আগে VM চালু করুন এবং চলমান কাজ শেষ হতে দিন।");return;}
        if(!bootComplete()){result.complete(null,"Android system boot সম্পূর্ণ হওয়ার পরে Screen snapshot চাপুন।");return;}
        GuestConsole session=console;transferring=true;Context app=c.getApplicationContext();
        put("guestScreenshotVerified",false);put("guestScreenshotError",JSONObject.NULL);
        note("Guest screenshot নেওয়া হচ্ছে… স্ক্রিন সংযোগের পরীক্ষামূলক বিকল্প।");
        commands.execute(()->{
            Bitmap bitmap=null;String message;
            try{
                byte[] png=GuestScreenCapture.read(session,(received,total)->note("Guest screenshot: "+(received/1024)+" / "+(total/1024)+" KB"));
                BitmapFactory.Options options=new BitmapFactory.Options();options.inJustDecodeBounds=true;
                BitmapFactory.decodeByteArray(png,0,png.length,options);
                if(options.outWidth<1||options.outHeight<1||options.outWidth>4096||options.outHeight>4096)
                    throw new IOException("Guest screenshot dimensions invalid: "+options.outWidth+"x"+options.outHeight);
                bitmap=BitmapFactory.decodeByteArray(png,0,png.length);
                if(bitmap==null)throw new IOException("Guest PNG could not be decoded");
                put("guestScreenshotVerified",true);put("guestScreenshotWidth",bitmap.getWidth());
                put("guestScreenshotHeight",bitmap.getHeight());put("guestScreenshotBytes",png.length);
                message="Guest screenshot পাওয়া গেছে ("+bitmap.getWidth()+"×"+bitmap.getHeight()+"). এটি স্থির ছবি, live screen নয়। নতুন ছবি পেতে আবার Screen snapshot চাপুন।";
            }catch(Throwable e){
                message="Screen snapshot ব্যর্থ: "+error(e);put("guestScreenshotError",error(e));
            }finally{
                transferring=false;
                app.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();
            }
            note(message);result.complete(bitmap,message);
        });
    }
    static void command(Context c,String command,boolean root,CommandResult result) {
        if(!active||console==null||transferring){result.complete("আগে VM চালু করুন এবং চলমান transfer শেষ হতে দিন।");return;}
        GuestConsole session=console;transferring=true;put("guestCommandError",JSONObject.NULL);note("Guest command চলছে…");
        commands.execute(()->{String output;try{
            GuestConsole.Result r=session.command(command,root,60000);output="Exit "+r.code+"\n"+r.output;
            put("lastGuestCommandExit",r.code);put("lastGuestCommandOutput",r.output);
            if(root&&r.code==0&&r.output.contains("uid=0(root)"))put("guestRootShellVerified",true);
        }catch(Throwable e){output=error(e);put("guestCommandError",output);}
        finally{transferring=false;}
        c.getApplicationContext().getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();
        note("Guest command শেষ।");result.complete(output);});
    }
    static void importFile(Context c,android.net.Uri uri,boolean apk,CommandResult result) {
        if(!active||console==null||transferring){result.complete("আগে VM চালু করুন এবং চলমান transfer শেষ হতে দিন।");return;}
        GuestConsole session=console;transferring=true;Context app=c.getApplicationContext();put("lastImportError",JSONObject.NULL);put("lastImportResult",JSONObject.NULL);put(apk?"lastApkInstallVerified":"lastFileImportVerified",false);note("বেছে নেওয়া ফাইল প্রস্তুত হচ্ছে…");
        commands.execute(()->{File local=null;String output;
            try {
                String name="file";
                try(android.database.Cursor cursor=app.getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
                    if(cursor!=null&&cursor.moveToFirst())name=cursor.getString(0);
                }
                local=File.createTempFile("vp-import-",".tmp",app.getCacheDir());
                try(InputStream in=app.getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(local)) {
                    if(in==null)throw new IOException("Cannot read selected file");byte[] b=new byte[65536];int n;long bytes=0;
                    while((n=in.read(b))>=0){if(cancel.get()||!active)throw new IOException("Cancelled");bytes+=n;if(bytes>1024L*1024*1024)throw new IOException("একবারে সর্বোচ্চ ১ GB ফাইল পাঠানো যাবে।");out.write(b,0,n);}
                }
                long[] last={0};
                output=GuestTransfer.send(session,local,name,apk,new GuestTransfer.Progress(){
                    public boolean cancelled(){return cancel.get()||!active;}
                    public void update(long bytes,long total){long now=SystemClock.elapsedRealtime();if(now-last[0]>750){note("VM-এ পাঠানো হচ্ছে: "+(bytes/1024)+" / "+(total/1024)+" KB");last[0]=now;}}
                });put(apk?"lastApkInstallVerified":"lastFileImportVerified",true);put("lastImportResult",output);
            }catch(Throwable e){output=error(e);put("lastImportError",output);}
            finally{if(local!=null)local.delete();transferring=false;}
            app.getSharedPreferences("android-vm-report",0).edit().putString("last",report()).apply();note("ফাইলের কাজ শেষ।");result.complete(output);
        });
    }
    static void touch(MotionEvent e,int width,int height) {
        Object target=vm;if(!active||target==null||width<=0||height<=0)return;
        MotionEvent copy=MotionEvent.obtain(e);android.graphics.Matrix m=new android.graphics.Matrix();m.setScale(720f/width,1280f/height);copy.transform(m);
        try{call(target,"sendMultiTouchEvent",new Class<?>[]{MotionEvent.class},copy);}catch(Throwable error){put("inputError",error(error));}finally{copy.recycle();}
    }
    static void key(int key) {
        Object target=vm;if(!active||target==null)return;long now=SystemClock.uptimeMillis();
        int scan=key==KeyEvent.KEYCODE_BACK?158:key==KeyEvent.KEYCODE_HOME?172:580;
        try{
            Method method=AvfReflection.keyboardMethod(target.getClass(),KeyEvent.class);
            for(int action:new int[]{KeyEvent.ACTION_DOWN,KeyEvent.ACTION_UP}){
                KeyEvent event=new KeyEvent(now,now,action,key,0,0,-1,scan,0,android.view.InputDevice.SOURCE_KEYBOARD);
                if(!AvfReflection.sendKey(target,method,(short)scan,action==KeyEvent.ACTION_DOWN,event))throw new IOException("AVF rejected keyboard input");
            }
        }catch(Throwable e){put("inputError",error(e));}
    }
    private static final class Drain extends Thread {
        final InputStream in;final String name,nonce;volatile boolean done;final StringBuilder buffer=new StringBuilder(),line=new StringBuilder();
        Drain(InputStream in,String name,String nonce){super("vp-android-"+name);this.in=in;this.name=name;this.nonce=nonce;setDaemon(true);}
        public void run(){try{byte[] b=new byte[4096];while(!done){int n=in.available();if(n==0){Thread.sleep(20);continue;}n=in.read(b,0,Math.min(n,b.length));if(n<0)break;String value=new String(b,0,n,StandardCharsets.UTF_8);synchronized(this){buffer.append(value);if(buffer.length()>16384)buffer.delete(0,buffer.length()-16384);}line.append(value);int end;while((end=line.indexOf("\n"))>=0){String text=line.substring(0,end);line.delete(0,end+1);GuestConsole session=console;if(session!=null&&name.equals("getConsoleOutput"))session.line(text);if(GuestConsole.bootMarker(text,nonce)){put("androidBootCompleted",true);note("Android system boot সম্পূর্ণ হয়েছে। স্ক্রিনে home screen দেখা যাচ্ছে কি না যাচাই বাকি।");}}if(line.length()>8192)line.delete(0,line.length()-8192);}}catch(Throwable e){if(!done)put(name+"Error",error(e));}}
        synchronized String tail(){return buffer.toString();}
        void finish(){done=true;try{in.close();}catch(IOException ignored){}interrupt();}
    }
}
