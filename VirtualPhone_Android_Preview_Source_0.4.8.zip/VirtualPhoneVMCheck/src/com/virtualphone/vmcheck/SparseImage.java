package com.virtualphone.vmcheck;

import java.io.*;

/** Streaming Android sparse-v1 decoder. The containing ZIP is separately SHA-256 pinned. */
final class SparseImage {
    interface Progress { void update(long bytes) throws IOException; }
    private static long u32(InputStream in)throws IOException {
        long v=0;for(int i=0;i<4;i++){int b=in.read();if(b<0)throw new EOFException();v|=(long)b<<(8*i);}return v;
    }
    private static int u16(InputStream in)throws IOException {int a=in.read(),b=in.read();if((a|b)<0)throw new EOFException();return a|(b<<8);}
    private static void skip(InputStream in,long n)throws IOException {while(n>0){long k=in.skip(n);if(k==0){if(in.read()<0)throw new EOFException();k=1;}n-=k;}}
    static void decode(InputStream source,File destination,long expectedSize,Progress progress)throws IOException {
        try(InputStream in=new BufferedInputStream(source,1024*1024);RandomAccessFile out=new RandomAccessFile(destination,"rw")) {
            if(u32(in)!=0xed26ff3aL||u16(in)!=1)throw new IOException("Unsupported Android sparse image");
            u16(in);int header=u16(in),chunkHeader=u16(in);long block=u32(in),blocks=u32(in),chunks=u32(in);u32(in);
            if(header<28||header>4096||chunkHeader<12||chunkHeader>4096||block!=4096||blocks<=0||chunks>1000000||blocks!=expectedSize/block)
                throw new IOException("Invalid sparse image dimensions");
            skip(in,header-28);out.setLength(0);out.setLength(expectedSize);
            byte[] buf=new byte[1024*1024];long produced=0;
            for(long i=0;i<chunks;i++) {
                int kind=u16(in);u16(in);long count=u32(in),total=u32(in),size=count*block;
                if(total<chunkHeader||size>expectedSize-produced)throw new IOException("Sparse chunk exceeds image bounds");
                skip(in,chunkHeader-12);long payload=total-chunkHeader;
                if(kind==0xcac1) {
                    if(payload!=size)throw new IOException("Invalid RAW chunk");
                    long left=size;while(left>0){int n=in.read(buf,0,(int)Math.min(left,buf.length));if(n<0)throw new EOFException();out.write(buf,0,n);left-=n;progress.update(produced+size-left);}
                } else if(kind==0xcac2) {
                    if(payload!=4)throw new IOException("Invalid FILL chunk");long word=u32(in);
                    if(word==0)out.seek(out.getFilePointer()+size);
                    else {for(int j=0;j<buf.length;j++)buf[j]=(byte)(word>>>(8*(j%4)));long left=size;while(left>0){int n=(int)Math.min(left,buf.length);out.write(buf,0,n);left-=n;progress.update(produced+size-left);}}
                } else if(kind==0xcac3) {
                    if(payload!=0)throw new IOException("Invalid DONT_CARE chunk");out.seek(out.getFilePointer()+size);
                } else if(kind==0xcac4) {
                    if(payload!=4||count!=0)throw new IOException("Invalid CRC chunk");u32(in);
                } else throw new IOException("Unknown sparse chunk type");
                produced+=size;progress.update(produced);
            }
            if(produced!=expectedSize||in.read()!=-1)throw new IOException("Incomplete or trailing sparse image data");
            out.getFD().sync();
        }
    }
}
