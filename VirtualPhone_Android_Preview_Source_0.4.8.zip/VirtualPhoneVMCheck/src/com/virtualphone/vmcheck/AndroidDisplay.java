package com.virtualphone.vmcheck;

import android.os.IBinder;
import android.view.Surface;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

/** Uses the OEM's own interface adapters; never guesses private transaction numbers. */
final class AndroidDisplay {
    private static native IBinder lookup();
    private static native IBinder requestLookup();
    private static final AtomicBoolean waiting=new AtomicBoolean();
    private static volatile Object display;
    private static volatile Class<?> displayInterface;
    private static volatile Surface connected;
    private static IBinder lookupJava()throws Exception {
        Class<?> manager=Class.forName("android.os.ServiceManager");
        Method check=manager.getDeclaredMethod("checkService",String.class);
        check.setAccessible(true);
        return (IBinder)check.invoke(null,"android.system.virtualizationservice");
    }
    /** Return an idle lookup observation; a lazy service need not exist before VM start. */
    static boolean checkApi()throws Exception {
        System.loadLibrary("vp_display_bridge");
        Class<?> internal=Class.forName("android.system.virtualizationservice_internal.IVirtualizationServiceInternal");
        internal.getMethod("waitDisplayService");
        Class.forName(internal.getName()+"$Stub").getMethod("asInterface",IBinder.class);
        Class<?> iface=Class.forName("android.crosvm.ICrosvmAndroidDisplayService");
        iface.getMethod("setSurface",Surface.class,boolean.class);iface.getMethod("removeSurface",boolean.class);
        Class.forName(iface.getName()+"$Stub").getMethod("asInterface",IBinder.class);
        return lookup()!=null;
    }
    static IBinder requireSystemService() {
        IBinder service=requestLookup();
        if(service==null)throw new IllegalStateException("AVF system Binder unavailable after requesting lazy startup; permission denial, OEM service differences or service startup failure require separate diagnosis");
        return service;
    }
    /** Observes service registration without treating an idle null as an AVF API failure. */
    static JSONObject observeService(boolean requestStart) {
        JSONObject result=new JSONObject();
        try {
            result.put("serviceName","android.system.virtualizationservice");
            result.put("lazyStartRequested",requestStart);
            System.loadLibrary("vp_display_bridge");
            IBinder binder=requestStart?requestLookup():lookup();
            result.put("binderVisible",binder!=null);
            try{
                IBinder javaBinder=lookupJava();
                result.put("javaServiceManagerBinderVisible",javaBinder!=null);
            }catch(Throwable e){result.put("javaServiceManagerError",AndroidVm.error(e));}
            if(binder!=null) {
                result.put("binderAlive",binder.isBinderAlive());
                try{result.put("interfaceDescriptor",binder.getInterfaceDescriptor());}
                catch(Throwable e){result.put("descriptorError",AndroidVm.error(e));}
            }
            result.put("permissionDeniedConfirmed",false);
        }catch(Throwable e){
            try {
                result.put("binderVisible",false);
                result.put("lookupError",AndroidVm.error(e));
                result.put("permissionDeniedConfirmed",e instanceof SecurityException);
            }catch(org.json.JSONException ignored){}
        }
        return result;
    }
    static void present(Surface surface) {
        if(!AndroidVm.active()||surface==null||!surface.isValid()||connected==surface||!waiting.compareAndSet(false,true))return;
        Thread thread=new Thread(()->{
            try {
                if(display==null) {
                    AndroidVm.put("displayStage","lookupVirtualizationService");
                    System.loadLibrary("vp_display_bridge");IBinder service=lookup();
                    if(service==null){
                        AndroidVm.put("displayStage","lookupJavaServiceManager");
                        try{service=lookupJava();}catch(Throwable e){AndroidVm.put("displayJavaLookupError",AndroidVm.error(e));}
                    }
                    if(service==null){AndroidVm.put("displayStage","requestNativeService");service=requireSystemService();}
                    Class<?> internal=Class.forName("android.system.virtualizationservice_internal.IVirtualizationServiceInternal");
                    Class<?> stub=Class.forName(internal.getName()+"$Stub");
                    Object adapter=stub.getMethod("asInterface",IBinder.class).invoke(null,service);
                    // This Binder call may wait for crosvm; it never blocks the UI thread.
                    AndroidVm.put("displayStage","waitDisplayService");
                    IBinder binder=(IBinder)internal.getMethod("waitDisplayService").invoke(adapter);
                    if(binder==null)throw new IllegalStateException("waitDisplayService returned null");
                    displayInterface=Class.forName("android.crosvm.ICrosvmAndroidDisplayService");
                    display=Class.forName(displayInterface.getName()+"$Stub").getMethod("asInterface",IBinder.class).invoke(null,binder);
                }
                if(!AndroidVm.active()||!surface.isValid())return;
                AndroidVm.put("displayStage","setSurface");
                displayInterface.getMethod("setSurface",Surface.class,boolean.class).invoke(display,surface,false);
                connected=surface;
                AndroidVm.put("displayStage","surfaceConnected");
                AndroidVm.put("displaySurfaceConnected",true);
                AndroidVm.put("displayError",JSONObject.NULL);
            } catch(Throwable e){AndroidVm.put("displayError",AndroidVm.error(e));AndroidVm.put("displayServiceAfterAttachFailure",observeService(false));display=null;}
            finally{waiting.set(false);}
        },"vp-display");thread.setDaemon(true);thread.start();
    }
    static void remove() {
        Object old=display;Class<?> iface=displayInterface;display=null;connected=null;
        if(old==null||iface==null)return;
        Thread t=new Thread(()->{try{iface.getMethod("removeSurface",boolean.class).invoke(old,false);}catch(Throwable ignored){}},"vp-display-remove");t.setDaemon(true);t.start();
    }
}
