package com.virtualphone.vmcheck;

import java.lang.reflect.*;

/** Uses only members actually exposed by this firmware. No policy changes or ART hooks. */
final class AvfReflection {
    static Object builder(Class<?> type,Class<?> contextType,Object context)throws Exception {
        Constructor<?> found=null;
        try {found=type.getConstructor();}catch(NoSuchMethodException ignored){}
        if(found==null&&context!=null)try{found=type.getConstructor(contextType);}catch(NoSuchMethodException ignored){}
        if(found==null)try{found=type.getDeclaredConstructor();found.setAccessible(true);}catch(NoSuchMethodException ignored){}
        if(found==null&&context!=null)try{found=type.getDeclaredConstructor(contextType);found.setAccessible(true);}catch(NoSuchMethodException ignored){}
        if(found==null)throw new NoSuchMethodException(type.getName()+": no visible zero-argument or Context constructor; restricted non-SDK API or OEM API difference");
        return found.getParameterTypes().length==0?found.newInstance():found.newInstance(context);
    }
    static Method method(Class<?> type,String name,Class<?>... params)throws Exception {
        try{return type.getMethod(name,params);}catch(NoSuchMethodException original){
            try {Method m=type.getDeclaredMethod(name,params);m.setAccessible(true);return m;}
            catch(NoSuchMethodException missing){throw original;}
        }
    }
    static Object invoke(Object target,String name,Class<?>[] params,Object... args)throws Exception {
        return method(target.getClass(),name,params).invoke(target,args);
    }
    /** AVF revisions expose either Linux scan-code input or the older KeyEvent API. */
    static Method keyboardMethod(Class<?> type,Class<?> keyEventType)throws Exception {
        try{return method(type,"sendKeyEvent",short.class,boolean.class);}
        catch(NoSuchMethodException absent){return method(type,"sendKeyEvent",keyEventType);}
    }
    static boolean sendKey(Object target,Method method,short scan,boolean down,Object legacyEvent)throws Exception {
        Object result=method.getParameterTypes().length==2?method.invoke(target,scan,down):method.invoke(target,legacyEvent);
        return !Boolean.FALSE.equals(result);
    }
    static String inventory(Class<?> type){
        StringBuilder out=new StringBuilder(type.getName());
        try{for(Constructor<?> c:type.getDeclaredConstructors())out.append("\n").append(c.toString());}catch(Throwable e){out.append("\nconstructor inventory: ").append(e.getClass().getSimpleName());}
        try{int n=0;for(Method m:type.getDeclaredMethods()){if(Modifier.isPublic(m.getModifiers())&&n++<60)out.append("\n").append(m.toString());}}catch(Throwable e){out.append("\nmethod inventory: ").append(e.getClass().getSimpleName());}
        return out.toString();
    }
}
