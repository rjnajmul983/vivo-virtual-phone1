package com.virtualphone.vmcheck;

import org.json.JSONObject;

/** Read-only, explicitly requested guest graphics diagnostics on serial console. */
final class GuestGraphicsDiagnostics {
    interface Progress {void update(String title);}
    private static final String[][] PROBES={
        {"guestShellAndProps", "echo VP_GUEST_SHELL_OK; id; for key in sys.boot_completed init.svc.surfaceflinger init.svc.bootanim ro.hardware.egl ro.hardware.hwcomposer ro.boot.hardware ro.boot.hardware.gralloc ro.boot.enable_bootanimation ro.sf.lcd_density; do echo $key=$(getprop $key); done; free -m"},
        {"graphicsDeviceNodes", "ls -l /dev/dri /dev/graphics 2>&1"},
        {"graphicsProcesses", "ps -A | grep -E 'surfaceflinger|composer|gralloc|hwc|bootanim|graphics' | head -n 32"},
        {"allocatorWaitState", "p=$(pidof android.hardware.graphics.allocator-service.minigbm); echo allocator_pid=$p; if [ -n \"$p\" ]; then cat /proc/$p/wchan 2>&1; grep -E '^State:|^VmRSS:' /proc/$p/status 2>&1; fi; cat /proc/pressure/memory 2>&1"},
        {"graphicsBinderServices", "service check SurfaceFlinger; service check SurfaceFlingerAIDL; service check window; service check display"},
        {"surfaceFlingerState", "timeout 5 dumpsys SurfaceFlinger --display-id 2>&1"},
        {"graphicsRecentLog", "logcat -b main,system -d -t 1800 2>&1 | grep -Ei 'surfaceflinger|composer|gralloc|drm|virtio.gpu|egl|vulkan|hwc' | tail -n 60"},
        {"crashRecentLog", "logcat -b crash -d -t 35 2>&1"}
    };
    private GuestGraphicsDiagnostics(){}
    static JSONObject inspect(GuestConsole console,Progress progress) {
        JSONObject output=new JSONObject();
        try{output.put("scope","read-only commands inside this guest Android VM; not the host");}catch(Exception ignored){}
        for(String[] probe:PROBES) {
            progress.update(probe[0]);
            JSONObject result=new JSONObject();
            try{
                GuestConsole.Result command=console.command(probe[1],false,12000);
                result.put("exit",command.code);
                result.put("output",command.output.length()>8192?command.output.substring(0,8192):command.output);
                if(command.code==124)result.put("guestCommandTimedOut",true);
            }catch(Throwable error){
                try{result.put("error",AndroidVm.error(error));}catch(Exception ignored){}
                // A host-side serial timeout closes the session: subsequent
                // output would be misleading until the VM has restarted.
                if(String.valueOf(error.getMessage()).contains("Stop/Start")) {
                    try{output.put(probe[0],result);output.put("probeStoppedBecauseConsoleLost",true);}catch(Exception ignored){}
                    break;
                }
            }
            try{output.put(probe[0],result);}catch(Exception ignored){}
        }
        return output;
    }
}
