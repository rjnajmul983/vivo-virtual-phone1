package com.virtualphone.vmcheck;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import org.json.JSONObject;

/** Shell-started instrumentation for THIS package only; never writes global API policy. */
public final class VmSessionInstrumentation extends Instrumentation {
    private static volatile boolean active,endRequested;
    private boolean probeOnly;
    static boolean active(){return active;}
    static void requestEnd(){endRequested=true;}
    @Override public void onCreate(Bundle args){
        super.onCreate(args);probeOnly=args!=null&&"true".equals(args.getString("probe_only"));start();
    }
    @Override public void onStart(){
        super.onStart();active=true;endRequested=false;
        Context context=getTargetContext();Bundle end=new Bundle();
        try{
            AndroidVm.initialize(context);
            Bundle initial=new Bundle();initial.putString("stream","VP_SESSION active; this app only; global API settings unchanged\n");sendStatus(1,initial);
            // Metadata lookup only: never invokes VMRuntime or changes ART policy itself.
            boolean hiddenMemberVisible=false;
            try{Class.forName("dalvik.system.VMRuntime").getDeclaredMethod("setHiddenApiExemptions",String[].class);hiddenMemberVisible=true;}catch(ReflectiveOperationException ignored){}
            JSONObject api=AvfApiCheck.run(context);api.put("sessionHiddenMemberLookupVisible",hiddenMemberVisible);
            AndroidVm.recordSessionCheck(context,api);
            Bundle checked=new Bundle();checked.putString("stream","VP_SESSION hidden_member_lookup_visible="+hiddenMemberVisible+" preflight_passed="+api.optBoolean("passed")+" failed_checks="+api.getJSONArray("failedMembers").length()+"; full details: Copy report\n");sendStatus(2,checked);
            if(probeOnly){end.putString("apiCheck",api.toString());end.putString("stream","VP_SESSION probe complete\n");}
            else{
                runOnMainSync(()->context.startActivity(new Intent(context,AndroidActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
                while(!endRequested)Thread.sleep(250);
                AndroidVm.stop();long deadline=android.os.SystemClock.elapsedRealtime()+5000;
                while((AndroidVm.active()||AndroidVm.busy())&&android.os.SystemClock.elapsedRealtime()<deadline)Thread.sleep(100);
                end.putString("stream","VP_SESSION ended\n");
            }
            finish(Activity.RESULT_OK,end);
        }catch(Throwable error){end.putString("stream","VP_SESSION error: "+DeviceProbe.describe(error)+"\n");finish(Activity.RESULT_CANCELED,end);}
        finally{active=false;}
    }
}
