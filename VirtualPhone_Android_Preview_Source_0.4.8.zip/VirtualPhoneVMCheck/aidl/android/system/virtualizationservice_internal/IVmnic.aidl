/*
 * Copyright 2024 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package android.system.virtualizationservice_internal;

interface IVmnic {
    /**
     * Create TAP network interface for a VM.
     * @param suffix of network interface name.
     * @return file descriptor of the TAP network interface.
     */
    ParcelFileDescriptor createTapInterface(String ifaceNameSuffix);

    /**
     * Delete TAP network interface created for a VM.
     * @param file descriptor of the TAP network interface.
     */
    void deleteTapInterface(in ParcelFileDescriptor tapFd);
}
