#!/system/bin/sh
# Run as Android's ADB shell user. The APK never executes this script itself.
# Preserve existing exemptions; only add these AVF-specific descriptor prefixes.
set -euf
vp_key=hidden_api_blacklist_exemptions
vp_backup=/data/local/tmp/virtualphone-avf-api.before
vp_prefixes='Landroid/system/virtualmachine/VirtualMachineCustomImageConfig,Landroid/system/virtualmachine/VirtualMachineConfig,Landroid/system/virtualmachine/VirtualMachine;,Landroid/system/virtualmachine/VirtualMachineManager;,Landroid/system/virtualizationservice_internal/IVirtualizationServiceInternal,Landroid/crosvm/ICrosvmAndroidDisplayService'
vp_current=$(settings get global "$vp_key")
case "$vp_current" in null) vp_current='' ;; esac
vp_new=$vp_current
vp_changed=no
case "${1:-enable}" in
  enable)
    if [ ! -f "$vp_backup" ]; then
      umask 077
      settings get global "$vp_key" > "$vp_backup"
    fi
    # Preserve an already-existing '*' policy exactly; do not replace it.
    if [ "$vp_current" != '*' ]; then
      IFS=,
      for vp_prefix in $vp_prefixes; do
        case ",$vp_new," in
          *",$vp_prefix,"*) ;;
          *) vp_new="${vp_new:+$vp_new,}$vp_prefix" ;;
        esac
      done
      unset IFS
    fi
    ;;
  restore)
    if [ ! -f "$vp_backup" ]; then echo 'No VirtualPhone setup backup exists.' >&2; exit 1; fi
    vp_before=$(cat "$vp_backup")
    vp_new=''
    IFS=,
    for vp_prefix in $vp_current; do
      vp_keep=yes
      case ",$vp_prefixes," in
        *",$vp_prefix,"*)
          case ",$vp_before," in *",$vp_prefix,"*) ;; *) vp_keep=no ;; esac
          ;;
      esac
      if [ "$vp_keep" = yes ]; then vp_new="${vp_new:+$vp_new,}$vp_prefix"; fi
    done
    unset IFS
    ;;
  *) echo 'Usage: sh avf-api-setup.sh [enable|restore]' >&2; exit 2 ;;
esac
if [ "$vp_new" != "$vp_current" ]; then
  if [ -n "$vp_new" ]; then settings put global "$vp_key" "$vp_new"; else settings delete global "$vp_key"; fi
  vp_verified=$(settings get global "$vp_key")
  case "$vp_verified" in null) vp_verified='' ;; esac
  if [ "$vp_verified" != "$vp_new" ]; then echo 'Firmware did not apply the AVF API setting.' >&2; exit 1; fi
  vp_changed=yes
fi
if [ "${1:-enable}" = restore ]; then rm -f "$vp_backup"; fi
echo "VP_AVF_SETUP action=${1:-enable} setting_verified=yes setting_changed=$vp_changed"
am force-stop com.virtualphone.vmcheck
sleep 1
am start -n com.virtualphone.vmcheck/.AndroidActivity
echo 'VP_AVF_SETUP restart_requested=yes; run API check in VirtualPhone. Setting verification alone does not prove API access, display or Android boot.'
