# 0.4.5 — observed Cuttlefish guest boot-device mismatch

## Real Vivo 0.4.4 report

Host: vivo V2507A / Android 16 / SDK 36.
`VirtualMachine.run()` returned successfully. The guest ARM64 kernel enumerated
the composite GPT disk with vda1-vda5 and the Cuttlefish virtual keyboard at:

    /devices/platform/2e000000.pci/pci0000:00/0000:00:08.0/virtio7/input/input1

The first-stage init then logged:

    init: Failed to read vbmeta partitions.
    init: realpath failed: /dev/block/by-name/super: No such file or directory
    init: Failed to create devices required for first stage mount
    Kernel panic - not syncing: Attempted to kill init!

`stopReason=5` followed the guest kernel panic. `androidBootCompleted=false`.
The display Binder remained unavailable, but graphics failure is not why init
aborted at approximately one guest second.

## Root-cause hypothesis and code change

The pinned Cuttlefish boot-params.json specifies `androidboot.boot_devices` as
`10000.pci`, matching the earlier local ARM64 QEMU path. The physical Vivo's
AVF guest platform reports `2e000000.pci` instead.

In AOSP first-stage init, `GetBootDevices()` gets platform prefixes from the
bootconfig, and `DeviceHandler::GetBlockDeviceSymlinks()` creates
`/dev/block/by-name/<partition>` on an identified boot device. A wrong prefix
therefore explains why the partition nodes were present but the by-name link
was missing. This is a targeted, source-grounded explanation—not yet a
successfully retested physical boot.

0.4.5 reads the prior saved `getConsoleOutputTail`, validates the observed PCI
platform identifier, and overrides only `androidboot.boot_devices` when
preparing the launch initrd. If no prior matching evidence is available, the
observed V2507A value is used on that exact manufacturer/model; other hosts
retain the original Cuttlefish-QEMU default. Since Android's bootconfig parser
splits boot devices at spaces, this version deliberately passes one exact
observed platform identifier rather than an unvalidated comma-joined list.

It also reports the selected value and source, plus whether the final guest
console contained a kernel panic or missing super by-name link.

## Expected validation and current limits

- The new boot-device selector, Java compilation, APK signing and alignment
  have been tested locally.
- Actual Vivo reboot with the new parameter remains to be tested.
- Existing private guest images and userdata paths, test signing key and
  `VirtualMachineManager` VM name are unchanged. Update; do not uninstall.
- A successful first-stage mount does **not** establish full Android boot,
  display Surface connection, Chrome/games or per-app root.
- The persistent display Binder failure still requires a subsequent isolated
  diagnosis if boot gets past init.

Primary AOSP source references:
- https://android.googlesource.com/platform/system/core/+/835a86216226663c6b0a1ff0ca38b24eab54e2bc/fs_mgr/libfstab/fstab.cpp
- https://android.googlesource.com/platform/system/core/+/refs/heads/main/init/devices.cpp
