# Android port status — 2026-10-26

This is a working porting checkpoint, not the completed VirtualPhone product.

## What was actually observed

The pinned public AOSP Cuttlefish ARM64 Android 17 image (build 16644040)
was booted locally under ARM64 QEMU software emulation. This is independent
of the earlier user-device Microdroid test.

- Linux 6.12.74 guest kernel, first-stage mounts of system/vendor, and Android
  second-stage init ran.
- Zygote, SurfaceFlinger, SystemServer and normal Android services started.
- The guest naturally set sys.boot_completed=1. It was never manually set by
  a test command. An init trigger emitted VP_ANDROID_BOOT_COMPLETE with the
  corresponding run nonce.
- The first successful run using the ranchu composer emitted the marker at
  guest elapsed 295.153567 seconds. A subsequent boot using the Java-generated
  Linux bootconfig trailer emitted it at 219.106367 seconds. These are local
  software-emulation observations, not phone performance claims.
- The kernel accepted the bootconfig trailer: 2284 bytes / 114 nodes. Android
  hardware settings no longer depend on fitting in ARM64's short command line.
- Real Android wallpaper frames were observed in the virtual display. Full
  launcher interaction, Settings completion, browser and game operation were
  not certified from a wallpaper frame.
- A shell inside this guest ran userdebug su and id returned uid=0(root),
  context u:r:su:s0. This is guest root from the actual guest kernel. It does
  not supply a per-app root permission manager or prove arbitrary root apps work.
- Userdata survived the successive local VM boots. The test did not reset it
  between the two successful boots.

Compact literal excerpts are in ANDROID_BOOT_EVIDENCE.txt.

## Changes needed for this initial port

The installer merges the generic/vendor ramdisks, removes direct-boot-inapplicable
recovery entries and AVB expectations from the guest's first-stage fstab, and
uses the guest's own software KeyMint/Gatekeeper variants. It has no dependency
on a PC-side Cuttlefish key service. A new run-specific nonce is in bootconfig.

The original drm_hwcomposer profile failed present validation in the local
virtual GPU. The current profile uses ranchu client composition, minigbm,
ANGLE/pastel guest software rendering and a virtio 2D GPU. Hardware 3D is not
implemented or tested by this profile.

Some host-backed peripheral APEX modules are disabled. The unavailable
Cuttlefish host sensor declaration/service are removed using size-preserving,
SHA-256-guarded patches to this exact image. A separate patched init trigger
reports genuine boot completion. No physical host sensor/camera/SIM is shared.

The small APK derives kernel and driver ramdisk files from the user's direct,
verified Google download. It does not redistribute kernel/module binaries.
Generated empty guest filesystems and public AOSP AIDL declarations are included.

## Target phone and outstanding work

On the user's V2507A Android 16 phone, only the earlier Microdroid native
payload test has been confirmed. The new full Android custom-image path,
OEM display/Binder API compatibility and networking must be tested on that
phone. The APK performs API/permission/native-library preflight before its
large download, and reports the actual failure instead of claiming success.

The 0.3 checkpoint left host APK/file import, a guest root permission manager, hardware acceleration,
guest audio, Chrome/Free Fire compatibility and comprehensive data-isolation
testing unfinished. The 0.4 changes below supersede the import implementation status. Application compatibility flags remain
false. A completed kernel boot or display connection does not change them.

There is no remote connection to the user's physical phone in this workspace.
The next phone-specific result must come from installing this concrete APK
over 0.2, preparing the image, starting it, and copying its report. The earlier
Microdroid test does not need repeating.

## 0.4 implementation

The production host APK now supports selected-file import, standalone APK
installation, and guest shell/root commands through an AVF serial console.
It enables setVmConsoleInputSupported and explicitly chooses hvc0. Console
settings use a fresh AVF VM handle while retaining the same guest userdata
and image disk paths. Boot evidence accepts genuine kernel log prefixes but
rejects command echo and a different run nonce.

Each transfer chunk receives a response; the full guest staging file must
match the host SHA-256 before installing or committing. Guest PM must return
both exit zero and an exact Success line. File import uses the guest's media
backing directory with media_rw ownership: the init console's mount namespace
cannot write the per-app /sdcard FUSE alias. Imports never share a host folder.
A different random guest serial is created for each host app installation and
persists over updates. This is not a complete device identity emulation system.

The target-phone full Android boot, graphics, networking and import integration
remain unverified. Per-app root approval, split-package installation, hardware
3D, audio, Chrome and Free Fire compatibility remain unfinished or unverified.
The root command checkbox operates only inside the guest; it does not implement
a root permission manager for third-party guest apps.

### 0.4 observed local results

Fresh local Android boot naturally completed at guest elapsed 214.489098 s.
The production command and transfer classes, connected to QEMU's serial socket,
verified real guest UID 0, a selected 4099-byte binary import, guest package
installation, a resumed test Activity, and that test app reading the imported
file through its own external-storage mount with the expected SHA-256. The
test APK was written specifically for this test; it is not Chrome or a game.

The capture still showed the Android test app's splash screen. Its completed
first draw and interactive launcher UI remain unverified. A resumed Activity
and successful file read are not proof that the display is fully working.
Exact command results are in LOCAL_0_4_TEST_EVIDENCE.txt.
