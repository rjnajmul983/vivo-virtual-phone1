# 0.4.1 API compatibility checkpoint

The user's Vivo V2507A Android 16 report from 0.4 showed:

    NoSuchMethodException: android.system.virtualmachine.VirtualMachineCustomImageConfig$Builder.<init> []

This happened in preflight, before the image download and before an Android VM
was created. The AOSP Android 16 source has a public no-argument constructor.
AOSP also documents that hidden/non-SDK API filtering can report missing members.
The report alone cannot establish whether this phone filtered the constructor or
changed its API. This does not disprove the earlier successful Microdroid boot.

0.4.1 uses a shared constructor/method adapter, trying exposed zero-argument and
Context constructors, including visible declared constructors. It does NOT
change ART policy, claim that a hidden constructor became visible, use unsafe
allocation, or substitute a Microdroid guest for full Android.

Preflight now checks the required builders, methods, constants, disk/partition
API, console/input, callbacks, manager and native display/Binder API. It records
all failures and visible member inventories in Copy report. It also runs before
Start if the image was prepared earlier. A failed check prevents image download.

## Phone-only setup with Termux

1. Update the app to 0.4.1; do not uninstall it.
2. Tap API check. If it passes, proceed to Android download.
3. If VM APIs are restricted, open Setup নির্দেশনা and Copy ADB setup.
4. With the previously configured Termux Wireless ADB connection active, paste
   and run the copied command in Termux. It uses the Android ADB shell, restarts
   only VirtualPhone, and reopens it. The APK itself never runs this script.
5. Tap API check again. If it fails, send Copy report and any Termux error.
   Passing API check does not certify Android guest boot or graphics.

The setup script adds only the listed AVF descriptor prefixes to the system's
hidden_api_blacklist_exemptions setting. The visibility setting is system-wide,
not a per-app grant. Existing entries are preserved; an existing '*' value is
left unchanged. It does not set hidden_api_policy or add a global wildcard.
The VM broker still checks MANAGE_VIRTUAL_MACHINE and USE_CUSTOM_VIRTUAL_MACHINE.
Copy restore removes only entries added by our script, preserving older entries
and unrelated entries added afterward. The original list is backed up by the
ADB shell with mode 0600. Firmware may restrict the Settings operation; the
script verifies the resulting setting and stops on a denied write.

## Validation and limits

The Java regression test reproduces a missing public constructor and checks
public/private/Context constructors, absent API diagnosis and real constructor
exceptions. It does not emulate Android's hidden-API enforcement.

The script was tested with a mock Settings shell for idempotence, preserving
older entries/wildcards, preserving later unrelated entries, restore, backup
permissions, and denied writes. It has NOT been applied to the user's phone.
The compiled APK retains the same package and signing certificate.

The previous 0.4 local guest boot/import tests are historical evidence for
unchanged guest-transfer code; they were not rerun for 0.4.1. Physical Vivo full
Android boot/display, per-app root manager, Chrome and games remain unverified
or unfinished.

Primary sources:
- https://developer.android.com/guide/app-compatibility/restrictions-non-sdk-interfaces
- https://android.googlesource.com/platform/packages/modules/Virtualization/+/refs/heads/android16-release/libs/framework-virtualization/src/android/system/virtualmachine/VirtualMachineCustomImageConfig.java
- https://android.googlesource.com/platform/frameworks/base/+/refs/heads/android16-release/services/core/java/com/android/server/am/ActivityManagerService.java
