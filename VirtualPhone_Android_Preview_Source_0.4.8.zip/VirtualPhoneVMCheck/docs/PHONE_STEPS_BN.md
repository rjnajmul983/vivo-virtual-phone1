# VirtualPhone 0.4.8 — Termux থেকে পরীক্ষামূলক launch

১. APK দিয়ে আগের VirtualPhone অ্যাপ Update করুন; uninstall করবেন না।
২. আগের Wireless ADB-connected Termux-এ চালান:

    adb shell am instrument --no-hidden-api-checks -w com.virtualphone.vmcheck/.VmSessionInstrumentation

৩. অ্যাপের পরীক্ষামূলক session খুলবে। Termux-এর command চলমান রাখুন।
৩ক. VM বন্ধ অবস্থায় উপরের **RAM** বোতাম থেকে **3 GB** বেছে নিন। ফোনে পর্যাপ্ত
    খালি RAM না থাকলে VM শুরু হবে না—সে ক্ষেত্রে 2 GB-তে ফিরে আসুন। এটি
    শুধু guest RAM-এর পরীক্ষা; host display service এখনো অনুপস্থিত।
৪. Copy report-এ `apiCheck.passed=true` হলে আবশ্যক Java/native API যাচাই সফল।
   `displayServiceObservation.lazyStartReadinessCheckPassed=false` থাকলেও
   এখন সেটি আলাদা diagnostic; VM screen কাজ করছে এমন কোনো নিশ্চয়তা নয়।
৫. আগের 0.4.5-এ Android image প্রস্তুত হয়ে থাকলে **আবার নামাবেন না**;
   আগের disk/data-ই ব্যবহার হবে। না থাকলে আপনি প্রায় ১.১ GB official image download করতে প্রস্তুত থাকলে
   `Android নামান` চাপুন। অন্তত ১৪ GB খালি জায়গা রাখুন। আগে image প্রস্তুত
   থাকলে আগের disk/data-ই ব্যবহার হবে; uninstall করবেন না।
৬. `Start` চাপুন। Boot চলাকালীন ফোন চার্জে রাখুন, অ্যাপ ও Termux session
   খোলা রাখুন। Android boot সম্পূর্ণ হওয়ার পর স্ক্রিন কালো থাকলে **Graphics test** চাপুন।
   পরীক্ষা শেষ হলে **Copy report** পাঠান। ইতিপূর্বে `screencap` timeout হয়েছে,
   তাই এই নতুন পরীক্ষায় SurfaceFlinger, GPU device ও crash log দেখা হবে।
   চাইলে **Screen snapshot** আবার চেষ্টা করতে পারেন।
   সফল হলে Guest-এর একটি স্থির ছবি দেখাবে। এটি live screen নয়; ছবি বদলালে
   আবার বোতামটি চাপতে হবে। **Live view** চাপলে স্থির ছবিটি সরিয়ে সরাসরি
   Surface view-তে ফিরে যাবে।
৭. স্ক্রিন কালো থাকলে `Copy report` পাঠান, বিশেষ করে
   `guestBootDevice`, `guestBootDeviceSource`, `vmRunReturned`,
   `guestSuperByNameMissing`, `guestKernelPanicDetected`, `androidBootCompleted`,
   `guestGraphicsDiagnostics`, `memoryBytes`, `hostMemoryAtStart`,
   `guestScreenshotVerified`, `guestScreenshotError`,
   `displayJavaLookupError`, `displayStage`, `displayError`, `stopReason`।
৮. VM চলার সময় Stop দিয়ে বন্ধ করুন; তারপর End ADB session দিয়ে session শেষ করুন।

এটি শুধু VirtualPhone-এর process-এর Android testing mode। এই flow global API
setting লেখে না। তাই global exemption null থাকলেও সেটি launch ব্যর্থ হওয়ার
প্রমাণ নয়। প্রতিবার নতুন process/session এই command দিয়ে খুলতে হবে।

Vivo-তে Android system boot রিপোর্টে নিশ্চিত হয়েছে; কিন্তু display এখনও অসম্পূর্ণ।
এখনও অসম্পূর্ণ/যাচাই বাকি: live display/network,
প্রতি-app root manager, Chrome/games, hardware 3D/audio ও background lifecycle।
