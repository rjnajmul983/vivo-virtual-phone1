# 0.4.6 — Vivo boot success, blank-screen diagnosis

The 0.4.5 physical Vivo V2507A report established that the guest boot marker
was received after 67,975 ms (`androidBootCompleted=true`). VM.run() returned
without error and the VM remained running, but the host display Binder was not
found (`displayStage=lookupVirtualizationService`, `displaySurfaceConnected=false`).
The guest console UWB/Bluetooth service errors are insufficient to explain the
host-to-guest display Surface failure.

## New independent checks

1. Native AServiceManager check, then Java `android.os.ServiceManager.checkService`
   through the app-only instrumentation's hidden API test mode. The Java lookup
   result/error is recorded separately. If both return null, the existing
   bounded native service request and explicit error reporting remain.
2. After confirmed guest boot, **Screen snapshot** invokes `screencap -p`
   inside the VM over the already-owned serial console, not on the host.
   Screenshot size is bounded to 6 MiB, transferred in 32-KiB Base64 chunks,
   SHA-256-checked against the guest and then PNG-decoded. Success records
   `guestScreenshotVerified`, dimensions and byte count; failure records
   `guestScreenshotError`.
3. The still image overlays the viewport only on user request, and **Live view**
   clears it. Touches continue to target the guest VM, but the preview does
   not refresh automatically. It does not guarantee that all guest UI services
   or an interactive frame are functioning.

## Test boundaries

The APK compiles and signs for arm64/SDK 36. Pure Java tests validate wrapped
Base64 guest transfer and rejection of unexpected byte lengths. No physical
Vivo test of this new screenshot path, no live Surface display, no root apps,
Chrome, Free Fire or GPU graphics has yet been verified. APK update preserves
the app package, test signing identity, downloaded image and guest disks.

## What to report

Run the app through the same `am instrument --no-hidden-api-checks` command,
press Start, wait for Android boot completion, then Screen snapshot. Send the
visible preview or the new screenshot-related report fields, plus
`displayStage`, `displayError`, `displayServiceAfterVmRun`.
