# 0.4.2 — API setup state and lazy Binder readiness

The user supplied a 0.4.1 report from vivo V2507A/API 36. Both VM permissions
were granted. Twenty-six checks failed; custom-image constructors/methods were
not visible, while normal System APIs were visible. The actual Termux setup
output was not supplied, so whether manual setup was run/applied is unknown.
The constant hiddenApiPolicyChangedByApp=false does not answer that question.

## Corrected error in our 0.4.1 preflight

0.4.1 treated checkService(null) before any VM as proof of inaccessible display
service. That was an incorrect readiness assumption: AVF's system service is
registered lazily. Null from a passive lookup alone cannot prove denial.

0.4.2 resolves Java/native display symbols independently, records the idle lookup
as an observation, and does NOT mark it as graphics success or proven denial.
When all required API checks pass, it requests the standard system service
through Binder NDK getService (AOSP's bounded lazy-start lookup), on the worker.
If the system Binder is still missing after that request, readiness fails and
image download is blocked. No VM is created by this readiness lookup. This does
not bypass permissions/SELinux. Runtime display Surface/boot/frame validation
remain mandatory after starting the real VM. Runtime lookup uses the same
lazy-start fallback.

## Setup evidence

API reports now include read-only coverage of the required AVF descriptors by
the current hidden_api_blacklist_exemptions setting. Only coverage of our
known descriptors is reported, not unrelated exemption contents. Read failures
are unknown, not proof that setup was not performed. Coverage does not prove a
running app has applied the setting; constructor/method checks remain decisive.

Setup command output now includes VP_AVF_SETUP action, verified setting state,
change/no-change status and restart request. It preserves earlier entries and
has restore support as documented for 0.4.1. It must be explicitly run by the
user through their existing Termux Wireless ADB connection. The APK does not
run it or change policy automatically.

## Tests

The actual AndroidDisplay.java and actual native/display_bridge.c were tested
on the host with SDK/AIDL declarations and a mock Binder NDK returning null.
The test confirms passive absence is an observation, a lazy-start request is
actually issued by the native bridge, and continued absence still fails
readiness. Prefix coverage cases include absent, exact/nested, broader,
unrelated and whole-setting wildcard values. The setup script's preservation,
idempotence, rollback and denied-write mock tests also pass.

This is a host regression test, not physical Android Binder/SELinux or display
certification. No 0.4.2 APK has yet been tested on the user's Vivo. Earlier local
QEMU guest boot/import evidence remains historical.

## Phone steps

Update without uninstalling. Tap API check. If still blocked, use Setup
নির্দেশনা → Copy ADB setup in the new app and run it in the previously connected
Termux. Keep the VP_AVF_SETUP lines or any error. Then run API check again and
send Copy report along with the Termux result. Passing the API/readiness checks
allows image preparation but does not certify guest boot/rendering.

Primary sources:
- https://android.googlesource.com/platform/packages/modules/Virtualization/+/refs/heads/android16-release/android/virtualizationservice/src/main.rs
- https://android.googlesource.com/platform/frameworks/native/+/refs/heads/android16-release/libs/binder/ndk/service_manager.cpp
- https://android.googlesource.com/platform/frameworks/native/+/refs/heads/android16-release/libs/binder/IServiceManager.cpp
- https://developer.android.com/guide/app-compatibility/restrictions-non-sdk-interfaces
