# 0.4.8 — Guest memory comparison after the physical Vivo graphics report

The phone's 0.4.7 read-only guest diagnostics show:

- `sys.boot_completed=1`, SurfaceFlinger running, and live guest graphics
  services (SurfaceFlinger, SurfaceFlingerAIDL, display, window).
- `/dev/dri/card0` and `/dev/dri/renderD128` exist.
- `android.hardware.graphics.allocator-service.minigbm` was in `D` state,
  which may be uninterruptible kernel/device I/O wait; not proof of the cause.
- Guest memory: 1967 MiB total, 1889 MiB used, only 77 MiB free (no swap in use).
- Crash buffer showed `libbluetooth_jni.so`, not a graphics process.
- Independent host ADB command: `Service android.system.virtualizationservice:
  not found`. This is distinct from guest memory pressure.

The official AOSP vmlauncher example configures 8 GiB RAM for its sample
custom VM; the physical Vivo is a 12 GiB device and cannot safely assume 8 GiB
is free. Therefore 0.4.8 offers explicit, individually named 2/3/4 GiB VM
profiles and checks that host `availMem` exceeds the requested size by 768 MiB
before proceeding. The user must select the profile; the default remains the
known-running 2 GiB profile. The same existing Android guest disks are reused
for all memory profiles. Running two profiles concurrently is unsupported.

No host SELinux setting, app permission or root access is changed. This test
does not bypass the missing host display service and is not an interactive
graphics solution. It may also fail to fix a stuck guest graphics allocator.

## Test protocol

1. Keep the current app-only ADB instrumentation active, update APK in place.
2. With guest stopped, choose 3 GB from RAM. If Start reports insufficient
   host memory, revert to 2 GB; do not force an unsafe allocation.
3. Wait for `androidBootCompleted=true` and run Graphics test. Check
   `memoryBytes`, `hostMemoryAtStart`, guest `free -m`, `allocatorWaitState`.
4. Try a single Screen snapshot. If the screenshot still times out, Stop the
   VM; more retries won't fix a stalled compositor.
5. Send Copy report. Live Surface display remains blocked by the absent
   host virtualizationservice Binder unless an authorized compatible host
   display path becomes available.
