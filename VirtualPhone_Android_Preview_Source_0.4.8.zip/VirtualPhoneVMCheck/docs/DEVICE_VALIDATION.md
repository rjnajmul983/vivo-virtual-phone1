# Target-phone validation — 2026-10-26

Evidence: the user's pasted report from VirtualPhone VM Check 0.2.0, timestamp
2026-10-26T04:37:38Z. The console text was truncated at the end of the chat
message, but the relevant callbacks, cleanup fields and guest marker are present.
This is recorded device evidence supplied by the user, not a new remote test.

| Observation | Result |
|---|---|
| Target | vivo/iQOO V2507A, Android 16/API 36, ARM64, user states host is non-rooted |
| MANAGE_VIRTUAL_MACHINE / USE_CUSTOM_VIRTUAL_MACHINE | Both granted |
| AVF capabilities | 3 (protected and non-protected support advertised) |
| VM exercised | Non-protected Microdroid, 256 MiB, diagnostic debug mode |
| Payload started | 749 ms |
| Payload ready | 758 ms |
| Payload finished | 759 ms, actual exit code 42 |
| VM stopped | 908 ms, reported reason 3 |
| Overall test | 1542 ms, no timeout, cleanupSucceeded=true |
| Host kernel | 6.6.127-android15-8-g24b70dd1cb81-abogki543702391-4k |
| Guest kernel | 6.6.77-android15-8-g5e64546a6601-ab13109490 |
| Guest payload identity | UID 6000, PID 65, aarch64 |

The real guest kernel and native payload ran on this firmware through the
authorized AVF broker. Raw /dev/kvm being unavailable in the app's view did not
prevent this path. This is stronger evidence than a feature flag or permission
check alone. The guest payload was **not root**; no su/root-app success follows.

The log's missing-directory/property-access messages did not prevent this
specific payload from completing with the expected result. They do not establish
compatibility with a full Android image.

## Original 0.2 checkpoint (superseded for local-image work)

- A compatible full Android system/vendor/userdata image and Android framework.
- Custom Android kernel/ramdisk image boot and persistent guest storage.
- Guest display, touch, accelerated 3D, network, audio and device integration.
- File manager, controlled host-file/APK imports, and guest root permission manager.
- Chrome, Free Fire, other games/root apps, and complete host-identity concealment.
- Production isolation. This test deliberately used a non-protected debug guest.

Microdroid lacks the Android Java UI APIs, Zygote and SystemServer needed by
ordinary Android apps; it must not be relabeled as a complete Android phone.

## Full-image build constraint

The current execution workspace has a 32 GiB filesystem. A complete AOSP source
build cannot be attempted faithfully in that space. Google's current development
requirements specify at least 400 GB free disk space and 64 GB RAM. A suitable
prebuilt ARM64 Cuttlefish image is another candidate, but it still needs AVF
boot/display/device adaptation; compatibility with this phone is not established.
A full guest image port was subsequently prepared in 0.3; see ANDROID_PORT_STATUS.md. That local work does not establish full Android compatibility on the physical phone.

Primary references:
- https://source.android.com/docs/setup/start/requirements
- https://source.android.com/docs/core/virtualization/microdroid
- https://source.android.com/docs/devices/cuttlefish/get-started

## 0.4 update

The earlier Microdroid evidence above remains valid. The source now includes guest console commands and selected file/APK import. Full Android boot/display on the physical V2507A and these new host-to-guest paths remain untested on that phone. No repeat Microdroid test is required.
