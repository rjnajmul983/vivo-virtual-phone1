# 0.4.3 — app-only Android instrumentation session

## Device evidence and reason for this change

On the user's vivo V2507A/Android 16, the scoped exemption setup returned exit
zero while the setting read back null. Both current and saved previous values
were null. A direct literal settings put also returned PUT_EXIT=0 / VALUE=null.
We cannot make the successful exit code a claim that a setting changed. The
OEM-specific cause has not been established. Repeating that setting write is
not part of the new launch flow.

## Implementation

The APK registers VmSessionInstrumentation targeting only com.virtualphone.vmcheck.
The Android shell starts it with the documented am instrument
--no-hidden-api-checks flag. That flag is applied by Android to the instrumented
app process. The APK never calls VMRuntime's policy setter or writes global
API settings. The app remains its normal UID; this is not host root and does
not grant missing VM permissions or SELinux access to the display system.

At startup the runner records an API check, reports a short status to the ADB
console, and opens the existing VM activity. It stays alive during the debug
session. Closing a finishing Activity or choosing End ADB session requests
cleanup. Stop the VM before ending the session. An explicit force-stop remains
available for this package. The guest disk paths and signing certificate stay
unchanged.

This is a development launch mode that must be used again for a new app process.
It is not a finished standalone VM release. Kernel boot, display/Surface access,
input, networking, per-app root approval and application/game compatibility are
still independent requirements. The native display readiness gate remains in
place before the large image download.

## Phone-only launch in Termux

Update over the installed app. Keep the existing Wireless ADB connection.
Run:

    adb shell am instrument --no-hidden-api-checks -w com.virtualphone.vmcheck/.VmSessionInstrumentation

If more than one transport is connected, use -s with the currently connected
phone's IP:port. The app's Setup নির্দেশনা dialog copies the same launch command.
Keep the Termux command/session running while using the app. It prints VP_SESSION
status. Send Copy report after it opens, especially if native display readiness
still fails. No large Android download is required for this API/session check.

## Validation scope

The built APK is tested under local AOSP ARM64 Android 17 with ordinary
instrumentation and with the app-only no-hidden-api-checks flag. The read-only
probe looks up metadata of a restricted member; it never invokes that member.
The test also compares the global exemption setting before and after. This is
not the physical vivo firmware. Actual results are recorded separately in
LOCAL_SESSION_0_4_3.json. A local development image cannot establish access on
the Vivo's production SELinux policy.

The local image exposes sendKeyEvent(short, boolean), while earlier AOSP
revisions use sendKeyEvent(KeyEvent). Preflight and navigation now resolve both
known signatures. The adapter preserves Linux scan codes and down/up order;
a false return is recorded as input rejection. Runtime guest input still needs
physical-phone validation.

## Actual local result

The final 0.4.3 APK installed and ran on the local ARM64 AOSP Android 17 guest.
Default instrumentation failed 23 accessibility checks. With the Android testing
flag, all required Java API lookups and native interface symbols passed. The
restricted metadata lookup changed from unavailable to available. The global
exemption setting was unchanged. The actual AndroidActivity resumed during the
app-only session (ActivityManager evidence is included).

Preflight still failed its final display system Binder readiness check, after
requesting lazy startup. It correctly kept large-image preparation blocked.
This result is not a successful runtime display test or a diagnosis of the
Vivo service policy. The local development OS uses permissive SELinux; the app
process still runs at its own normal UID. No full AVF Android guest was started
during this session test. The local APK was force-stopped after verifying that
its Activity resumed. The in-app End ADB session control was not automated.

The keyboard adapter's separate Java regression exercises old KeyEvent input,
new scan-code down/up input and a false/rejected result. It does not establish
physical guest keyboard delivery.

Primary reference:
https://developer.android.com/studio/test/command-line#AMOptionsSyntax
