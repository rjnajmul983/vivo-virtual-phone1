# 0.4.7: Isolate guest GPU/compositor from missing host display service

## Evidence on Vivo V2507A

- 0.4.5: `androidBootCompleted=true`; host Java/native display Binder unavailable;
  no host Surface connected.
- 0.4.6: after app-only ADB instrumentation, VM ran, but screenshot capture
  inside guest returned `Guest exit 124` (the 30-second command timeout).
  The captured serial console also contained `crash_dump64` messages without
  identifying the process that failed.
- Boot parameters currently include `androidboot.enable_bootanimation=0`.
  Re-enabling an animation cannot remedy an unconnected host display Surface.

## What this build changes

After guest boot, tap **Graphics test**. This performs only read-only commands
inside the VM on its existing serial connection, sequentially:

1. `getprop`, `id`, `free`: boot state, SurfaceFlinger/bootanim state,
   renderer properties and VM memory.
2. `ls`: graphics device nodes in the guest.
3. `ps`: compositor and graphics HAL processes.
4. `service check`: guest graphics and window Binder registration.
5. `timeout 5 dumpsys SurfaceFlinger --display-id`: guest display output.
6. Filtered recent graphics messages and guest crash buffer.

Every operation has a bounded guest command. The report stores outputs and
exit codes under `guestGraphicsDiagnostics`. A host-side serial-console loss
halts further probing; Stop/Start the guest before another command.

No host global setting, SELinux policy, root access or user data is changed.
Guest-disk, app package and test signing identity remain unchanged.

The `Graphics test` result and independent host service lookup decide the next
fix. If guest `/dev/dri` is absent or SurfaceFlinger is stopped, inspect guest
graphics configuration/image support. If guest rendering is healthy but the
host Binder remains unregistered or inaccessible, the phone's OEM AVF display
capability or app privilege boundary may be the blocker; a UI-only change
cannot make the host compositor connect.

An ADB shell-side, **host-only and read-only** comparison can be collected in
the already-connected Termux session without modifying hidden-API settings:

    adb shell service check android.system.virtualizationservice
    adb shell service list | grep -i -E 'virtual|crosvm'

If shell can see the service but this app cannot, an app access restriction
becomes more likely. If neither sees it, the service may be unregistered or
the OEM may expose a different graphics path. These are observations only;
they do not grant host privileges or prove rendering support.

Official AOSP `vmlauncher_app` obtains
`ServiceManager.waitForService("android.system.virtualizationservice")`,
calls `waitDisplayService()` and then attaches a Surface via
`ICrosvmAndroidDisplayService.setSurface()`:
https://android.googlesource.com/platform/packages/modules/Virtualization/+/00a957331c1724cf9bc925faeed147b0e23cfc8b/vmlauncher_app/java/com/android/virtualization/vmlauncher/MainActivity.java

## Product gates

1. **Graphics**: guest compositor + host Surface must display a verified, live
   Android frame, with touch input functioning on the Vivo.
2. **Boot/Home**: enable actual Android boot animation; verify launcher and
   first-use setup without relying on synthetic splash screens.
3. **Full screen**: replace diagnostics-first layout with edge-to-edge guest
   display; retain hidden troubleshooting entry.
4. **Apps/root/games**: verify guest package manager, file manager, per-app
   privilege confirmation and performance on specific Chrome/APK/OBB/game
   samples. A permissive guest SELinux setting is not an app-granted root
   manager. 2D guest graphics do not establish 3D game compatibility.

None of gates 1–4 can be marked complete based on this build alone.
