# VirtualPhone 0.4.4 — idle Binder vs. runtime display

## Observed on the Vivo V2507A

The user ran `am instrument --no-hidden-api-checks` on Android 16/API 36.
Required Java/native custom VM interfaces were accessible, including the
AVF keyboard and display AIDL surface. The sole 0.4.3 failure was an idle
`android.system.virtualizationservice` Binder lookup after a lazy-start
request. A null Binder did not prove a permission denial or broken GPU.
The user's physical full Android guest was never run in that report.

## Corrected decision in 0.4.4

- `apiCheck.passed` reflects **required** Java/native accessibility only.
- `apiCheck.displayServiceObservation.lazyStartObservation` captures an idle
  Binder lookup separately. `requiredForJavaPreflight` is false.
- An unavailable idle display service does not prevent preparing an official
  guest image or attempting `VirtualMachine.run()`. A real runtime permission or
  service error still fails at its actual stage; it is never bypassed.
- After VM start, the report distinguishes `vmRunReturned`,
  `displayServiceBeforeVmRun`, `displayServiceAfterVmRun`, `displayStage`,
  `displaySurfaceConnected`, `displayError`, and `androidBootCompleted`.
- The `Display check` button can collect a separate lazy-start Binder
  observation. It does not render a guest frame.

## Interpret new report

1. `apiCheck.passed=false`: a required interface or permission remains blocked.
2. `apiCheck.passed=true` + idle Binder false: Java interface discovery passed;
   service runtime and graphics are **unverified**, not necessarily denied.
3. `vmRunReturned=false` + `error`: inspect the guest creation/start error.
4. `vmRunReturned=true` + `displayStage=lookupVirtualizationService` +
   `displayError`: the display bridge cannot resolve the service under this UID
   after the guest run request.
5. `displayStage=waitDisplayService` + `displayError`: service was found, but
   obtaining the crosvm display channel failed; error details matter.
6. `displayStage=setSurface` + `displayError`: display channel was found but
   Surface connection failed.
7. `displaySurfaceConnected=true`: Surface call succeeded; still verify visible
   frames, touch, and launcher on the **physical Vivo** separately.
8. `androidBootCompleted=true`: console marker was received; does not prove a
   rendered Android home screen.

No SELinux policy, host root, global hidden API exemption or Binder transaction
IDs are changed. The app remains at its existing UID. Test with the same
signing key and package; **update, never uninstall**, to preserve guest data.

## Evidence and limits

The 0.4.4 APK was built with Android SDK 36 and an arm64 16 KiB-aligned native
bridge. Signature, alignment and Java preflight policy regression were tested
locally. The user still needs to test full boot and graphics on their Vivo.
Per-app guest root approval, Chrome/games, hardware acceleration and audio
remain future work.

Primary AOSP implementation reference:
https://android.googlesource.com/platform/packages/modules/Virtualization/+/00a957331c1724cf9bc925faeed147b0e23cfc8b/vmlauncher_app/java/com/android/virtualization/vmlauncher/MainActivity.java
