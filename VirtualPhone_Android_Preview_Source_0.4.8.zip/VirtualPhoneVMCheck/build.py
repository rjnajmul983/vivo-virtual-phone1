#!/usr/bin/env python3
"""Build a dependency-free diagnostic APK with a complete JDK 17 and SDK 36.

Signing credentials are intentionally public test credentials, never production.
All tool paths are structured subprocess arguments; no shell command strings.
"""
import argparse,os,shutil,subprocess,zipfile,re
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--android-jar',required=True,type=Path)
p.add_argument('--build-tools',required=True,type=Path)
p.add_argument('--output',type=Path,default=Path('build'))
p.add_argument('--zig',type=Path,help='Zig 0.14.1 executable (cross C compiler)')
p.add_argument('--ndk',type=Path,help='Alternative: Android NDK directory containing LLVM')
a=p.parse_args()
root=Path(__file__).resolve().parent
out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
tools=a.build_tools.resolve();android=a.android_jar.resolve()
def run(args):subprocess.run([str(v) for v in args],check=True,cwd=root)
def tool(name):
    path=tools/name
    if not path.is_file():raise SystemExit('Missing Android build tool: '+str(path))
    return path

for name in ['classes','dex','compiled','generated']:
    folder=out/name
    if folder.exists():shutil.rmtree(folder)
    folder.mkdir()
native=out/'native';native.mkdir(exist_ok=True)
if a.zig:
    compiler=[a.zig.resolve(),'cc','-target','aarch64-linux-android']
elif a.ndk:
    candidates=list(a.ndk.resolve().glob('toolchains/llvm/prebuilt/*/bin/aarch64-linux-android26-clang'))
    if not candidates:raise SystemExit('NDK ARM64 API 26 clang wrapper not found')
    compiler=[candidates[0]]
else:raise SystemExit('Supply --zig /path/to/zig or --ndk /path/to/android-ndk')
flags=['-O2','-shared','-fPIC','-nostdlib','-ffreestanding','-fno-builtin','-fno-stack-protector',
       '-Wl,-z,max-page-size=16384','-Wl,--no-undefined']
# Build-time-only stable-API link stub. Do NOT ship it; Microdroid supplies the
# real library at runtime, as specified by the AOSP VM Payload API.
stub=native/'ready_stub.c';stub.write_text('void AVmPayload_notifyPayloadReady(void) {}\n')
run([*compiler,*flags,'-Wl,-soname,libvm_payload.so',stub,'-o',native/'libvm_payload.so'])
payload=native/'libvp_guest_probe.so'
run([*compiler,*flags,'-Wl,-soname,libvp_guest_probe.so',root/'native/guest_probe.c',
     '-L'+str(native),'-lvm_payload','-o',payload])
# Link only against a build-time Binder-NDK symbol stub; Android provides the
# real libbinder_ndk.so. The stub is never packaged in the APK.
binder_stub=native/'binder_stub.c'
binder_stub.write_text('void *AServiceManager_checkService(const char *n){return 0;}\n'
                       'void *AServiceManager_getService(const char *n){return 0;}\n'
                       'void *AIBinder_toJavaBinder(void *e,void *b){return 0;}\n'
                       'void AIBinder_decStrong(void *b){}\n')
run([*compiler,*flags,'-Wl,-soname,libbinder_ndk.so',binder_stub,'-o',native/'libbinder_ndk.so'])
bridge=native/'libvp_display_bridge.so'
run([*compiler,*flags,'-Wl,-soname,libvp_display_bridge.so',root/'native/display_bridge.c',
     '-L'+str(native),'-lbinder_ndk','-o',bridge])

# Compile published AOSP Android 16 AIDL declarations, including their complete
# method order. No handwritten Binder transaction IDs are used.
aidl_root=root/'aidl';selected=set();pending=[
 'android.system.virtualizationservice_internal.IVirtualizationServiceInternal',
 'android.crosvm.ICrosvmAndroidDisplayService']
while pending:
    name=pending.pop()
    if name in selected:continue
    file=aidl_root/(name.replace('.','/')+'.aidl')
    if not file.is_file():raise SystemExit('Missing AIDL declaration: '+name)
    selected.add(name)
    for dependency in re.findall(r'^import\s+([\w.]+);',file.read_text(),re.M):
        if (aidl_root/(dependency.replace('.','/')+'.aidl')).is_file():pending.append(dependency)
for name in sorted(selected):
    file=aidl_root/(name.replace('.','/')+'.aidl')
    run([tool('aidl'),'--min_sdk_version=36','-I'+str(aidl_root),'-p'+str(android.parent/'framework.aidl'),
         '-o'+str(out/'generated'),file])
run([tool('aapt2'),'compile','--dir',root/'res','-o',out/'compiled'])
compiled=sorted((out/'compiled').glob('*.flat'))
run([tool('aapt2'),'link','-I',android,'--manifest',root/'AndroidManifest.xml',
     '-A',root/'assets','--auto-add-overlay','-o',out/'resources.apk',*compiled])
sources=sorted((root/'src').rglob('*.java'))+sorted((out/'generated').rglob('*.java'))
run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-encoding','UTF-8',
     '--release','8','-classpath',android,'-d',out/'classes',*sources])
jar=out/'classes.jar'
with zipfile.ZipFile(jar,'w') as z:
    for file in sorted((out/'classes').rglob('*.class')):z.write(file,file.relative_to(out/'classes'))
run([tool('d8'),'--release','--min-api','36','--lib',android,'--output',out/'dex',jar])
unsigned=out/'unsigned.apk';shutil.copyfile(out/'resources.apk',unsigned)
with zipfile.ZipFile(unsigned,'a',compression=zipfile.ZIP_DEFLATED) as z:
    for file in sorted((out/'dex').glob('*.dex')):z.write(file,file.name)
    z.write(payload,'lib/arm64-v8a/libvp_guest_probe.so',compress_type=zipfile.ZIP_STORED)
    z.write(bridge,'lib/arm64-v8a/libvp_display_bridge.so',compress_type=zipfile.ZIP_STORED)
aligned=out/'aligned.apk'
run([tool('zipalign'),'-f','-P','16','4',unsigned,aligned])
key=root/'test-signing'/'vmcheck-test.keystore';key.parent.mkdir(exist_ok=True)
if not key.exists():raise SystemExit('Recover the existing test key; do not generate a replacement key for an update.')
apk=out/'VirtualPhone_Android_Preview_0.4.8.apk'
run([tool('apksigner'),'sign','--ks',key,'--ks-key-alias','vmcheck','--ks-pass','pass:android',
     '--key-pass','pass:android','--min-sdk-version','36','--out',apk,aligned])
run([tool('apksigner'),'verify','--verbose',apk])
print('Built:',apk)
