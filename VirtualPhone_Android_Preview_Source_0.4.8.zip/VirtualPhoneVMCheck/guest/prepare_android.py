#!/usr/bin/env python3
"""Prepare the pinned public Cuttlefish image for an isolated AVF boot experiment.

This is a porting tool, not a claim that the resulting image boots on a phone.
Never use its output to flash a physical device. All paths are guest files.
"""
import argparse
import binascii
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import uuid


def read_newc(data):
    result = {}
    p = 0
    while p + 110 <= len(data):
        if data[p:p+6] not in (b'070701', b'070702'):
            raise ValueError('Invalid newc header at ' + str(p))
        fields = [int(data[p+6+8*i:p+14+8*i], 16) for i in range(13)]
        namesize, size = fields[11], fields[6]
        start = p + 110
        name = data[start:start+namesize-1].decode()
        p = (start + namesize + 3) & ~3
        content = data[p:p+size]
        if len(content) != size:
            raise ValueError('Truncated newc member')
        p = (p + size + 3) & ~3
        if name == 'TRAILER!!!':
            break
        result[name] = (fields, content)
    return result


def write_newc(members):
    out = bytearray()
    entries = list(members.items()) + [('TRAILER!!!', ([0]*13, b''))]
    for index, (name, (fields, content)) in enumerate(entries):
        f = list(fields)
        f[0] = index + 1
        f[6], f[11], f[12] = len(content), len(name.encode()) + 1, 0
        out += b'070701' + b''.join(('%08x' % x).encode() for x in f)
        out += name.encode() + b'\0'
        out += b'\0' * (-len(out) % 4)
        out += content
        out += b'\0' * (-len(out) % 4)
    out += b'\0' * (-len(out) % 512)
    return bytes(out)


def patch_fstab(text):
    lines = []
    for line in text.splitlines():
        words = line.split()
        if not words or line.lstrip().startswith('#'):
            lines.append(line)
            continue
        if len(words) != 5:
            raise ValueError('Unexpected fstab line: ' + line)
        # A direct kernel/initrd boot has no Android bootloader/recovery slots.
        # First-stage init otherwise waits for boot_a and init_boot_a as well.
        if 'recoveryonly' in words[4].split(','):
            continue
        # AVB signatures of the original vendor image cannot certify our port.
        flags = [x for x in words[4].split(',')
                 if not (x == 'avb' or x.startswith(('avb=', 'avb_keys=')))]
        if words[1] == '/data':
            # Initial boot experiment uses a new, empty private guest volume.
            # This deliberately does not offer guest disk encryption yet.
            flags = [x for x in flags if not x.startswith(
                ('fileencryption=', 'keydirectory=', 'metadata_encryption=', 'checkpoint='))]
        words[4] = ','.join(flags)
        lines.append(' '.join(words))
    return '\n'.join(lines) + '\n'


def add_file(members, name, content, mode=0o100644):
    fields = [0, mode, 0, 0, 1, 1230768000, len(content), 0, 0, 0, 0, 0, 0]
    members[name] = (fields, content)


def partition_metadata(image):
    """Read and verify Android liblp primary slot-zero metadata."""
    with Path(image).open('rb') as f:
        f.seek(4096)
        g = f.read(52)
        if len(g) != 52 or struct.unpack_from('<I', g)[0] != 0x616c4467:
            raise ValueError('Invalid liblp geometry')
        check = g[8:40]
        if hashlib.sha256(g[:8] + b'\0'*32 + g[40:]).digest() != check:
            raise ValueError('Invalid liblp geometry checksum')
        f.seek(12288)
        h = f.read(256)
        if struct.unpack_from('<I', h)[0] != 0x414c5030:
            raise ValueError('Invalid liblp header')
        header_size, = struct.unpack_from('<I', h, 8)
        if header_size not in (128, 256):
            raise ValueError('Unsupported liblp header size')
        h = h[:header_size]
        if hashlib.sha256(h[:12] + b'\0'*32 + h[44:]).digest() != h[12:44]:
            raise ValueError('Invalid liblp header checksum')
        size, = struct.unpack_from('<I', h, 44)
        if size > 4*1024*1024:
            raise ValueError('Excessive liblp table size')
        f.seek(12288+header_size)
        tables = f.read(size)
        if hashlib.sha256(tables).digest() != h[48:80]:
            raise ValueError('Invalid liblp table checksum')
        po, pc, ps = struct.unpack_from('<III', h, 80)
        eo, ec, es = struct.unpack_from('<III', h, 92)
        if ps != 52 or es != 24 or po+pc*ps > size or eo+ec*es > size:
            raise ValueError('Invalid liblp table bounds')
        result = []
        for i in range(pc):
            name, attrs, first, count, group = struct.unpack_from('<36sIIII', tables, po+i*ps)
            if first+count > ec:
                raise ValueError('Invalid liblp extent range')
            extents = [struct.unpack_from('<QIQI', tables, eo+j*es)
                       for j in range(first, first+count)]
            result.append((name.rstrip(b'\0').decode(), attrs, extents))
        return result


def make_gpt(output, parts):
    """Create a sparse GPT disk for the local QEMU test; AVF supplies its own GPT."""
    sector = 512
    entries = bytearray(128*128)
    ranges, next_sector = [], 2048
    for i, (name, path) in enumerate(parts):
        length = (Path(path).stat().st_size + sector-1) // sector
        first, last = next_sector, next_sector+length-1
        part_type = uuid.UUID('0fc63daf-8483-4772-8e79-3d69d8477de4').bytes_le
        struct.pack_into('<16s16sQQQ72s', entries, i*128, part_type,
                         uuid.uuid4().bytes_le, first, last, 0, name.encode('utf-16le'))
        ranges.append((path, first, length))
        next_sector = ((last+1+2047)//2048)*2048
    sectors = next_sector + 2048
    guid = uuid.uuid4().bytes_le
    table_crc = binascii.crc32(entries)

    def header(current, backup, table):
        h = bytearray(512)
        struct.pack_into('<8sIIIIQQQQ16sQIII', h, 0, b'EFI PART', 0x10000, 92,
                         0, 0, current, backup, 34, sectors-34, guid, table, 128, 128, table_crc)
        struct.pack_into('<I', h, 16, binascii.crc32(h[:92]))
        return h

    with Path(output).open('wb') as w:
        w.truncate(sectors*sector)
        mbr = bytearray(512)
        struct.pack_into('<B3sB3sII', mbr, 446, 0, b'\0\x02\0', 0xee,
                         b'\xff\xff\xff', 1, min(sectors-1, 0xffffffff))
        mbr[510:512] = b'\x55\xaa'
        w.write(mbr)
        w.write(header(1, sectors-1, 2))
        w.write(entries)
        w.seek((sectors-33)*sector)
        w.write(entries)
        w.write(header(sectors-1, 1, sectors-33))
        for path, first, length in ranges:
            w.seek(first*sector)
            with Path(path).open('rb') as r:
                # Preserve sparse zero regions of super/userdata in the test disk.
                while data := r.read(1024*1024):
                    if data.strip(b'\0'):
                        w.write(data)
                    else:
                        w.seek(len(data), 1)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--images', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    out = a.output
    out.mkdir(parents=True, exist_ok=True)
    members = read_newc((a.images/'vendor.cpio').read_bytes())
    members.update(read_newc((a.images/'init.cpio').read_bytes()))
    for name, (fields, content) in list(members.items()):
        if '/fstab.cf.' in name:
            members[name] = (fields, patch_fstab(content.decode()).encode())
    # Generic init_boot must win over the recovery init from vendor_boot.
    if members['init'][0][1] & 0o170000 != 0o100000:
        raise ValueError('Generic init is not a regular executable')
    with gzip.open(out/'initrd.img', 'wb', compresslevel=6) as w:
        w.write(write_newc(members))
    shutil.copyfile(a.images/'boot-unpacked/kernel', out/'Image')
    print(json.dumps({'kernel': str(out/'Image'), 'initrd': str(out/'initrd.img'),
                      'members': len(members), 'status': 'PORT_NOT_BOOT_VERIFIED'}, indent=2))


if __name__ == '__main__':
    main()
