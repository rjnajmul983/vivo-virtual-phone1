# VirtualPhone Android Preview 0.4.8

Target: vivo V2507A, non-rooted Android 16/API 36, ARM64. Same app package,
public test signing certificate and private guest disk paths as earlier builds.
Update over the existing installation to retain permissions and guest data.

The user's Android settings command returned exit zero but its exemption value
remained null. Version 0.4.3 added the app-only instrumentation launch. Version
0.4.4 separated idle display Binder observation from required preflight. The
physical Vivo V2507A then executed the actual guest kernel, but its first-stage
init could not resolve /dev/block/by-name/super and panicked. The console
showed the guest PCI platform path 2e000000.pci, while the Cuttlefish bootconfig
still named the local-QEMU path 10000.pci.

Version 0.4.5 selects the guest boot device from the previous console report,
with a Vivo V2507A-specific observed fallback. It does not change the guest's
disk contents, its 1.1 GB downloaded AOSP image, or the host's physical storage.
See docs/PCI_BOOT_FIX_0_4_5.md for evidence and test scope.

The physical Vivo 0.4.5 report confirms `androidBootCompleted=true` but still
shows a blank display: neither idle nor post-run native lookup finds the host
`android.system.virtualizationservice` Binder. Version 0.4.6 adds a Java
ServiceManager lookup as a second, separately reported path. It also provides
an explicit **Screen snapshot** button to capture a PNG from the guest console,
verify its SHA-256 and show one static frame in the viewport. The **Live view**
button hides the still frame. This is not live rendering: the PNG fallback
may fail if the guest display compositor is unavailable, and real-time Surface
attachment still requires compatible host display service access.

Physical 0.4.6 testing subsequently reported `Guest exit 124` when issuing
`screencap` (the guest command hit its 30-second timeout). This does not tell
whether the guest compositor crashed, the GPU HAL hung, or the host display
service is simply unavailable. In 0.4.7 the new **Graphics test** button runs
bounded, read-only diagnostics for guest GPU device nodes, SurfaceFlinger and
display services, running processes, recent graphics logs and crash logs. It
records `guestGraphicsDiagnostics` under **Copy report**. The screenshot timeout
message is shortened to avoid presenting unrelated console traffic as a cause.
0.4.7 is a focused *diagnostic* update, not a claim that live display, launcher,
root apps, Chrome or games now work. See docs/GRAPHICS_PROBE_0_4_7.md.

The physical 0.4.7 guest graphics probe showed `sys.boot_completed=1`, running
SurfaceFlinger and composer HAL, working guest DRM nodes and graphics Binder
services. However, the minigbm allocator process was observed in state `D`,
guest free RAM was only 77 MiB out of 1967 MiB, and the host ADB shell itself
reported `Service android.system.virtualizationservice: not found`.
Bluetooth, not SurfaceFlinger, produced the captured crash backtrace. This
points to two separate issues: a possible guest graphics/memory stall and a
missing host GUI Binder route. The latter cannot be solved by a cosmetic UI.

Version 0.4.8 adds **RAM 2/3/4 GB** profiles (2 GB remains the default), a
minimum-host-available-RAM safety check, and deeper guest allocator-wait and
graphics-log diagnostics. Different VM profile names preserve the same existing
guest disk image without asking users to uninstall or re-download Android.
Try **3 GB** if the RAM chooser allows it, then rerun Graphics test and Screen
snapshot. This is a memory diagnosis, **not** a confirmed graphics fix; do not
assume that Free Fire, root apps or host display will work.

    adb shell am instrument --no-hidden-api-checks -w com.virtualphone.vmcheck/.VmSessionInstrumentation

The app's Setup নির্দেশনা dialog copies the launch command. Keep that Termux
session active while using the debug app. This applies the Android testing flag
to this app process. It does not write global API policy, change the host UID,
root the host, or confer missing VM/SELinux permissions. New processes require a
new diagnostic launch; this is not a completed standalone product.

The required custom-image Java/native interface check remains before the ~1.1 GB
official pinned AOSP image download. A missing *idle* display Binder is no longer
misclassified as a required API failure and does not block download. The
app records display service observations before and after VM.run(), plus each
display Surface attachment stage. This change permits a real boot attempt,
but does not claim the service, graphics, or full Android boot will succeed.
Guest userdata stays separate and persists over Stop/Start and app updates.

Existing implementation includes direct verified image download, sparse-image
preparation, custom Android boot configuration, bounded serial command framing,
selected binary file import with guest SHA-256, standalone APK installation and
guest root shell commands. See guest/IMAGE_PROVENANCE.json for the official image.
These are a real Android guest port, not host app cloning.

Historical local QEMU tests verified genuine Android boot, guest UID 0, binary
import, APK installation and a test app reading imported data. Full interactive
launcher/display were not certified. Physical Vivo reports now confirm system
boot, but not interactive display. Chrome, games,
per-app root approval, accelerated 3D/audio and background lifecycle remain
unfinished or unverified.

Phone instructions: docs/PHONE_STEPS_BN.md. Diagnostic interpretation and
scope: docs/MEMORY_PROFILE_0_4_8.md, docs/SCREEN_CAPTURE_0_4_6.md and docs/DISPLAY_DIAGNOSTICS_0_4_4.md. The 0.4.3 session evidence remains
in docs/APP_SESSION_0_4_3.md as a historical checkpoint.

Build with JDK 17, Python 3, SDK 36/Build Tools 36 and Zig 0.14.1 or an NDK:

    python3 build.py --android-jar /path/android.jar --build-tools /path/build-tools --zig /path/zig --output /tmp/vp-build

The public test key is intentionally retained for in-place updates, not a
production key. Build-time Binder/VM payload link stubs are never packaged.
New code MIT; bundled AOSP declarations retain their Apache 2.0 notices.
