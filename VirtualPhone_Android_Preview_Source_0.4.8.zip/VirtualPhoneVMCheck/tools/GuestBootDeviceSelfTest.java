package com.virtualphone.vmcheck;

public final class GuestBootDeviceSelfTest {
    public static void main(String[] args) {
        String vivoLog="input: Crosvm Virtio Keyboard 0 as /devices/platform/2e000000.pci/pci0000:00/0000:00:08.0/virtio7/input/input1";
        GuestBootDevice.Choice observed=GuestBootDevice.choose(vivoLog,"vivo","V2507A");
        if(!"2e000000.pci".equals(observed.path)||!"previous_guest_kernel_pci_path".equals(observed.source))throw new AssertionError("Vivo kernel evidence ignored");
        GuestBootDevice.Choice different=GuestBootDevice.choose("/devices/platform/a1230000.pci/pci0000:01/", "vivo", "V2507A");
        if(!"a1230000.pci".equals(different.path))throw new AssertionError("Evidence must override device fallback");
        if(!"2e000000.pci".equals(GuestBootDevice.choose("", "vivo", "V2507A").path))throw new AssertionError("Vivo first-update fallback missing");
        if(!"10000.pci".equals(GuestBootDevice.choose("", "Other", "Unknown").path))throw new AssertionError("QEMU fallback changed");
        if(!"10000.pci".equals(GuestBootDevice.choose("/devices/platform/not-a-pci/", "Other", "Unknown").path))throw new AssertionError("Unexpected/untrusted path accepted");
        System.out.println("PASS: guest PCI path selection from previous console, Vivo fallback, and QEMU fallback");
    }
}
