package com.virtualphone.vmcheck;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** Local porting helper using the same bootconfig encoder as the APK. */
public final class BootconfigTool {
    public static void main(String[] args)throws Exception {
        Map<String,String> params=new LinkedHashMap<>();
        Matcher m=Pattern.compile("\"([^\"]+)\"\\s*:\\s*\"([^\"]*)\"").matcher(new String(Files.readAllBytes(Paths.get(args[0])),StandardCharsets.UTF_8));
        while(m.find())params.put(m.group(1),m.group(2));
        if(args.length>3&&args[3].equals("local-qemu")) {
            params.put("console","ttyAMA0");params.put("earlycon","pl011,0x9000000");
            params.put("androidboot.boot_devices","4010000000.pcie");params.put("androidboot.hw_timeout_multiplier","50");
            params.put("androidboot.console","hvc0");params.put("androidboot.serialconsole","1");
        }
        params.put("androidboot.vp_nonce","porttest9");
        BootImages.bootconfig(new File(args[1]),new File(args[2]),params);
        try(RandomAccessFile file=new RandomAccessFile(args[2],"r")) {
            if(file.length()%4!=0)throw new AssertionError("Unaligned bootconfig");
            file.seek(file.length()-20);long size=Integer.toUnsignedLong(Integer.reverseBytes(file.readInt()));long sum=Integer.toUnsignedLong(Integer.reverseBytes(file.readInt()));byte[] magic=new byte[12];file.readFully(magic);
            if(!Arrays.equals(magic,"#BOOTCONFIG\n".getBytes(StandardCharsets.US_ASCII)))throw new AssertionError("Bootconfig magic");
            file.seek(file.length()-20-size);long actual=0;for(long n=0;n<size;n++)actual+=file.readUnsignedByte();if((actual&0xffffffffL)!=sum)throw new AssertionError("Bootconfig checksum");
            System.out.println("Bootconfig trailer size/alignment/checksum passed; bytes="+size);
        }
    }
}
