/* Mock Binder NDK for the ACTUAL display_bridge.c in host regression tests.
 * build.py never packages this file/library. No Android service is contacted.
 */
static int requests;
void *AServiceManager_checkService(const char *name){(void)name;return (void *)0;}
void *AServiceManager_getService(const char *name){(void)name;requests++;return (void *)0;}
void *AIBinder_toJavaBinder(void *env,void *binder){(void)env;(void)binder;return (void *)0;}
void AIBinder_decStrong(void *binder){(void)binder;}
__attribute__((visibility("default")))
int Java_com_virtualphone_vmcheck_AndroidDisplayPreflightSelfTest_startRequests(void *env,void *clazz){(void)env;(void)clazz;return requests;}
