package com.virtualphone.vmcheck;

public final class AvfPreflightPolicySelfTest {
    public static void main(String[] args) {
        if(!AvfPreflightPolicy.passed(0))throw new AssertionError("Lazy display service must not block required Java API checks");
        if(AvfPreflightPolicy.passed(1))throw new AssertionError("A missing required member must block preflight");
        if(AvfPreflightPolicy.passed(7))throw new AssertionError("Multiple missing required members must block preflight");
        System.out.println("PASS: required API failures gate preflight; idle display service readiness is diagnostic only");
    }
}
