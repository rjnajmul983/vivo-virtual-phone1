package com.virtualphone.vmcheck;

import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Tests actual image transformations, not AVF hardware or Android GUI compatibility. */
public final class ImageSelfTest {
    private static byte[] digest(InputStream in)throws Exception {MessageDigest d=MessageDigest.getInstance("SHA-256");byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>=0)d.update(b,0,n);return d.digest();}
    private static void equal(byte[] a,byte[] b,String why){if(!Arrays.equals(a,b))throw new AssertionError(why);}
    private static void le(DataOutputStream o,long v,int n)throws Exception {for(int i=0;i<n;i++)o.write((int)(v>>>(8*i)));}
    private static byte[] fixture(int type,int chunkBytes,boolean trailing)throws Exception {
        ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);
        le(o,0xed26ff3aL,4);le(o,1,2);le(o,0,2);le(o,28,2);le(o,12,2);le(o,4096,4);le(o,1,4);le(o,1,4);le(o,0,4);
        le(o,type,2);le(o,0,2);le(o,1,4);le(o,12+chunkBytes,4);
        if(type==0xcac1)for(int i=0;i<chunkBytes;i++)o.write(i&255);
        if(type==0xcac2)le(o,0x11223344,4);if(trailing)o.write(1);return b.toByteArray();
    }
    public static void main(String[] args)throws Exception {
        File dir=new File(args[1]);dir.mkdirs();File out=new File(dir,"fixture.raw");int rejected=0;
        for(int kind:new int[]{0xcac1,0xcac2,0xcac3}) {
            SparseImage.decode(new ByteArrayInputStream(fixture(kind,kind==0xcac1?4096:kind==0xcac2?4:0,false)),out,4096,n->{});
            byte[] actual=Files.readAllBytes(out.toPath());if(actual.length!=4096)throw new AssertionError("size");
            for(int i=0;i<4096;i++){int want=kind==0xcac1?i&255:kind==0xcac2?(int)(0x11223344L>>>(8*(i%4)))&255:0;if((actual[i]&255)!=want)throw new AssertionError("sparse chunk content");}
        }
        for(byte[] bad:new byte[][]{fixture(0xcac1,20,false),fixture(0xffff,0,false),fixture(0xcac3,0,true),new byte[20]}) {
            try{SparseImage.decode(new ByteArrayInputStream(bad),out,4096,n->{});throw new AssertionError("Malformed sparse image accepted");}catch(IOException expected){rejected++;}
        }
        // Literal-only and overlapping-match legacy LZ4 blocks.
        byte[] lz={2,33,76,24,5,0,0,0,0x40,'t','e','s','t'};equal(BootImages.legacyLz4(lz),new byte[]{'t','e','s','t'},"LZ4 literal");
        byte[] overlap={2,33,76,24,6,0,0,0,0x13,'a',1,0,0x10,'b'};
        equal(BootImages.legacyLz4(overlap),"aaaaaaaab".getBytes("US-ASCII"),"LZ4 overlapping match");
        try{BootImages.legacyLz4(new byte[]{2,33,76,24,3,0,0,0,0,0,0});throw new AssertionError("Invalid LZ4 match accepted");}catch(IOException expected){rejected++;}
        try(ZipFile zip=new ZipFile(args[0])) {
            BootImages.prepare(zip,dir);
            try(InputStream a=new FileInputStream(new File(dir,"Image"));InputStream b=new FileInputStream(args[2])){equal(digest(a),digest(b),"Pinned kernel extraction");}
            try(InputStream a=new GZIPInputStream(new FileInputStream(new File(dir,"initrd.img")));InputStream b=new GZIPInputStream(new FileInputStream(args[3]))){equal(digest(a),digest(b),"Java/Python ramdisk transformations disagree");}
            File raw=new File(dir,"super.raw");SparseImage.decode(zip.getInputStream(zip.getEntry("super.img")),raw,8589934592L,n->{});
            try(InputStream a=new FileInputStream(raw);InputStream b=new FileInputStream(args[4])){equal(digest(a),digest(b),"Java sparse decoder differs from AOSP simg2img");}
        }
        System.out.println("PASS: RAW/FILL/DONT_CARE sparse fixtures; "+rejected+" malformed inputs rejected; LZ4 literals/overlap; actual Google kernel, merged ramdisk and 8 GiB super image agree with reference tools.");
    }
}
