package com.virtualphone.vmcheck;

/** Uses SDK/interface declarations plus a HOST-ONLY JNI lookup stub returning null. */
public final class AndroidDisplayPreflightSelfTest {
    private static native int startRequests();
    public static void main(String[] args)throws Exception {
        if(AndroidDisplay.checkApi())throw new AssertionError("The test lookup must return null");
        try{AndroidDisplay.requireSystemService();throw new AssertionError("Absent service after start request must still block readiness");}catch(IllegalStateException expected){if(!expected.getMessage().contains("requesting lazy startup"))throw expected;}
        if(startRequests()!=1)throw new AssertionError("The actual native bridge did not request lazy startup");
        System.out.println("PASS: actual display preflight resolves required interface symbols and tolerates an idle null Binder lookup without asserting graphics success");
        System.out.println("PASS: actual native bridge requests lazy startup; continued absence remains a readiness failure");
        String c="Landroid/system/virtualmachine/VirtualMachineCustomImageConfig$Builder;";
        if(AvfSetupState.covered(null,c)||AvfSetupState.covered("",c)||AvfSetupState.covered("Lother/Class;",c)||AvfSetupState.covered("Lwrong/*",c))throw new AssertionError("Unrelated setting incorrectly covers AVF");
        if(!AvfSetupState.covered("Landroid/system/virtualmachine/VirtualMachineCustomImageConfig",c)||!AvfSetupState.covered("*",c)||!AvfSetupState.covered("Lother/Class;,Landroid/system/virtualmachine/",c))throw new AssertionError("Expected prefix coverage not recognized");
        System.out.println("PASS: absent, exact, nested, broader, wildcard and unrelated exemption coverage");
        System.out.println("Host stub test only; no Vivo Binder permission or rendering is certified.");
    }
}
