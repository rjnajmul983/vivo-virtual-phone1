from pathlib import Path
import tempfile,os,subprocess,stat
source=(Path(__file__).resolve().parents[1]/'assets/avf-api-setup.sh').read_text()
with tempfile.TemporaryDirectory(prefix='vp-setup-test-') as directory:
 p=Path(directory);binpath=p/'bin';binpath.mkdir();state=p/'setting';events=p/'events';before=p/'before';script=p/'setup.sh'
 script.write_text(source.replace('vp_backup=/data/local/tmp/virtualphone-avf-api.before','vp_backup='+str(before)))
 (binpath/'settings').write_text('''#!/usr/bin/env python3
import os,sys
from pathlib import Path
p=Path(os.environ['VP_TEST_STATE'])
assert sys.argv[2:4]==['global','hidden_api_blacklist_exemptions'],sys.argv
if sys.argv[1]=='get': print(p.read_text() if p.exists() else 'null')
elif os.environ.get('VP_TEST_DENY')=='1':sys.exit(1)
elif sys.argv[1]=='put':p.write_text(sys.argv[4])
elif sys.argv[1]=='delete':p.unlink(missing_ok=True)
else:sys.exit(2)
''')
 (binpath/'am').write_text('#!/bin/sh\necho am >> "$VP_TEST_EVENTS"\n')
 (binpath/'sleep').write_text('#!/bin/sh\nexit 0\n')
 for f in binpath.iterdir():f.chmod(0o755)
 env=os.environ.copy();env.update(PATH=str(binpath)+':'+env['PATH'],VP_TEST_STATE=str(state),VP_TEST_EVENTS=str(events))
 def run(mode='enable',denied=False):
  e=env.copy()
  if denied:e['VP_TEST_DENY']='1'
  return subprocess.run(['/bin/sh',str(script),mode],env=e,capture_output=True,text=True)
 for initial in [None,'Lexample/Existing;', 'Landroid/system/virtualmachine/VirtualMachineConfig,Lexample/Existing;', '*']:
  state.unlink(missing_ok=True);before.unlink(missing_ok=True)
  if initial is not None:state.write_text(initial)
  assert run().returncode==0
  enabled=state.read_text() if state.exists() else None
  assert run().returncode==0 and (state.read_text() if state.exists() else None)==enabled,'Not idempotent'
  if initial=='*':assert enabled=='*'
  assert stat.S_IMODE(before.stat().st_mode)==0o600
  if enabled!='*':state.write_text(enabled+',Lother/AddedLater;')
  assert run('restore').returncode==0
  restored=state.read_text() if state.exists() else None
  expected=initial if initial=='*' else ((initial+',' if initial else '')+'Lother/AddedLater;')
  assert restored==expected,(initial,restored,expected)
  assert not before.exists()
 state.unlink(missing_ok=True);events.unlink(missing_ok=True)
 assert run(denied=True).returncode!=0
 assert not state.exists() and not events.exists(),'Denied setting still restarted the app'
print('PASS: setup is scoped and idempotent; preserves existing entries, pre-existing wildcard, later changes, backup mode 0600, restore and denied-write handling')
print('Mock Settings shell only; Vivo firmware application remains untested.')
