package com.virtualphone.vmcheck;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;

/** Pure-Java framing tests; physical guest rendering remains unverified. */
public final class GuestScreenCaptureSelfTest {
    private static void verify(boolean ok,String name){if(!ok)throw new AssertionError(name);}
    public static void main(String[] args)throws Exception {
        byte[] original=new byte[32768];
        for(int i=0;i<original.length;i++)original[i]=(byte)(i*31+7);
        String wrapped=Base64.getMimeEncoder(76,new byte[]{'\n'}).encodeToString(original);
        String noisy="[  10.100000] guest status: hello\n"+wrapped+"\n";
        byte[] actual=GuestScreenCapture.decodeLines(noisy,original.length);
        verify(Arrays.equals(actual,original),"wrapped guest base64 with log prefix");
        byte[] last=Arrays.copyOf(original,291);
        actual=GuestScreenCapture.decodeLines(Base64.getMimeEncoder(76,new byte[]{'\n'}).encodeToString(last),last.length);
        verify(Arrays.equals(actual,last),"partial final guest chunk");
        boolean rejected=false;
        try{GuestScreenCapture.decodeLines(wrapped,123);}catch(IOException expected){rejected=true;}
        verify(rejected,"length mismatch rejected");
        System.out.println("PASS: guest screen transfer chunk decoding, noise filtering and length check");
    }
}
