package com.virtualphone.vmcheck;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Base64;

/** LOCAL QEMU TEST ONLY: authorize a newly generated local test key in our guest. */
public final class EnableLocalGuestAdb {
    public static void main(String[] args)throws Exception {
        try(Socket socket=new Socket("127.0.0.1",45589)){
            GuestConsole console=new GuestConsole(socket.getOutputStream());
            Thread reader=new Thread(()->{try{InputStream in=socket.getInputStream();ByteArrayOutputStream line=new ByteArrayOutputStream();int b;while((b=in.read())>=0){if(b=='\n'){console.line(new String(line.toByteArray(),StandardCharsets.UTF_8));line.reset();}else if(line.size()<16384)line.write(b);}}catch(IOException ignored){}finally{console.close();}});reader.setDaemon(true);reader.start();
            String pub=Base64.getEncoder().encodeToString(Files.readAllBytes(Paths.get(args[0])));
            GuestConsole.Result ready=console.command("mkdir -p /data/misc/adb; printf %s '"+pub+"' | base64 -d > /data/misc/adb/adb_keys; chown 1000:2000 /data/misc/adb/adb_keys; chmod 0640 /data/misc/adb/adb_keys; ip link set buried_eth0 up; ip addr add 10.0.2.15/24 dev buried_eth0; ip rule add priority 1 table main; setprop service.adb.listen_addrs tcp:5555; setprop service.adb.tcp.port 5555; stop adbd; start adbd; ip -brief addr; getprop service.adb.listen_addrs",true,30000).require();
            System.out.println(ready.output);System.out.println("Local test guest adbd requested; no physical phone was contacted.");console.close();
        }
    }
}
