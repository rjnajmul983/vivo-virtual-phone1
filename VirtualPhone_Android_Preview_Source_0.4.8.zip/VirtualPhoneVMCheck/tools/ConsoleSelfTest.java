package com.virtualphone.vmcheck;
import java.io.*;
import java.util.concurrent.*;
import java.util.regex.*;

/** Fault injection for framing, spoofed echo, bounded output and cancellation. */
public final class ConsoleSelfTest {
    public static void main(String[] args)throws Exception {
        ByteArrayOutputStream written=new ByteArrayOutputStream();GuestConsole console=new GuestConsole(written);
        ExecutorService worker=Executors.newSingleThreadExecutor();
        try {
            Future<GuestConsole.Result> job=worker.submit(()->console.command("id",true,1000));
            String marker=marker(written);console.line("echo "+marker+"_BEGIN");console.line(marker+"_END 0");
            if(job.isDone())throw new AssertionError("Echo was treated as a response");
            console.line(marker+"_BEGIN\r");console.line("uid=0(root)");console.line(marker+"_END bad");console.line(marker+"_END 23\r");
            GuestConsole.Result r=job.get(1,TimeUnit.SECONDS);if(r.code!=23||!r.output.equals("uid=0(root)"))throw new AssertionError("Frame mismatch");
            written.reset();Future<GuestConsole.Result> waiting=worker.submit(()->console.command("id",false,5000));marker(written);console.close();
            try{waiting.get(1,TimeUnit.SECONDS);throw new AssertionError("Close did not cancel pending command");}catch(ExecutionException expected){}
            if(GuestTransfer.safeName("../../file'name").contains("/"))throw new AssertionError("Unsafe name");
            if(!GuestConsole.bootMarker("[  219.106367][  T104] VP_ANDROID_BOOT_COMPLETE abc\r","abc")||GuestConsole.bootMarker("echo VP_ANDROID_BOOT_COMPLETE abc","abc")||GuestConsole.bootMarker("VP_ANDROID_BOOT_COMPLETE wrong","abc"))throw new AssertionError("Boot marker framing");
            System.out.println("PASS: echo rejection, fragmented frames, exit status, close cancellation and path sanitizing");
        }finally{console.close();worker.shutdownNow();}
    }
    private static String marker(ByteArrayOutputStream written)throws Exception {
        long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(2);
        while(System.nanoTime()<end){String s=written.toString("UTF-8");Matcher m=Pattern.compile("VP_CMD_[a-f0-9]+(?=_BEGIN)").matcher(s);if(m.find())return m.group();Thread.yield();}
        throw new AssertionError("Command was not written");
    }
}
