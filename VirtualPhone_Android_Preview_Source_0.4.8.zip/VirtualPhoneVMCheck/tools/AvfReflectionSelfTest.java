package com.virtualphone.vmcheck;
import java.lang.reflect.*;

/** Regression cases for the exact no-public-zero-argument lookup failure. */
public final class AvfReflectionSelfTest {
    public static final class Context {}
    public static final class PublicBuilder {public PublicBuilder(){}}
    public static final class PrivateBuilder {private PrivateBuilder(){}private String value(){return "private-visible";}}
    public static final class ContextBuilder {final Context context;public ContextBuilder(Context c){context=c;}}
    public static final class AbsentBuilder {public AbsentBuilder(String s){}}
    public static final class BrokenBuilder {public BrokenBuilder(){throw new IllegalStateException("constructor failure must not be hidden");}}
    public static final class TestKeyEvent {}
    public static final class LegacyKeyboard {Object received;public boolean sendKeyEvent(TestKeyEvent e){received=e;return true;}}
    public static final class ScanKeyboard {short scan;boolean down;public boolean sendKeyEvent(short s,boolean d){scan=s;down=d;return true;}}
    public static final class RejectedKeyboard {public boolean sendKeyEvent(short s,boolean d){return false;}}
    public static void main(String[] args)throws Exception {
        Context c=new Context();
        if(!(AvfReflection.builder(PublicBuilder.class,Context.class,c) instanceof PublicBuilder))throw new AssertionError();
        try{PrivateBuilder.class.getConstructor();throw new AssertionError("Regression fixture did not reproduce NoSuchMethodException");}catch(NoSuchMethodException expected){}
        Object privateBuilder=AvfReflection.builder(PrivateBuilder.class,Context.class,c);
        if(!"private-visible".equals(AvfReflection.invoke(privateBuilder,"value",new Class<?>[]{})))throw new AssertionError();
        if(((ContextBuilder)AvfReflection.builder(ContextBuilder.class,Context.class,c)).context!=c)throw new AssertionError();
        try{AvfReflection.builder(AbsentBuilder.class,Context.class,c);throw new AssertionError();}catch(NoSuchMethodException expected){if(!expected.getMessage().contains("restricted non-SDK API or OEM API difference"))throw expected;}
        try{AvfReflection.builder(BrokenBuilder.class,Context.class,c);throw new AssertionError();}catch(InvocationTargetException expected){if(!(expected.getCause() instanceof IllegalStateException))throw expected;}
        TestKeyEvent event=new TestKeyEvent();LegacyKeyboard legacy=new LegacyKeyboard();
        if(!AvfReflection.sendKey(legacy,AvfReflection.keyboardMethod(LegacyKeyboard.class,TestKeyEvent.class),(short)158,true,event)||legacy.received!=event)throw new AssertionError("Legacy KeyEvent not forwarded");
        ScanKeyboard scan=new ScanKeyboard();Method input=AvfReflection.keyboardMethod(ScanKeyboard.class,TestKeyEvent.class);
        if(!AvfReflection.sendKey(scan,input,(short)580,true,event)||scan.scan!=580||!scan.down)throw new AssertionError("Scan-code key-down not forwarded");
        if(!AvfReflection.sendKey(scan,input,(short)580,false,event)||scan.down)throw new AssertionError("Scan-code key-up not forwarded");
        if(AvfReflection.sendKey(new RejectedKeyboard(),AvfReflection.keyboardMethod(RejectedKeyboard.class,TestKeyEvent.class),(short)158,true,event))throw new AssertionError("Rejected input must be reported");
        System.out.println("PASS: reproduced missing public constructor; public/private/Context constructors, private method, absent API diagnostics and real constructor exceptions");
        System.out.println("This is a Java compatibility regression test; it does not emulate Vivo's hidden-API policy.");
        System.out.println("PASS: legacy KeyEvent and newer scan-code/down-up signatures, rejected keyboard input");
    }
}
