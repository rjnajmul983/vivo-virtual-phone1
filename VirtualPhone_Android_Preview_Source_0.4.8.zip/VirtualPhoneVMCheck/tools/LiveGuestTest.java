package com.virtualphone.vmcheck;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Runs the production command/transfer classes against a real local Android VM. */
public final class LiveGuestTest {
    public static void main(String[] args)throws Exception {
        try(Socket socket=new Socket("127.0.0.1",45589)) {
            GuestConsole session=new GuestConsole(socket.getOutputStream());
            Thread reader=new Thread(()->{try{
                InputStream in=socket.getInputStream();ByteArrayOutputStream line=new ByteArrayOutputStream();int c;
                while((c=in.read())>=0){if(c=='\n'){session.line(new String(line.toByteArray(),StandardCharsets.UTF_8));line.reset();}else if(line.size()<16384)line.write(c);}
            }catch(IOException ignored){}finally{session.close();}});reader.setDaemon(true);reader.start();
            GuestConsole.Result boot=session.command("getprop sys.boot_completed",false,15000).require();
            check(boot.output.equals("1"),"Natural Android boot: "+boot.output);
            GuestConsole.Result root=session.command("id",true,15000).require();
            check(root.output.contains("uid=0(root)"),"Real guest root: "+root.output);
            GuestConsole.Result failed=session.command("exit 23",false,15000);
            check(failed.code==23,"Nonzero exit propagation");
            File fixture=new File(args[0]);
            GuestTransfer.Progress progress=new GuestTransfer.Progress(){public void update(long b,long n){}public boolean cancelled(){return false;}};
            String imported=GuestTransfer.send(session,fixture,"../../quote' test.bin",false,progress);
            check(imported.contains("SHA-256 "+GuestTransfer.digest(fixture)),"Selected binary transferred with SHA-256");
            String path=imported.split("\n")[0];
            check(session.command("wc -c < "+GuestConsole.quote(path.replace("/storage/emulated/0/","/data/media/0/")),true,15000).require().output.trim().equals(""+fixture.length()),"Guest file byte length");
            System.out.println(GuestTransfer.send(session,new File(args[1]),"GuestTest.apk",true,progress));
            String packages=session.command("pm list packages com.virtualphone.guesttest",false,15000).require().output;
            check(packages.contains("package:com.virtualphone.guesttest"),"Package exists in actual guest");
            session.command("appops set com.virtualphone.guesttest MANAGE_EXTERNAL_STORAGE allow; logcat -c",true,30000).require();
            System.out.println(session.command("settings put global device_provisioned 1; settings put secure user_setup_complete 1; input keyevent 82; am start -a android.intent.action.MAIN -c android.intent.category.HOME",true,60000).require().output);
            System.out.println(session.command("am start -W -n com.virtualphone.guesttest/.MainActivity --es path "+GuestConsole.quote(path),false,60000).require().output);
            Thread.sleep(10000);
            String read=session.command("logcat -d -s VP_GUEST_TEST:I '*:S'",true,15000).require().output;
            check(read.contains(GuestTransfer.digest(fixture)),"Imported binary read through the actual guest app's external-storage mount");
            System.out.println(session.command("dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity'",false,30000).output);
            session.close();System.out.println("PASS: real Android console, root, binary import and package installation");
        }
    }
    private static void check(boolean valid,String message){if(!valid)throw new AssertionError(message);System.out.println("PASS: "+message);}
}
