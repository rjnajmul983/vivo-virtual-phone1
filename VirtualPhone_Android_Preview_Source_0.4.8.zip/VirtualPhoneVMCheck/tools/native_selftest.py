#!/usr/bin/env python3
"""Actual host-side C execution; this never substitutes for an AVF phone test."""
import json,os,platform,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
if platform.system()!='Linux' or platform.machine() not in ['x86_64','aarch64']:
    raise SystemExit('This native syscall check requires Linux x86_64 or aarch64')
with tempfile.TemporaryDirectory(prefix='vp-native-') as work:
    binary=Path(work)/'guest-probe-selftest'
    subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror','-DVP_NATIVE_SELFTEST',
                    str(root/'native/guest_probe.c'),'-o',str(binary)],check=True)
    result=subprocess.run([str(binary)],capture_output=True,text=True,timeout=5)
    assert result.returncode==42,(result.returncode,result.stdout,result.stderr)
    assert result.stdout==result.stderr
    assert result.stdout.startswith('VP_GUEST_PROBE ')
    value=json.loads(result.stdout[len('VP_GUEST_PROBE '):])
    assert value['uid']==os.getuid()
    assert value['pid']>0 and value['pid']!=os.getpid()
    assert value['kernel']==platform.release()
    assert value['machine']==platform.machine()
    assert value['expectedExitCode']==42
print('PASS: real native syscall reads, bounded JSON and sentinel exit 42')
print('This was a host Linux test. Android AVF boot remains a separate device test.')
