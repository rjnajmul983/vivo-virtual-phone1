package com.virtualphone.guesttest;
public class MainActivity extends android.app.Activity {
 public void onCreate(android.os.Bundle b){super.onCreate(b);String result="VirtualPhone guest APK installed successfully";
 try {String path=getIntent().getStringExtra("path");if(path!=null){java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");try(java.io.InputStream in=new java.io.FileInputStream(path)){byte[] data=new byte[4096];int n;while((n=in.read(data))>=0)md.update(data,0,n);}StringBuilder hex=new StringBuilder();for(byte v:md.digest())hex.append(String.format(java.util.Locale.ROOT,"%02x",v&255));result+="\nImported file SHA-256: "+hex;android.util.Log.i("VP_GUEST_TEST",hex.toString());}}catch(Exception e){result+="\nRead failed: "+e;android.util.Log.e("VP_GUEST_TEST",result);}
 android.widget.TextView t=new android.widget.TextView(this);t.setText(result);t.setTextSize(22);t.setTextColor(0xff00ffcc);t.setBackgroundColor(0xff101828);setContentView(t);
 }
}