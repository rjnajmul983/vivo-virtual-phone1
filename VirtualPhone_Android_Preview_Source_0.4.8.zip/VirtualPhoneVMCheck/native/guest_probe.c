/* MIT License. A real AVF guest payload, never loaded by the host application.
 * No heap, files, network or external commands. Linux syscalls only read this
 * guest's UID/PID/kernel, write a diagnostic line, and return the sentinel 42.
 * AVmPayload_notifyPayloadReady is provided by Microdroid's stable payload API.
 */
#if defined(__aarch64__)
static long call3(long number, long a, long b, long c) {
    register long x0 __asm__("x0")=a, x1 __asm__("x1")=b, x2 __asm__("x2")=c;
    register long x8 __asm__("x8")=number;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8),"r"(x1),"r"(x2) : "memory","cc");
    return x0;
}
#define NR_WRITE 64
#define NR_UNAME 160
#define NR_GETPID 172
#define NR_GETUID 174
#elif defined(VP_NATIVE_SELFTEST) && defined(__x86_64__)
/* Only for the separate Linux build-time check, never shipped in the APK. */
static long call3(long number,long a,long b,long c) {
    long result;
    __asm__ volatile("syscall" : "=a"(result) : "a"(number),"D"(a),"S"(b),"d"(c) : "rcx","r11","memory","cc");
    return result;
}
#define NR_WRITE 1
#define NR_UNAME 63
#define NR_GETPID 39
#define NR_GETUID 102
#else
#error This guest payload supports only AArch64.
#endif

#ifdef VP_NATIVE_SELFTEST
static void AVmPayload_notifyPayloadReady(void) {}
#else
extern void AVmPayload_notifyPayloadReady(void);
#endif
struct Uts { char sysname[65],nodename[65],release[65],version[65],machine[65],domain[65]; };
struct Line { char data[1024]; unsigned int length; };
static void text(struct Line* out,const char* value) {
    while(*value && out->length<sizeof(out->data)-1)out->data[out->length++]=*value++;
}
static void number(struct Line* out,unsigned long value) {
    char reverse[32];unsigned int n=0;
    do {reverse[n++]=(char)('0'+value%10);value/=10;} while(value && n<sizeof(reverse));
    while(n && out->length<sizeof(out->data)-1)out->data[out->length++]=reverse[--n];
}
static void safe_string(struct Line* out,const char* value) {
    for(unsigned int i=0;i<64 && value[i] && out->length<sizeof(out->data)-1;i++) {
        unsigned char c=(unsigned char)value[i];
        out->data[out->length++]=(c>=32 && c<127 && c!='"' && c!='\\')?(char)c:'_';
    }
}
__attribute__((visibility("default"))) int AVmPayload_main(void) {
    struct Uts uts;
    long uname_result=call3(NR_UNAME,(long)&uts,0,0);
    long uid=call3(NR_GETUID,0,0,0), pid=call3(NR_GETPID,0,0,0);
    struct Line out;out.length=0;
    text(&out,"VP_GUEST_PROBE {\"schema\":1,\"marker\":\"vp_guest_v2\",\"uid\":");
    number(&out,(unsigned long)uid);text(&out,",\"pid\":");number(&out,(unsigned long)pid);
    text(&out,",\"kernel\":\"");
    if(uname_result==0)safe_string(&out,uts.release);else text(&out,"unavailable");
    text(&out,"\",\"machine\":\"");
    if(uname_result==0)safe_string(&out,uts.machine);else text(&out,"unavailable");
    text(&out,"\",\"expectedExitCode\":42}\n");
    /* Both streams are guest-owned. At least one should be routed to captured
       console/log output by the OEM's Microdroid launcher. */
    call3(NR_WRITE,1,(long)out.data,(long)out.length);
    call3(NR_WRITE,2,(long)out.data,(long)out.length);
    AVmPayload_notifyPayloadReady();
    return 42;
}
#ifdef VP_NATIVE_SELFTEST
int main(void){return AVmPayload_main();}
#endif
