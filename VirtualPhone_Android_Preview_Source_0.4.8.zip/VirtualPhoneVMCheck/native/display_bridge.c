/* Only looks up the permission-checked AVF system Binder through libbinder_ndk.
 * No host identifiers, files, elevation, private Binder transaction numbers,
 * or hidden-API policy changes are used. Android supplies the actual library.
 */
typedef void JNIEnv;
typedef void *jobject;
typedef struct AIBinder AIBinder;
extern AIBinder *AServiceManager_checkService(const char *name);
extern AIBinder *AServiceManager_getService(const char *name);
extern jobject AIBinder_toJavaBinder(JNIEnv *env, AIBinder *binder);
extern void AIBinder_decStrong(AIBinder *binder);
__attribute__((visibility("default")))
jobject Java_com_virtualphone_vmcheck_AndroidDisplay_lookup(JNIEnv *env, jobject clazz) {
    (void)clazz;
    AIBinder *binder = AServiceManager_checkService("android.system.virtualizationservice");
    if (!binder) return (jobject)0;
    jobject result = AIBinder_toJavaBinder(env, binder);
    AIBinder_decStrong(binder);
    return result;
}
/* AOSP's legacy getService requests lazy startup with a bounded retry budget.
 * Call only on workers. The same Android permission/SELinux rules still apply.
 */
__attribute__((visibility("default")))
jobject Java_com_virtualphone_vmcheck_AndroidDisplay_requestLookup(JNIEnv *env, jobject clazz) {
    (void)clazz;
    AIBinder *binder=AServiceManager_getService("android.system.virtualizationservice");
    if(!binder)return (jobject)0;
    jobject result=AIBinder_toJavaBinder(env,binder);
    AIBinder_decStrong(binder);
    return result;
}
